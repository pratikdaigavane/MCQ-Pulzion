-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 24, 2019 at 10:06 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mcq_pasc`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add question', 7, 'add_question'),
(26, 'Can change question', 7, 'change_question'),
(27, 'Can delete question', 7, 'delete_question'),
(28, 'Can view question', 7, 'view_question'),
(29, 'Can add scores', 8, 'add_scores'),
(30, 'Can change scores', 8, 'change_scores'),
(31, 'Can delete scores', 8, 'delete_scores'),
(32, 'Can view scores', 8, 'view_scores'),
(33, 'Can add scores', 9, 'add_scores'),
(34, 'Can change scores', 9, 'change_scores'),
(35, 'Can delete scores', 9, 'delete_scores'),
(36, 'Can view scores', 9, 'view_scores'),
(37, 'Can add scores', 10, 'add_scores'),
(38, 'Can change scores', 10, 'change_scores'),
(39, 'Can delete scores', 10, 'delete_scores'),
(40, 'Can view scores', 10, 'view_scores'),
(41, 'Can add auth', 11, 'add_auth'),
(42, 'Can change auth', 11, 'change_auth'),
(43, 'Can delete auth', 11, 'delete_auth'),
(44, 'Can view auth', 11, 'view_auth');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(57, 'pbkdf2_sha256$150000$D8IjNcHGWA3S$oa2e0Rbc/5fFvLZ54GquvddW0hUD+xbJRdsxP74yPUc=', '2019-07-23 18:44:07.000000', 1, 'admin', '', '', '', 1, 1, '2019-07-17 13:56:42.000000'),
(133, 'pbkdf2_sha256$150000$TiR4xFxZHNLm$B5XYlb5btCnlkUGvOD4MGXjot5z5vbAwqhItOSGi03M=', '2019-08-22 20:19:00.479536', 1, 'pratik', '', '', '', 1, 1, '2019-08-20 12:12:34.051870');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(40, '2019-07-17 13:57:11.241100', '46', 'admin', 3, '', 4, 57),
(41, '2019-07-17 13:57:11.335424', '40', 'apoorv', 3, '', 4, 57),
(42, '2019-07-17 13:57:11.375374', '41', 'manav', 3, '', 4, 57),
(43, '2019-07-17 13:57:11.470095', '45', 'nachiket', 3, '', 4, 57),
(44, '2019-07-17 13:57:11.503183', '52', 'pratham@pasc.in', 3, '', 4, 57),
(45, '2019-07-17 13:57:11.536615', '44', 'pratik', 3, '', 4, 57),
(46, '2019-07-17 13:57:11.570129', '39', 'raghav', 3, '', 4, 57),
(47, '2019-07-17 13:57:11.603497', '53', 'user1@pasc.in', 3, '', 4, 57),
(48, '2019-07-17 13:57:11.637004', '54', 'user2@pasc.in', 3, '', 4, 57),
(49, '2019-07-17 13:57:11.679267', '56', 'user3@pasc.in', 3, '', 4, 57),
(50, '2019-07-17 13:57:11.712613', '55', 'user5@pasc.in', 3, '', 4, 57),
(51, '2019-07-17 16:40:13.064841', '59', 'user2@pasc.in', 3, '', 4, 57),
(52, '2019-07-17 16:40:13.168583', '58', 'user1@pasc.in', 3, '', 4, 57),
(53, '2019-07-17 18:54:15.317283', '63', 'user5@pasc.in', 3, '', 4, 57),
(54, '2019-07-17 18:54:15.394679', '61', 'user3@pasc.in', 3, '', 4, 57),
(55, '2019-07-17 18:54:15.505744', '60', 'user1@pasc.in', 3, '', 4, 57),
(56, '2019-07-17 18:54:15.547213', '62', 'pratham@pasc.in', 3, '', 4, 57),
(57, '2019-07-17 19:11:48.036327', '65', 'user1@pasc.in', 3, '', 4, 57),
(58, '2019-07-17 19:11:48.169041', '64', 'pratham@pasc.in', 3, '', 4, 57),
(59, '2019-07-17 19:16:58.207675', '69', 'user5@pasc.in', 3, '', 4, 57),
(60, '2019-07-17 19:16:58.608907', '68', 'user3@pasc.in', 3, '', 4, 57),
(61, '2019-07-17 19:16:58.684311', '67', 'user1@pasc.in', 3, '', 4, 57),
(62, '2019-07-17 19:16:58.785934', '66', 'pratham@pasc.in', 3, '', 4, 57),
(63, '2019-07-17 19:29:53.276030', '71', 'pratham@pasc.in', 3, '', 4, 57),
(64, '2019-07-17 19:29:53.363149', '70', 'user1@pasc.in', 3, '', 4, 57),
(65, '2019-07-17 19:29:53.464138', '72', 'user3@pasc.in', 3, '', 4, 57),
(66, '2019-07-17 19:29:53.572272', '73', 'user4@pasc.in', 3, '', 4, 57),
(67, '2019-07-18 12:28:41.308830', '75', 'joshisiddhesh28@gmail.com', 3, '', 4, 57),
(68, '2019-07-18 12:28:41.372581', '74', 'pratham@pasc.in', 3, '', 4, 57),
(69, '2019-07-18 17:18:04.077887', '82', 'anuj@pasc.in', 3, '', 4, 57),
(70, '2019-07-18 17:18:04.122594', '83', 'jinesh@pasc.in', 3, '', 4, 57),
(71, '2019-07-18 17:18:04.164038', '81', 'pratham@pasc.in', 3, '', 4, 57),
(72, '2019-07-18 17:18:04.223186', '76', 'user1@pasc.in', 3, '', 4, 57),
(73, '2019-07-18 17:18:04.289537', '77', 'user2@pasc.in', 3, '', 4, 57),
(74, '2019-07-18 17:18:04.481748', '78', 'user3@pasc.in', 3, '', 4, 57),
(75, '2019-07-18 17:18:04.557140', '79', 'user4@pasc.in', 3, '', 4, 57),
(76, '2019-07-18 17:18:04.615588', '80', 'user5@pasc.in', 3, '', 4, 57),
(77, '2019-07-21 12:39:48.184455', '89', 'boss@pasc.in', 3, '', 4, 57),
(78, '2019-07-21 12:39:48.211988', '88', 'jinesh@pasc.in', 3, '', 4, 57),
(79, '2019-07-21 12:39:48.237174', '85', 'pratham@pasc.in', 3, '', 4, 57),
(80, '2019-07-21 12:39:48.262197', '84', 'user1@pasc.in', 3, '', 4, 57),
(81, '2019-07-21 12:39:48.295629', '86', 'user2@pasc.in', 3, '', 4, 57),
(82, '2019-07-21 12:39:48.328786', '87', 'user3@pasc.in', 3, '', 4, 57),
(83, '2019-07-21 17:02:14.675654', '96', 'anuj@pasc.in', 3, '', 4, 57),
(84, '2019-07-21 17:02:14.714534', '99', 'apoorv@pasc.in', 3, '', 4, 57),
(85, '2019-07-21 17:02:14.739982', '98', 'boss@pasc.in', 3, '', 4, 57),
(86, '2019-07-21 17:02:14.790313', '97', 'jinesh@pasc.in', 3, '', 4, 57),
(87, '2019-07-21 17:02:14.815351', '92', 'pratham@pasc.in', 3, '', 4, 57),
(88, '2019-07-21 17:02:14.840213', '90', 'user1@pasc.in', 3, '', 4, 57),
(89, '2019-07-21 17:02:14.991182', '91', 'user2@pasc.in', 3, '', 4, 57),
(90, '2019-07-21 17:02:15.016277', '93', 'user3@pasc.in', 3, '', 4, 57),
(91, '2019-07-21 17:02:15.041743', '94', 'user4@pasc.in', 3, '', 4, 57),
(92, '2019-07-21 17:02:15.066622', '95', 'user5@pasc.in', 3, '', 4, 57),
(93, '2019-07-22 12:10:11.092675', '105', 'anuj@pasc.in', 3, '', 4, 57),
(94, '2019-07-22 12:10:11.158988', '107', 'boss@pasc.in', 3, '', 4, 57),
(95, '2019-07-22 12:10:11.192445', '106', 'jinesh@pasc.in', 3, '', 4, 57),
(96, '2019-07-22 12:10:11.225956', '110', 'manav@pasc.in', 3, '', 4, 57),
(97, '2019-07-22 12:10:11.259410', '108', 'pratham@pasc.in', 3, '', 4, 57),
(98, '2019-07-22 12:10:11.326200', '109', 'raghav@pasc.in', 3, '', 4, 57),
(99, '2019-07-22 12:10:11.359688', '100', 'user1@pasc.in', 3, '', 4, 57),
(100, '2019-07-22 12:10:11.392833', '101', 'user2@pasc.in', 3, '', 4, 57),
(101, '2019-07-22 12:10:11.493571', '102', 'user3@pasc.in', 3, '', 4, 57),
(102, '2019-07-22 12:10:11.526802', '103', 'user4@pasc.in', 3, '', 4, 57),
(103, '2019-07-22 12:10:11.560479', '104', 'user5@pasc.in', 3, '', 4, 57),
(104, '2019-07-22 12:10:11.594152', '111', 'yash@pasc.in', 3, '', 4, 57),
(105, '2019-07-23 14:26:32.385403', '116', 'yash@pasc.in', 3, '', 4, 57),
(106, '2019-07-23 14:26:32.517819', '117', 'user5@pasc.in', 3, '', 4, 57),
(107, '2019-07-23 14:26:32.558596', '118', 'user4@pasc.in', 3, '', 4, 57),
(108, '2019-07-23 14:26:32.608503', '114', 'user3@pasc.in', 3, '', 4, 57),
(109, '2019-07-23 14:26:32.642362', '115', 'user2@pasc.in', 3, '', 4, 57),
(110, '2019-07-23 14:26:32.683693', '113', 'user1@pasc.in', 3, '', 4, 57),
(111, '2019-07-23 14:26:32.717245', '119', 'jinesh@pasc.in', 3, '', 4, 57),
(112, '2019-07-23 14:26:32.750618', '112', 'anuj@pasc.in', 3, '', 4, 57),
(113, '2019-07-23 18:16:22.341613', '127', 'apoorv@pasc.in', 3, '', 4, 57),
(114, '2019-07-23 18:16:22.387793', '126', 'boss@pasc.in', 3, '', 4, 57),
(115, '2019-07-23 18:16:22.420270', '128', 'manav@pasc.in', 3, '', 4, 57),
(116, '2019-07-23 18:16:22.454162', '120', 'pratham@pasc.in', 3, '', 4, 57),
(117, '2019-07-23 18:16:22.488482', '129', 'raghav@pasc.in', 3, '', 4, 57),
(118, '2019-07-23 18:16:22.521432', '121', 'user1@pasc.in', 3, '', 4, 57),
(119, '2019-07-23 18:16:22.554739', '122', 'user2@pasc.in', 3, '', 4, 57),
(120, '2019-07-23 18:16:22.587936', '123', 'user3@pasc.in', 3, '', 4, 57),
(121, '2019-07-23 18:16:22.622022', '125', 'user4@pasc.in', 3, '', 4, 57),
(122, '2019-07-23 18:16:22.654644', '124', 'yash@pasc.in', 3, '', 4, 57),
(123, '2019-07-23 18:44:36.614351', '130', 'user1@pasc.in', 3, '', 4, 57),
(124, '2019-07-23 18:44:36.661739', '131', 'user2@pasc.in', 3, '', 4, 57),
(125, '2019-07-23 18:44:57.748042', '57', 'admin', 2, '[{\"changed\": {\"fields\": [\"username\"]}}]', 4, 57),
(126, '2019-07-23 18:45:15.752958', '4', 'Scores object (4)', 3, '', 10, 57),
(127, '2019-07-23 18:45:15.783685', '3', 'Scores object (3)', 3, '', 10, 57),
(128, '2019-07-23 18:45:15.817125', '2', 'Scores object (2)', 3, '', 10, 57),
(129, '2019-07-23 18:45:15.850572', '1', 'Scores object (1)', 3, '', 10, 57),
(130, '2019-08-20 12:39:46.724105', '132', 'boss@pasc.in', 3, '', 4, 133),
(131, '2019-08-20 12:39:46.730198', '135', 'manav@pasc.in', 3, '', 4, 133),
(132, '2019-08-20 12:39:46.734291', '134', 'user1@pasc.in', 3, '', 4, 133),
(133, '2019-08-20 14:03:47.029916', '137', 'boss@pasc.in', 3, '', 4, 133),
(134, '2019-08-20 14:03:47.035973', '138', 'manav@pasc.in', 3, '', 4, 133),
(135, '2019-08-20 14:03:47.039808', '136', 'user1@pasc.in', 3, '', 4, 133),
(136, '2019-08-21 05:46:59.548958', '139', 'boss@pasc.in', 3, '', 4, 133),
(137, '2019-08-21 05:46:59.554149', '141', 'raghav@pasc.in', 3, '', 4, 133),
(138, '2019-08-21 05:46:59.557564', '140', 'yash@pasc.in', 3, '', 4, 133),
(139, '2019-08-21 06:34:40.127593', '142', 'boss@pasc.in', 3, '', 4, 133),
(140, '2019-08-21 06:34:40.134820', '143', 'user1@pasc.in', 3, '', 4, 133),
(141, '2019-08-21 07:34:58.958882', '147', 'anuj@pasc.in', 3, '', 4, 133),
(142, '2019-08-21 07:34:58.970769', '149', 'boss@pasc.in', 3, '', 4, 133),
(143, '2019-08-21 07:34:58.974726', '146', 'user1@pasc.in', 3, '', 4, 133),
(144, '2019-08-21 07:34:58.978547', '144', 'user2@pasc.in', 3, '', 4, 133),
(145, '2019-08-21 07:34:58.982642', '148', 'user3@pasc.in', 3, '', 4, 133),
(146, '2019-08-21 07:34:58.986515', '145', 'user4@pasc.in', 3, '', 4, 133),
(147, '2019-08-21 10:07:45.966198', '150', 'boss@pasc.in', 3, '', 4, 133),
(148, '2019-08-21 10:17:59.251548', '152', 'boss@pasc.in', 3, '', 4, 133),
(149, '2019-08-21 10:17:59.257903', '153', 'manav@pasc.in', 3, '', 4, 133),
(150, '2019-08-21 10:17:59.260362', '151', 'user1@pasc.in', 3, '', 4, 133),
(151, '2019-08-21 10:22:33.150662', '154', 'boss@pasc.in', 3, '', 4, 133),
(152, '2019-08-21 11:55:31.938724', '155', 'boss@pasc.in', 3, '', 4, 133),
(153, '2019-08-21 12:00:58.816610', '157', 'boss@pasc.in', 3, '', 4, 133),
(154, '2019-08-21 12:00:58.823123', '156', 'user1@pasc.in', 3, '', 4, 133),
(155, '2019-08-21 12:08:43.984624', '158', 'boss@pasc.in', 3, '', 4, 133),
(156, '2019-08-21 12:08:43.990691', '159', 'user1@pasc.in', 3, '', 4, 133),
(157, '2019-08-21 12:12:28.399259', '160', 'boss@pasc.in', 3, '', 4, 133),
(158, '2019-08-21 17:53:50.217543', '161', 'boss@pasc.in', 3, '', 4, 133),
(159, '2019-08-21 17:53:50.225235', '163', 'mundada.devansh@gmail.com', 3, '', 4, 133),
(160, '2019-08-21 17:53:50.228452', '162', 'vedbhatawadekar@gmail.com', 3, '', 4, 133),
(161, '2019-08-21 18:33:13.216947', '164', 'boss@pasc.in', 3, '', 4, 133),
(162, '2019-08-21 19:05:17.836093', '1', 'Question object (1)', 2, '[{\"changed\": {\"fields\": [\"problem\", \"option_a\", \"option_b\", \"option_c\", \"option_d\", \"correct_option\"]}}]', 7, 133),
(163, '2019-08-21 19:06:12.019300', '166', 'boss@pasc.in', 3, '', 4, 133),
(164, '2019-08-21 19:06:12.025404', '165', 'user1@pasc.in', 3, '', 4, 133),
(165, '2019-08-21 19:06:12.028891', '167', 'yash@pasc.in', 3, '', 4, 133),
(166, '2019-08-22 03:55:13.291740', '168', 'boss@pasc.in', 3, '', 4, 133),
(167, '2019-08-22 03:55:13.297059', '170', 'jinesh@pasc.in', 3, '', 4, 133),
(168, '2019-08-22 03:55:13.300642', '169', 'user1@pasc.in', 3, '', 4, 133),
(169, '2019-08-22 04:47:24.931276', '175', 'anuj@pasc.in', 3, '', 4, 133),
(170, '2019-08-22 04:47:24.943155', '171', 'boss@pasc.in', 3, '', 4, 133),
(171, '2019-08-22 04:47:24.948587', '174', 'user1@pasc.in', 3, '', 4, 133),
(172, '2019-08-22 04:47:24.954101', '172', 'user2@pasc.in', 3, '', 4, 133),
(173, '2019-08-22 04:47:24.957233', '173', 'user3@pasc.in', 3, '', 4, 133),
(174, '2019-08-22 12:21:43.991533', '176', 'boss@pasc.in', 3, '', 4, 133),
(175, '2019-08-22 12:21:43.998719', '178', 'jinesh@pasc.in', 3, '', 4, 133),
(176, '2019-08-22 12:21:44.002401', '180', 'user1@pasc.in', 3, '', 4, 133),
(177, '2019-08-22 12:21:44.004280', '181', 'user2@pasc.in', 3, '', 4, 133),
(178, '2019-08-22 12:21:44.007513', '177', 'user4@pasc.in', 3, '', 4, 133),
(179, '2019-08-22 12:21:44.010899', '179', 'user5@pasc.in', 3, '', 4, 133),
(180, '2019-08-22 17:20:03.106662', '1', 'Question object (1)', 2, '[{\"changed\": {\"fields\": [\"problem\"]}}]', 7, 133),
(181, '2019-08-22 17:47:49.663191', '1', 'Question object (1)', 2, '[{\"changed\": {\"fields\": [\"problem\"]}}]', 7, 133),
(182, '2019-08-22 20:25:42.053852', '172', 'auth object (172)', 1, '[{\"added\": {}}]', 11, 133),
(183, '2019-08-22 20:26:29.807323', '190', 'aj240502@gmail.com', 3, '', 4, 133),
(184, '2019-08-22 20:26:29.814178', '182', 'boss@pasc.in', 3, '', 4, 133),
(185, '2019-08-22 20:26:29.818033', '186', 'bsnsourav@gmail.com', 3, '', 4, 133),
(186, '2019-08-22 20:26:29.822677', '195', 'codeicted@gmail.com', 3, '', 4, 133),
(187, '2019-08-22 20:26:29.827188', '191', 'deoresakshi16@gmail.com', 3, '', 4, 133),
(188, '2019-08-22 20:26:29.832785', '197', 'hpshah294@gmail.com', 3, '', 4, 133),
(189, '2019-08-22 20:26:29.837918', '189', 'jaydoshi9012@gmail.com', 3, '', 4, 133),
(190, '2019-08-22 20:26:29.843214', '184', 'manav@pasc.in', 3, '', 4, 133),
(191, '2019-08-22 20:26:29.848968', '193', 'manlikerathish@gmail.com', 3, '', 4, 133),
(192, '2019-08-22 20:26:29.856809', '187', 'nimu.kelkar@gmail.com', 3, '', 4, 133),
(193, '2019-08-22 20:26:29.863989', '185', 'paramrpatil@gmail.com', 3, '', 4, 133),
(194, '2019-08-22 20:26:29.871092', '188', 'ramborude999@gmail.com', 3, '', 4, 133),
(195, '2019-08-22 20:26:29.876764', '192', 'sudarshanvhon1105@gmail.com', 3, '', 4, 133),
(196, '2019-08-22 20:26:29.883418', '183', 'user1@pasc.in', 3, '', 4, 133),
(197, '2019-08-22 20:26:29.896379', '194', 'user2@pasc.in', 3, '', 4, 133),
(198, '2019-08-22 20:26:29.901906', '196', 'vjyeluri31@gmail.com', 3, '', 4, 133),
(199, '2019-08-22 22:53:39.077872', '198', 'user1@pasc.in', 3, '', 4, 133),
(200, '2019-08-22 22:55:25.108163', '200', 'user1@pasc.in', 3, '', 4, 133),
(201, '2019-08-22 22:58:04.360153', '201', 'user1@pasc.in', 3, '', 4, 133),
(202, '2019-08-22 23:01:53.185433', '202', 'user1@pasc.in', 3, '', 4, 133),
(203, '2019-08-22 23:05:39.397632', '203', 'user1@pasc.in', 3, '', 4, 133),
(204, '2019-08-22 23:07:09.192478', '204', 'user1@pasc.in', 3, '', 4, 133),
(205, '2019-08-22 23:11:13.809398', '205', 'user1@pasc.in', 3, '', 4, 133),
(206, '2019-08-22 23:16:47.160055', '206', 'user1@pasc.in', 3, '', 4, 133),
(207, '2019-08-22 23:20:02.935669', '207', 'user1@pasc.in', 3, '', 4, 133),
(208, '2019-08-22 23:21:27.735765', '208', 'user1@pasc.in', 3, '', 4, 133),
(209, '2019-08-22 23:24:43.826724', '209', 'user1@pasc.in', 3, '', 4, 133),
(210, '2019-08-22 23:33:34.603516', '210', 'user1@pasc.in', 3, '', 4, 133),
(211, '2019-08-22 23:48:34.074106', '211', 'user1@pasc.in', 3, '', 4, 133),
(212, '2019-08-22 23:53:16.111291', '212', 'user1@pasc.in', 3, '', 4, 133),
(213, '2019-08-23 00:31:40.084854', '67', 'Scores object (67)', 3, '', 10, 133),
(214, '2019-08-23 00:31:40.092565', '66', 'Scores object (66)', 3, '', 10, 133),
(215, '2019-08-23 00:31:40.097294', '65', 'Scores object (65)', 3, '', 10, 133),
(216, '2019-08-23 00:31:40.106444', '64', 'Scores object (64)', 3, '', 10, 133),
(217, '2019-08-23 00:31:40.110202', '63', 'Scores object (63)', 3, '', 10, 133),
(218, '2019-08-23 00:31:40.114142', '62', 'Scores object (62)', 3, '', 10, 133),
(219, '2019-08-23 00:31:40.117895', '61', 'Scores object (61)', 3, '', 10, 133),
(220, '2019-08-23 00:31:40.121759', '60', 'Scores object (60)', 3, '', 10, 133),
(221, '2019-08-23 00:31:40.125744', '59', 'Scores object (59)', 3, '', 10, 133),
(222, '2019-08-23 00:31:40.129483', '58', 'Scores object (58)', 3, '', 10, 133),
(223, '2019-08-23 00:31:40.133531', '57', 'Scores object (57)', 3, '', 10, 133),
(224, '2019-08-23 00:31:40.138039', '56', 'Scores object (56)', 3, '', 10, 133),
(225, '2019-08-23 00:31:40.142573', '55', 'Scores object (55)', 3, '', 10, 133),
(226, '2019-08-23 00:31:40.147202', '54', 'Scores object (54)', 3, '', 10, 133),
(227, '2019-08-23 00:31:40.151822', '53', 'Scores object (53)', 3, '', 10, 133),
(228, '2019-08-23 00:31:40.182387', '52', 'Scores object (52)', 3, '', 10, 133),
(229, '2019-08-23 00:31:40.208386', '51', 'Scores object (51)', 3, '', 10, 133),
(230, '2019-08-23 00:31:40.214206', '50', 'Scores object (50)', 3, '', 10, 133),
(231, '2019-08-23 00:31:40.219155', '49', 'Scores object (49)', 3, '', 10, 133),
(232, '2019-08-23 00:31:40.224674', '48', 'Scores object (48)', 3, '', 10, 133),
(233, '2019-08-23 01:02:42.401852', '213', 'user1@pasc.in', 3, '', 4, 133),
(234, '2019-08-23 01:05:03.327977', '214', 'user1@pasc.in', 3, '', 4, 133),
(235, '2019-08-23 01:08:01.842611', '215', 'user1@pasc.in', 3, '', 4, 133),
(236, '2019-08-23 01:08:37.550531', '216', 'user1@pasc.in', 3, '', 4, 133),
(237, '2019-08-23 01:12:31.615395', '217', 'user1@pasc.in', 3, '', 4, 133),
(238, '2019-08-23 01:45:32.195133', '323', 'Question object (323)', 3, '', 7, 133),
(239, '2019-08-23 01:45:32.202205', '322', 'Question object (322)', 3, '', 7, 133),
(240, '2019-08-23 01:45:32.205460', '321', 'Question object (321)', 3, '', 7, 133),
(241, '2019-08-23 01:45:32.209066', '320', 'Question object (320)', 3, '', 7, 133),
(242, '2019-08-23 01:45:32.212867', '319', 'Question object (319)', 3, '', 7, 133),
(243, '2019-08-23 01:45:32.216469', '318', 'Question object (318)', 3, '', 7, 133),
(244, '2019-08-23 01:45:32.219803', '317', 'Question object (317)', 3, '', 7, 133),
(245, '2019-08-23 01:45:32.221467', '316', 'Question object (316)', 3, '', 7, 133),
(246, '2019-08-23 01:45:32.224467', '315', 'Question object (315)', 3, '', 7, 133),
(247, '2019-08-23 01:45:32.227878', '314', 'Question object (314)', 3, '', 7, 133),
(248, '2019-08-23 01:45:32.229696', '313', 'Question object (313)', 3, '', 7, 133),
(249, '2019-08-23 01:45:32.233222', '312', 'Question object (312)', 3, '', 7, 133),
(250, '2019-08-23 01:45:32.237532', '311', 'Question object (311)', 3, '', 7, 133),
(251, '2019-08-23 01:45:32.242406', '310', 'Question object (310)', 3, '', 7, 133),
(252, '2019-08-23 01:45:32.247786', '309', 'Question object (309)', 3, '', 7, 133),
(253, '2019-08-23 01:45:32.252938', '308', 'Question object (308)', 3, '', 7, 133),
(254, '2019-08-23 01:45:32.257998', '307', 'Question object (307)', 3, '', 7, 133),
(255, '2019-08-23 01:45:32.262474', '306', 'Question object (306)', 3, '', 7, 133),
(256, '2019-08-23 01:45:32.267100', '305', 'Question object (305)', 3, '', 7, 133),
(257, '2019-08-23 01:45:32.271610', '304', 'Question object (304)', 3, '', 7, 133),
(258, '2019-08-23 01:45:39.550456', '303', 'Question object (303)', 3, '', 7, 133),
(259, '2019-08-23 01:46:26.686047', '169', 'Question object (169)', 3, '', 7, 133),
(260, '2019-08-23 02:06:08.356961', '218', 'user1@pasc.in', 3, '', 4, 133),
(261, '2019-08-23 02:06:18.215479', '199', 'deoresakshi16@gmail.com', 3, '', 4, 133),
(262, '2019-08-23 02:09:32.749195', '219', 'user1@pasc.in', 3, '', 4, 133),
(263, '2019-08-23 02:13:56.541566', '220', 'user1@pasc.in', 3, '', 4, 133),
(264, '2019-08-23 02:14:05.146206', '1', 'Scores object (1)', 3, '', 10, 133),
(265, '2019-08-23 02:24:27.425360', '221', 'user1@pasc.in', 3, '', 4, 133),
(266, '2019-08-23 02:33:13.999201', '3', 'Scores object (3)', 3, '', 10, 133),
(267, '2019-08-23 02:33:14.004085', '2', 'Scores object (2)', 3, '', 10, 133),
(268, '2019-08-23 02:37:01.618682', '222', 'user1@pasc.in', 3, '', 4, 133),
(269, '2019-08-23 03:31:03.773022', '172', 'auth object (172)', 1, '[{\"added\": {}}]', 11, 133),
(270, '2019-08-23 04:32:09.123283', '223', 'user1@pasc.in', 3, '', 4, 133),
(271, '2019-08-23 04:35:30.820739', '224', 'user1@pasc.in', 3, '', 4, 133),
(272, '2019-08-23 04:35:42.768733', '4', 'Scores object (4)', 3, '', 10, 133),
(273, '2019-08-23 04:48:31.731343', '267', 'Question object (267)', 2, '[{\"changed\": {\"fields\": [\"problem\", \"option_a\", \"option_c\", \"option_d\"]}}]', 7, 133),
(274, '2019-08-23 04:48:58.334535', '267', 'Question object (267)', 2, '[{\"changed\": {\"fields\": [\"option_a\", \"option_b\", \"option_c\"]}}]', 7, 133),
(275, '2019-08-23 04:49:27.097550', '267', 'Question object (267)', 2, '[{\"changed\": {\"fields\": [\"option_d\"]}}]', 7, 133),
(276, '2019-08-23 04:51:03.271509', '225', 'user1@pasc.in', 3, '', 4, 133),
(277, '2019-08-23 04:51:11.660057', '5', 'Scores object (5)', 3, '', 10, 133);

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(11, 'questions', 'auth'),
(7, 'questions', 'question'),
(10, 'questions', 'scores'),
(9, 'Scores', 'scores'),
(6, 'sessions', 'session'),
(8, 'test_submit', 'scores');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2019-06-30 13:35:00.564237'),
(2, 'auth', '0001_initial', '2019-06-30 13:35:00.732599'),
(3, 'admin', '0001_initial', '2019-06-30 13:35:01.309169'),
(4, 'admin', '0002_logentry_remove_auto_add', '2019-06-30 13:35:01.429526'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2019-06-30 13:35:01.443486'),
(6, 'contenttypes', '0002_remove_content_type_name', '2019-06-30 13:35:01.569100'),
(7, 'auth', '0002_alter_permission_name_max_length', '2019-06-30 13:35:01.582427'),
(8, 'auth', '0003_alter_user_email_max_length', '2019-06-30 13:35:01.603370'),
(9, 'auth', '0004_alter_user_username_opts', '2019-06-30 13:35:01.618331'),
(10, 'auth', '0005_alter_user_last_login_null', '2019-06-30 13:35:01.691136'),
(11, 'auth', '0006_require_contenttypes_0002', '2019-06-30 13:35:01.694129'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2019-06-30 13:35:01.719061'),
(13, 'auth', '0008_alter_user_username_max_length', '2019-06-30 13:35:01.742998'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2019-06-30 13:35:01.772917'),
(15, 'auth', '0010_alter_group_name_max_length', '2019-06-30 13:35:01.789873'),
(16, 'auth', '0011_update_proxy_permissions', '2019-06-30 13:35:01.803836'),
(17, 'questions', '0001_initial', '2019-06-30 13:35:01.855417'),
(18, 'sessions', '0001_initial', '2019-06-30 13:35:01.891321'),
(19, 'test_submit', '0001_initial', '2019-07-07 11:47:06.039550'),
(20, 'Scores', '0001_initial', '2019-07-07 12:01:23.885018'),
(21, 'questions', '0002_scores', '2019-07-23 17:39:03.242529'),
(22, 'questions', '0003_auto_20190812_1353', '2019-08-20 11:26:50.042294'),
(23, 'questions', '0004_auto_20190812_1413', '2019-08-20 11:26:50.083333'),
(24, 'questions', '0005_scores_created', '2019-08-20 11:26:50.093650'),
(25, 'questions', '0006_auto_20190819_0100', '2019-08-20 11:26:50.112335'),
(26, 'questions', '0007_scores_name', '2019-08-21 11:42:19.791963'),
(27, 'questions', '0008_auth', '2019-08-22 13:33:00.733171');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('05t3o1gwfq2nca6v81lir3o7qmzb1en5', 'NmFmYTliZTBlYTg4ZmVmOTIzNTQ5NDQ3YWU3N2M3N2JmZjIxYTUzMDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6InNyeWJRZU1hb1Z2bHB1dXY5V1F4IiwibmFtZSI6IkFudWoiLCJfYXV0aF91c2VyX2lkIjoiMTQ3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI1MzE3NjI1NTMxMDFjZTFkNjI1ZWVhMDUwZGNkOWJlM2YyNzhiNWUzIiwicXVlc3Rpb25zIjpbNzI1LDEwLDc4Myw2MDUsNzYwXSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIxMTIzNTQxfQ==', '2019-09-04 06:40:41.102153'),
('0vy75ncu0luc5dcd0evifpu8o1bnfq2m', 'NjA1Mjc0MDkwMzg4MDBiOWRjZjY5NzlhNDJjYjY0Yzk4MDY0MzAyYTp7Il9hdXRoX3VzZXJfaWQiOiI0NCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYWQwMTBmOTIwYjc0ZTlmOThhOTljNTQwYTcxZjRmOGM5OTlhNTM2OCJ9', '2019-07-18 15:23:01.426375'),
('130zu9ps04k61fd5ik5p0088qn6yze1t', 'MDU0NWYzNjFmYWU2OWU4ZWFlMmJlMDQxNzRiMWE5NDk1YTAxZDNjNjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI2NTMzNmNkZThhNjhjZDY2YzNlYmJjYWYxMjZkZDRlNTExOWE3NDYwIn0=', '2019-07-18 11:44:05.251753'),
('1liujy1uycoe4j0mvacswtaew3stea1s', 'OTNjMjRhNzZjZWQzNjMxMjMzMGQ2MzY1NmMwYTNhZGUwZGMwNjQyMDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6Ikthd1NheE5OQm1qdDdGMGhPaTJsIiwibmFtZSI6IlVzZXIxIiwiX2F1dGhfdXNlcl9pZCI6IjE1MSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZWFjZjg2M2E1ZDA5MDE1MDJiNGVhMTU0ZTI0ZjViZjdhMzI3NGVmMSIsInF1ZXN0aW9ucyI6WzEwLDgyMyw4NzcsNjU0LDkwXSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIxMTQzMzAwfQ==', '2019-09-04 08:38:00.132304'),
('1nq98uvors5ifvqu66c8vtwtc9powoke', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 15:38:44.474962'),
('1o4o46ikott4rg7z7p5c6nukmgm9wara', 'ZTAzMDI4M2NlNDkyZWJmYTM3ZmM0MjgyNDlkYWFjZWM0ZjMzNjc2Yjp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6Ikthd1NheE5OQm1qdDdGMGhPaTJsIiwibmFtZSI6IlVzZXIxIiwiX2F1dGhfdXNlcl9pZCI6IjE3NCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYzRkYzdjODM5MjQ5YjQyODcwNTEyYWFmN2I4ODJhMmU1ZmIwOWQ2NiIsInF1ZXN0aW9ucyI6WzEwLDEsMjA1LDYyMSw1NiwxNDUsMTk2LDcxNSw3Miw3ODgsNTM2XSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIyMTAyOTU2fQ==', '2019-09-05 04:34:56.882589'),
('1zlh2ovocqrec5xkdjzmsxxen3u52eb3', 'NjhkOGRmN2FkMDk1MzIxODk1ZDMwNjBjZGVkZTU1M2MyOTkwYWQ5ODp7Il9hdXRoX3VzZXJfaWQiOiIxMzMiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6ImQ3ZWM4MDY1YTIwZjEzOTI1Y2VmNmNhNzNkMGE3NDc2ZGUzZGI1ZGQifQ==', '2019-09-05 12:14:12.282612'),
('2tskt7yit7kvrgq8mmxnyo78cmsa05ax', 'ZDQ3ZDFkNzAyMDYwMmFlMTg3NGNlYjdiODA3OGFiNTI1ZGY5MTJhMzp7Il9hdXRoX3VzZXJfaWQiOiI1NyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiN2I5NzQ1OGFlNTM0OWZiOWE5ZDk1ZjJhZTdkNGVhNGM2MGM5Mzg5MiJ9', '2019-08-04 15:38:27.630760'),
('39fulc47a5951400s1rf62ae4da0y0ug', 'MDhhZjBjODBmZmNlZjNjNjlkZjgyM2ZkYjg2ZmMxNTExZTY1NTM5YTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTQyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIwZjFiZWZlNzM2YWY3MzQ0ZTQ5ZjY1MzYyYWFiNjdkNzEzZTQxZDM1IiwicXVlc3Rpb25zIjpbMjczLDU4MSwzNjIsMTAsNTgyXSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIxMTE0NDAzfQ==', '2019-09-04 05:49:03.210813'),
('48tysrp6oibvyfbgk1178b43e7bytiq8', 'NzZlYTJiMWM2NGUwZGQ2Y2FmYmYyNDFkY2Q2YWFmNzFlY2Q5Y2VmYTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6IjBIVUFQTkc1dDVsT1JVbmo4VmtkIiwibmFtZSI6InZlZCBiaGF0YXdhZGVrYXIiLCJfYXV0aF91c2VyX2lkIjoiMTYyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIwYmI1MjNhMmQ5ZWU5NjM3MzVlYWEwNjQxODJhYmYxNTUzNTA3MzM1IiwicXVlc3Rpb25zIjpbMTAsODI0LDUxMSw4NDcsNjM3LDQxLDI5Niw4NDksMzIzLDU5NiwzNjZdLCJzY29yZSI6MH0=', '2019-09-04 14:33:21.742937'),
('4c9y7baoonfcf1jzrwnewxbvs0ka5itz', 'YjFmYTNlMDNkMjU1NTA0NTkwMDBiMmI1OWVkOTc0ZTc1YTA1YWU4ODp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJTdWRhcnNoYW4gSG9uIiwiX2F1dGhfdXNlcl9pZCI6IjE5MiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNTNmOGEyMTAxYmE1NGRlNTc0ZjQ3NjU0NmM4MjMyN2M1OWYyYTBlYiIsInF1ZXN0aW9ucyI6WzEwLDEsNzQsNTY4LDI2MCw2OTIsNjY4LDY4LDIwNyw3OSwyNF0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMjIzNDUxNn0=', '2019-09-05 17:50:16.572378'),
('4jkt7eggbtivax4e1w0jqyt4qkfwvxos', 'MTdiMTc1ZmRiOTliMzhhMTcwNGIzYzUyM2FjYjM3MGEzZjE1MjkyYjp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6IkJyTEhjbUJWdVdvdk9JSUJwTWl4IiwibmFtZSI6Inlhc2giLCJfYXV0aF91c2VyX2lkIjoiMTY3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjYTZkYTlmZmIzMWZjYzY5MDdjOWYzMDk2ODk0OTAxZDQzYzdkNDAyIiwicXVlc3Rpb25zIjpbMTAsNjUyLDYyLDgyMywzMTMsNzEyLDQ1LDgxMSw4MzUsNjc3LDU5Nl0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMjAwNTY1NH0=', '2019-09-04 19:01:54.033224'),
('52ouomaarx5od0tp19fdbtk7atvy0w47', 'MDBmNjM4NDBiZDkxNWYzZmFmYmFhMWJiM2U0NmU5NmViMWE3MTQwMDp7InVzZXJpZCI6IlRGVVREV0ZRV2NmV0hCU0VaamEwIiwiX2F1dGhfdXNlcl9pZCI6IjI5IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3YjE0ZTg3NDEyMjZjNDFiZmIxZmY1YzQ1OGRiNmU5YjRlM2NiMDM1IiwicXVlc3Rpb25zIjpbNSwxNzcsNTgzLDQ0NiwzNTYsMzEyXSwic2NvcmUiOjF9', '2019-07-18 12:31:57.185407'),
('5d7u4bge46ikbz9kbhw4fga9504m6ukc', 'MGYyNmM0NmFhMjA4ODRiNmIxODAzOTUzZDBkMTgwMzAwZDdlMmRkNzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-04 10:08:20.238562'),
('5ffk2j2xyyklu1wsfd2ki01lppydo4n2', 'YzJiMzRjMzQ1NTExNjZjNDMwOWZhY2FmYjNmOTI5Mzg3MGQ4YTA3Mzp7Il9hdXRoX3VzZXJfaWQiOiI0MiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMzdlNDlkYWQzYzcyMmRmZDVjOWMyYjlkMjJlMzZmYmQ1ZDg1YWFjYiIsInF1ZXN0aW9ucyI6WzUsNjAzLDU1Nyw3Niw2Miw4NTFdLCJzY29yZSI6MH0=', '2019-07-18 12:49:14.573032'),
('5srba8ah2qt25sw4tyigzty1klib7m2w', 'MjE1YmUwODg5MWUzMThmMjViZmQ3NDRmYjBmZjAxOGFhMDg5OTNkZjp7Il9hdXRoX3VzZXJfaWQiOiIxMCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYjcxN2RhZjEyM2EwNTIzYTZiMWMzZmYwMzJhNmZmZDg5N2IxY2IxNiIsInF1ZXN0aW9ucyI6WzUsNzkwLDc5OSw0MDUsNjAzLDI1MV0sInNjb3JlIjowfQ==', '2019-07-17 15:26:31.525935'),
('5vdwr5088yxdu9d2l0w1tekc0ajdqreu', 'YWY4Zjk5ZGNhZDA5ZWNlOGIxYTcwYmI2OTE2NTFjYmFhYWU0OTIwNTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTUwIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyZjdkMzk1OGYyZTAyYWQ5OTY1OTg5OGM5ZTY0ODBmYTY5NmQ0ZDE3IiwicXVlc3Rpb25zIjpbMTAsODksMzcwLDY4MCwxODRdLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjExMzMwNTF9', '2019-09-04 07:35:51.384969'),
('6ckvg6kh20y5mpj6af9kugr003d7uqgv', 'NjYyNTcwZmYwMjQxY2JmNTcyMGUzNDMxY2JlNTcyY2UxNDg4ZTkxNTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJHdXJ1amkiLCJfYXV0aF91c2VyX2lkIjoiMjA0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI2NDNjZDg4OTdmNWQ0Yjg0Mzg1MDBhZTc0YmY3ZTZhOGRiYjBhY2M3IiwicXVlc3Rpb25zIjpbMTAsMSw3MSwxMDMsMzAyLDU5MywyNTMsNzcsMTM1LDMxMiw4MDRdLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjMwNTAxMDR9', '2019-09-05 23:06:04.531285'),
('6mrvz04lumrazz7j2j1gm7dmxh572jk7', 'ZTkyNTAxOTMzOTcwNTU0MWViMzA5NjVhMjVkMTY2MzM4MDk1NmNkNzp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImJwUGhCZWM3Y2I1T0tzZEpGeEtoIiwibmFtZSI6Im1hbmF2IiwiX2F1dGhfdXNlcl9pZCI6IjEzNSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZGZiZjM2MDVhMjc3ZmQ3NDBiODc3YjE2M2JmNjQzMWNiOWMyNDJkYiIsInF1ZXN0aW9ucyI6Wzc2OCwxNDksODI5LDEwLDg1M10sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMDE4MTA1OH0=', '2019-09-03 12:15:58.449837'),
('6t5e7rg7mkk0maki4gvf9omozq7j8uyo', 'ZDU3NDBjNDI0YmZhOTA3ZDY3MmYxMDA5OWJmMzFiNjJmNGU2N2UwZDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImRUMFk3ejNFUGZLanh6SXFhUEEzIiwibmFtZSI6IlVzZXI0IiwiX2F1dGhfdXNlcl9pZCI6IjE0NSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDg3ODRlMWYzZjU5MTMwOTg3NzNmYTE4NzI3NzYzYzcyZWM4OWUyNiIsInF1ZXN0aW9ucyI6WzUyLDE2NywxMCw2NCw0MjldLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjExMjM1NDB9', '2019-09-04 06:40:40.479376'),
('6uifovek4reqauadfswcafg64zteol0k', 'NDQyNjExOWQ2ZjlkNDQxZTdiYmYzOWMzOTljYmVkZDBjYjVjZjJkZjp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6Ikthd1NheE5OQm1qdDdGMGhPaTJsIiwibmFtZSI6IlVzZXIxIiwiX2F1dGhfdXNlcl9pZCI6IjEzNiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiODVkYmVkY2YwYjM2Y2M5ZDE5YjBiMDU0NDFhNGE2Y2UxZWMxZGY4OCIsInF1ZXN0aW9ucyI6WzM4NCwyNzEsNTM4LDEwLDQ5MF0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMDE4MzcwOH0=', '2019-09-03 12:42:08.941496'),
('6wxptg1qzopcwzj427hd00fthmx83r7e', 'ZmRjM2ZhZjc2NjY0MzgxMDg2MTBmOTFiMGVjZGZkMzRhNDIxZDI2OTp7InF1ZXN0aW9ucyI6WzQ5LDM4MCw0NDQsMTg2LDgxMSw2NTksODIsMzEyLDMzMCwyMTYsMTYxLDgyMSwzNzQsNjI1LDgwNCw2MTksNDYxLDM5MywyMjAsNTcwLDMyMyw2NzcsNjA2LDUwMyw3NzYsNzc0LDUxNiwxNTcsMzY0LDY5NCw1ODEsMzgzLDU1OCw4MTAsNDQsNDgxLDIxNCw1MDMsMjMxLDI5NCw4NDIsNzUzLDYwNyw3MTUsNDMxLDM4NSwyMzcsMTczLDcyOCwzNDFdLCJzY29yZSI6MH0=', '2019-07-31 19:12:10.523242'),
('6zlym8tkbbas7s8qu880hzo8d739u4j2', 'NjVhZTg4YTE2MDdkZjY4YTI2ZWYzYzI1OWM5OTIxMWNhMjc1YjEwZTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6IkpHaUdpa2Nhd3dIbk5Vdm5vM2RqIiwibmFtZSI6IlVzZXIzIiwiX2F1dGhfdXNlcl9pZCI6IjE0OCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiY2FkNmVjMzRhNDVlYzA5N2I5ZDViZjc0NWJjYzg2N2I5ZmM4YTE1NiIsInF1ZXN0aW9ucyI6WzUzOSw2NjksNTg2LDEwLDU3OV0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMTEyMzYwN30=', '2019-09-04 06:41:07.136372'),
('7fa3gjty7o8wbsfdky3ffb1sfnzojgr6', 'ZTgyYTczZTYyMjkzNTc4ZjQwZDdkZWJhNTQ2YTEwMjhmZDBhZTQxNzp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6InRBdng3dmtrdXpNd3hmbTQ1RXh0IiwibmFtZSI6IlVzZXIyIiwiX2F1dGhfdXNlcl9pZCI6IjE0NCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNTA5Y2RiMzE2NTZiNjlkNDM1ZGRhOTcyOTgzMzI5YWRkY2JjNWVhNiIsInF1ZXN0aW9ucyI6WzQxNiw3NzIsMTAsNjM5LDUyM10sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMTEyMzUyOH0=', '2019-09-04 06:40:28.500332'),
('8icjpm5cwmejj93rd0t0npgzbprsbz8z', 'ZDQ3ZDFkNzAyMDYwMmFlMTg3NGNlYjdiODA3OGFiNTI1ZGY5MTJhMzp7Il9hdXRoX3VzZXJfaWQiOiI1NyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiN2I5NzQ1OGFlNTM0OWZiOWE5ZDk1ZjJhZTdkNGVhNGM2MGM5Mzg5MiJ9', '2019-08-04 12:39:33.682526'),
('8ihfvaj1sgizofx8j3z9g0f1odwwh8bf', 'NDgxMWMzNjg0OTEyNDkzYTNiNDQ0Y2NlODFhNjk2NmU2OGI3ZjI5ZDp7InVzZXJpZCI6IkpHaUdpa2Nhd3dIbk5Vdm5vM2RqIiwiX2F1dGhfdXNlcl9pZCI6IjYxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI1MDJkMTQ1NjYxNWNhOWQyOGM4MGViYTg1OGU5OTBjOTQ4ODBmNTZlIiwicXVlc3Rpb25zIjpbNDksMjUwLDQ1OCw3NSw3OTEsNzkyLDU5MiwyOTgsNTM2LDQ4Nyw2MDksNTI4LDc4OCw2ODYsODAyLDc2MywxMTIsMzk5LDc2NiwzMjcsNDk3LDczNCw3Miw0NTQsNTgwLDEzNyw3OTMsNDQ0LDU5Nyw0OTAsNjUxLDIxMiw4NzMsNDcyLDksNTEzLDI3MywzNzksNjc1LDU5LDM5Niw1MjYsMjM3LDY1NCwzMjEsNDUzLDMwNSw4MTQsMTM4LDcxOF0sInNjb3JlIjowfQ==', '2019-07-31 16:47:44.591118'),
('8jrssl597z7d5b2c9h65j0icta1p7l66', 'NTFkOWE5NTgxNjAyNGFlYWQ3NDk1NGRmY2Y3OTQ5YjhmMTY2ZGVhMTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTU4IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0OWVkMmMyOGFiZTVlMzM3M2I2MDY5Yjg1MWNiOTAyNWNjMzEyODI5IiwicXVlc3Rpb25zIjpbMTAsNDIwLDg2MSw5Nyw3NjgsNzQ0LDc4Nyw1OTgsODQwLDUxNiwzMzVdLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjExNzU2MTd9', '2019-09-04 12:01:17.971052'),
('91z2p48ld1rso9mlhcfn1hqwhe7kkljd', 'YTFlNTYwYjg4MWZkMDhjN2IxOGE0ODQ5OTI3MzU2ZmM1MTcwZmRkNzp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6InRBdng3dmtrdXpNd3hmbTQ1RXh0IiwibmFtZSI6IlVzZXIyIiwiX2F1dGhfdXNlcl9pZCI6IjE3MiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMTA5MmYzODBmZGRjOGNhODc2MzRhMTY0ZmVmMmE5YTk0MmEzYjQwNiIsInF1ZXN0aW9ucyI6WzEwLDEsOTAsNTU1LDU4NCw3MDUsODI4LDM5OCw2ODksNTk2LDMwM10sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMjEwMDAxNn0=', '2019-09-05 04:05:16.263797'),
('aszkdvhzf03dctz7ey5woep2n7dwa5kp', 'ZDQ3ZDFkNzAyMDYwMmFlMTg3NGNlYjdiODA3OGFiNTI1ZGY5MTJhMzp7Il9hdXRoX3VzZXJfaWQiOiI1NyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiN2I5NzQ1OGFlNTM0OWZiOWE5ZDk1ZjJhZTdkNGVhNGM2MGM5Mzg5MiJ9', '2019-07-31 13:56:54.632038'),
('aumh0m489i9d2rgmx3kpjonss9i410e3', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 15:26:25.577583'),
('ay314omsfrjuh1cy6s5y80f6d5tl0q3z', 'MmQ3NWQwOWI1N2IxY2JmYWJlYTcxMmM4ODZjN2U3NGE1ZDBiMmE2OTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJOaXJtYXlpIEtlbGthciIsIl9hdXRoX3VzZXJfaWQiOiIxODciLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6ImNjYzJkOTkzMGRmMDc4ODFkZjUxZDM2NTQwYzU0ZDc2MDI4NWY5ZDQiLCJxdWVzdGlvbnMiOlsxMCwxLDgyMywyNyw0MTEsNDgxLDY0OSwzNTgsNTMsMzY2LDcwMV0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMjIxMzUyMH0=', '2019-09-05 15:40:20.576203'),
('b9yqad3n5h7yhulqqb85fijtubrgenil', 'N2E5ZmZkN2ZmZGIzZGVkMDFhMGM3ZmVhMWEzMWY5YTI2NjA1Njc3Mzp7InVzZXJpZCI6IjByUmpBc1VXNkVtM2syQmtPdzV6IiwiX2F1dGhfdXNlcl9pZCI6IjY5IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0ZjBjYjA3YmZmMGM3MDI4YmQyNzZmZTc2ZDA5OGI4ZDdmMThiOTYzIiwicXVlc3Rpb25zIjpbNDksNjE3LDUwNiwxMTYsMjIsMjIwLDEwLDUwOCw3ODUsNTM5LDM0MCw2MjYsMTE3LDQ3Miw0MzQsNDY4LDQyNCwzNDMsNjkzLDY3Miw1MjgsNzIsNzQ4LDM4MCw1NCwyMjcsMzEzLDIxMyw3NjYsNTMsNDA1LDMyNyw4MjIsNTc2LDE5MywzNTgsMTE3LDM1Nyw3NTEsODQwLDQyMiw3NjgsMjg0LDU1OSw2OTMsNjU5LDE2OCw0MDUsODksMjQ2XSwic2NvcmUiOjB9', '2019-07-31 19:16:17.754187'),
('b9yrot6vgb7hwyfetg5jxzf47gbt76qp', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 12:12:30.720509'),
('bejeeqtb94nk5aaphisdobfadiartl9y', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 14:41:23.785270'),
('bv3j643rt7k6cwdz3grbof25r4mt1khp', 'MTgyZDZmMzgzOWRiOTFhYzhlNjU4NTJlZWFhNzk5ZmRjZmZiM2NmODp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6Ikthd1NheE5OQm1qdDdGMGhPaTJsIiwibmFtZSI6IlVzZXIxIiwiX2F1dGhfdXNlcl9pZCI6IjE4MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiN2ZkODUzZDY3NDdjYzNlNDYyNTA5ODM2ZGM5NmJjZGI2MzU5YmJjZiIsInF1ZXN0aW9ucyI6WzEwLDEsMjIwLDc0LDM3NCwyOTcsMzk4LDU5OCwxOTMsMTEzLDUzNF0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMjEwNTQyNX0=', '2019-09-05 04:59:25.041827'),
('bvajs1ttx2j0oswsav6rc7ioydlr0mgp', 'MmRmYzgxY2E5MzIwZWE2OGQ0ZTgxN2IzZmMyZTE2NmY0ZGI5YjMzMjp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6Ikthd1NheE5OQm1qdDdGMGhPaTJsIiwibmFtZSI6IlVzZXIxIiwiX2F1dGhfdXNlcl9pZCI6IjEzNCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZmE4MjE0NWVjOGZjYmEzNzk3ODhhMzA0MTRhZmNhMTcyNTZjNjIxMyIsInF1ZXN0aW9ucyI6WzY2Niw2MDEsNDE5LDEwLDc4XSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIwMTgwOTQwfQ==', '2019-09-03 12:14:40.658184'),
('bykshnl8p21wda67o93ycfo4e6ne8ka2', 'OTU5YWYwODc4YWY3YzUxYWNkNDA3YjQwNTg0NDJhYmIzNjI5N2U4ZDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJHdXJ1amkifQ==', '2019-09-06 01:08:04.847730'),
('c8ha9incisq0lh2975ljvt604wofk6t0', 'Mzg5ZGUyMzc0Y2YwYTRlZTA4YzUwMzg0ZGNhOTU3M2RjOTM5NWY0ZDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6Ikthd1NheE5OQm1qdDdGMGhPaTJsIiwibmFtZSI6IlVzZXIxIiwiX2F1dGhfdXNlcl9pZCI6IjE0MyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiODNjMWI3ZDBhNmE0YzQ1MGRlNzM1N2NkMTk2N2UzNzk3ZmY4NGI1YyIsInF1ZXN0aW9ucyI6WzU1MiwxMCwxNTYsODc2LDIzOV0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMTEyMTM0NX0=', '2019-09-04 06:18:45.241734'),
('cqwzvj5r1p09qxz34w1bl0wzi9n0r5he', 'OTU5YWYwODc4YWY3YzUxYWNkNDA3YjQwNTg0NDJhYmIzNjI5N2U4ZDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJHdXJ1amkifQ==', '2019-09-06 02:07:22.510467'),
('cxw97p4e3veg3261dao9mzgi9qp2x06m', 'OTU5YWYwODc4YWY3YzUxYWNkNDA3YjQwNTg0NDJhYmIzNjI5N2U4ZDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJHdXJ1amkifQ==', '2019-09-06 01:05:35.977716'),
('dggacgrj2lrv797ijky1bqkjff0gu2wq', 'YTA4NWYyMGQ5NjYzYTkwZmZiMWVkZWQzYzdhZWZlYzkwNWMwMWVhODp7InVzZXJpZCI6IjBxUDdIbXNqOHZtTzBwQkZ0ZzFJIiwiX2F1dGhfdXNlcl9pZCI6IjkiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6IjcwM2NjZjZmODJiOGJhZTRiZTNkZTMxOWJhNmNlYWJmZmY3YzRmMzgiLCJxdWVzdGlvbnMiOlsxMCw1MzMsNzc1LDIxNyw1ODIsNzUzLDI4MSw3MDgsNzQxLDczMywyMjZdLCJzY29yZSI6MH0=', '2019-07-17 14:46:50.186936'),
('dqn2ru8nj6bsehng53xuc5v5jb8ynapt', 'NjBmODQ1Nzk0YmRkODk0NTZkZTdmZmQzNDYyNzZiZjM4NWIxZjNiMTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImFtSWp4ZkdJdzd5OU9KbzE2WG1ZIiwibmFtZSI6InJhZ2hhdiIsIl9hdXRoX3VzZXJfaWQiOiIxNDEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6ImI1ZTZmN2Y1MGMyM2ZhOTgzMTJlMGY1NGQ3MTkzY2MxZTY1OGUwNDMiLCJxdWVzdGlvbnMiOlszMCw1MTcsOTksMTMyLDEwXSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIwMjAyMTM2fQ==', '2019-09-03 14:26:36.332790'),
('dwrrph69s73o0fyb4dyw1cpmbiiqt1v3', 'YzVjOGNkNTI5ZmU3YzA5YjkyOTFkMDNlYmU2MTliYzllMzJiOTFjZDp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 18:56:43.090252'),
('e377d1p78c46ppnz1u86jpnn9x3pvgm4', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 21:41:53.703204'),
('e3yewfczhxnje5i4i6jr41se9mcn9k8u', 'YjVmODFiOWNjMzM4ODIyMWQzYTdhNWNkYWJiNDY3ZTVmY2RkNjliYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 04:52:49.378862'),
('es2ql4320pwxt8ht3hidd19ub9b2fwix', 'YWIzOGY2M2EzNDMzZDg3ZjkzNTFkY2I1YWY0NmQzMzliNDZhNTY2NTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJHdXJ1amkiLCJfYXV0aF91c2VyX2lkIjoiMjAyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI1MmU4M2I4NjdmNDYwMzVhZGVjNGMwNjYyMGE1ZGRlNzJjNGMzYzU3In0=', '2019-09-05 22:58:15.599608'),
('f1mzkb2s7x0bv0lbqbq2zi1aamlk2jug', 'MTJmZmJiYzBhY2FhODdkODU2MDZhMTk2OTVhNDg3MzY1OWU4ODEzNzp7InVzZXJpZCI6InRBdng3dmtrdXpNd3hmbTQ1RXh0IiwiX2F1dGhfdXNlcl9pZCI6IjU5IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkYmRmYmNmNmI1YjRmMjY3ZTVmMjZkZGNiOTdlMjBlM2JlNzAyMDNlIiwicXVlc3Rpb25zIjpbNSw4MTQsODIyLDI2Miw1NTAsNDAxXSwic2NvcmUiOjB9', '2019-07-31 14:26:49.233092'),
('fg1bvvofdce3i8z8r420v3h8esl8v6q5', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 14:45:20.081128'),
('fiugcdek4leatj1obh5aug0kcdktdx9c', 'MGFlYjMwYTA4YzBhNTZiODRmODQ1YzUxNjdiOGU0MGViZjYzYmU1ZTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJzYWtzaGkiLCJfYXV0aF91c2VyX2lkIjoiMTk5IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJiODY0OGIzZDQ3ZTMxNjJlNGJmN2Q5N2IxMWRhZTI1YmJiZDk3ZWVjIn0=', '2019-09-05 22:50:45.681582'),
('g3dosry92ez92wfqg9so26qhlat0imks', 'ZmQyOTdkM2U0MDhhOGUyMGQ4NjRkYTYzM2E1NjMzNmYxZDk3NDlmYzp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTcxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJmZmI4Y2IxMmVjZDQwMDJhYjQ0M2MxYzFhYmE3OWE3ODE4NjBhM2U4IiwicXVlc3Rpb25zIjpbMTAsMSw4NiwxMjUsODQ3LDExMCw0NzAsODM5LDUwNSwxNTksNzkwXSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIyMDk1MDUwfQ==', '2019-09-05 03:55:50.238503'),
('greu3k5cmn31asn6tkpskw2fbofb7thx', 'NWNjYjE5YTI1NGMxOTA0YWM3ZmNhOTBmYjczYWUxOTU3ZDIzNzBkYTp7InVzZXJpZCI6IlRGVVREV0ZRV2NmV0hCU0VaamEwIiwiX2F1dGhfdXNlcl9pZCI6IjYyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjMjE4MTkxMDRjMmZmMTQ1OTU0MTYwMjM2YmUzN2U5MWE0Y2NmMTAyIiwicXVlc3Rpb25zIjpbNDksNzg4LDI2NywxNzMsNTAxLDc4MiwzNTcsNjMwLDcyNSw0NzksNzkwLDI2MCw4MzYsNzU1LDgwMSw3NzEsMjQyLDQyNSw4MzYsMjMwLDgzLDQ4Nyw1MDcsMjY5LDczMSwzMzEsNDM2LDM5Miw0NTgsNDA2LDMyOCwzNzQsNDEyLDEzLDg0Miw3NDQsNzkxLDI4OCw0MTQsMjkzLDExNCwyMDYsNzIwLDU2OCwzODksODUwLDQxMCwxMzIsNzA0LDM2XSwic2NvcmUiOjB9', '2019-07-31 18:15:38.501373'),
('gwkpodnuuthcu3iwo0127ryy516r3xkk', 'NmQ0NzFjY2E1NDgwMGY3Y2E1NThiNWNlYTE0MTA0OTRjZTg0MmEwMzp7InF1ZXN0aW9ucyI6WzQ5LDkwLDg0Niw2OTEsNDkxLDgzOSwyOTAsMTg4LDIzNSw1MjcsNDMsNjQ0LDYyLDg0MiwxNTAsNzgxLDU5OCwzODAsNDM1LDE4OSwyNDcsODU3LDU2NSw1OCwyMTMsNjksNjc3LDgzLDcwMCw2NjIsNzgyLDg4LDc4NSw1NzAsNzQ5LDIyLDYxMiwzMzIsODU0LDU3LDE1OSw2ODQsMjYyLDE3Niw2MTEsMzExLDczMCw2MTQsMjMsMzZdLCJzY29yZSI6MH0=', '2019-07-31 19:16:20.738170'),
('h3ldbfkepb0b9id980ms0gfwa3slf8yp', 'MjdiZjY4NmQ3MDFmZmVkNGU5MzNmMzU2NjAzNzE5OGZkODM3MGY1Nzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5MzE3NjljNDJlN2JmNDE2YWM3MzZmNzY2ODQ0NDY0OTAxZGEwZjBiIn0=', '2019-07-15 22:13:31.852363'),
('h5pqc92b75lwz18lfmj0xc9ycclky7hl', 'ZTA2NWRhYzlkNTcyMjcwYTgxMWIwMzM3N2UzNGE5N2RmMDVkMTczOTp7Il9hdXRoX3VzZXJfaWQiOiIyNyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiM2EzOGI1MGMyOTY0NjZlMjk3MTJhY2VhOTQ2YTUwYjI3MGJkOTI3YSIsInF1ZXN0aW9ucyI6WzUsNDI4LDE0MCw3MTcsNTc4LDM5Nl0sInNjb3JlIjowfQ==', '2019-07-18 12:30:20.527883'),
('hbtdtu0l7tdz1kpkdhajkyjb6t3he5yx', 'NWJkOTlkZWE1NDRjN2I4MmM3NTczMDNhYjM2NTZjYTI2YTI3NGM1Yjp7Il9hdXRoX3VzZXJfaWQiOiIzNSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiM2EwNDliNTk1YWQxNjcxMmQ0OGQwNTU5Zjc0ZDU0NTdjNGRjODk1MiIsInF1ZXN0aW9ucyI6WzUsNzMzLDQwNSwyOTgsNzUsMTFdLCJzY29yZSI6MH0=', '2019-07-18 12:35:32.051115'),
('hk8rw39nxmmrqdwrom4f21nd1spzohld', 'NmUxNTcxOWJkMTMyOWE5MjQ0ODNiZGNiNjE4YmM2OTRhNDQxYzExZjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5MzE3NjljNDJlN2JmNDE2YWM3MzZmNzY2ODQ0NDY0OTAxZGEwZjBiIiwiaGVsbG8iOjI5LCJxdWVzdGlvbiI6WzEwLDU4MSwxMzYsODQzLDIxMywxMzMsMzI5LDM2Nyw5NywxNjYsMzM4XX0=', '2019-07-15 07:01:23.334649'),
('hkzs4ki6jqxfxdx62c3hy333lbm8843y', 'N2Q3YmM3ODhiMThiOWYxZTNiNjE5MjM4YzJhNjAyM2U4ZDk1OGQ5Nzp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJHdXJ1amkiLCJfYXV0aF91c2VyX2lkIjoiMjE3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlNTcyYTNjZGIwZGJhMzhjYmJmOWZkYjg5MGE5MjRhNDQxOGI2Y2EwIiwicXVlc3Rpb25zIjpbMTAsMSw0OSw2MSwzMSwyMzQsMTEwLDEyMyw4MCwxOTIsMTg3XSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIzMDY0MTU2fQ==', '2019-09-06 01:10:57.003732'),
('hqx185lnpw120gk6xfhyghwc8tlo4pkp', 'OGZmNGQ3NTU2NzdmOWZiZmIzYWFlZGZlMGZkYjI5MzI2NWRmYjRhMDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTY4IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyMDM0ODY1YjA4NTcyNGI4ZmM0NzU3NzIyNjZhNzczNTRlZDU4YmQxIiwicXVlc3Rpb25zIjpbMTAsMSw5Miw0MTAsMzIyLDU2MCw0ODcsMjI2LDUzNiwzMzksNTg5XSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIyMDEwMjAxfQ==', '2019-09-04 19:07:01.343267'),
('hwcpktzw8t7alsdin9vevrkggxjvry6y', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 22:19:29.918617'),
('i4kvms50qd5db90ctmif9dm7mxbtfiuk', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-06 03:30:18.401069'),
('ighe236t37ajhqu7t5oxys2v2xepqaj9', 'Y2I4ODlhZDgwMGE4ODI0OTFmODgwNTRlYjkyY2U2MWRhNWRkZWI3Zjp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6IjEwdUtvdmZ6cWJ2cm0wZ3dTODJhIiwibmFtZSI6IkRldmFuc2ggTXVuZGFkYSIsIl9hdXRoX3VzZXJfaWQiOiIxNjMiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6IjMzZjdhZWQ0NTlhOGQ4YmZiYTg2NDNhN2M0MmVkMjY1MGUxYzBiZDQiLCJxdWVzdGlvbnMiOlsxMCw4MzcsMjIsNDk4LDQxNSw4NTksMjAxLDczNSwyNzEsNTMwLDU4OV0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMTIwMzcwMn0=', '2019-09-04 14:42:02.388802'),
('iqyjfz9bfq4c3nfefqapjr59f12sqdnv', 'ZGExMWJhYjQyZmRkNzFhMjliM2YwZTFkN2M3YTM1Y2Q0NDIxZTdkOTp7Il9hdXRoX3VzZXJfaWQiOiI1NyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZjkyM2E4NTQzYjJjODJiZWZkYWU5Mzc5OThjYjI1ZmEyMjk4OTI1MSJ9', '2019-08-06 18:16:13.311542'),
('ixz7yb93zxrg0y4zerrkszwao04br1rk', 'MDRjYzhhOTQyOTM5MzY0ZWZhYmJiYzg4ODFiY2NkNjdlZDFkNTAzYjp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIxNWUxMzI4NGZlZDBmZjg4ODEwYzJhMzQ0YTNkM2VlMTg1NDA1YTY2IiwiaGVsbG8iOjMxfQ==', '2019-07-14 20:57:06.351493'),
('jadyodndyqvz5z5roeskn41c27k35evz', 'NjM0Yzk0NzFlMTYwZTEzOGEwMWMwOWM0YWRhZTllNzFiYmQ0OTQwYzp7InVzZXJpZCI6InRBdng3dmtrdXpNd3hmbTQ1RXh0IiwiX2F1dGhfdXNlcl9pZCI6Ijg2IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzMjMwMjY5YzYwNWE0ZmFiMDE1Y2QzMDNiODY2ZmZkZTNlMmFiMTkxIiwicXVlc3Rpb25zIjpbMTAsODc2LDE0MCwyMDksNjgsMjY1LDcyOCwzNzksNTA5LDUzMiw4Nl0sInNjb3JlIjowfQ==', '2019-08-02 16:42:14.690381'),
('jf0ny3js8ilivnwcgg0o628jw50tmhne', 'OTQ5OGE4YTJlY2YyOWJkNDI3ODIzZTYxNTJhNzA3YWVhOGNkMTgyMDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJHdXJ1amkiLCJfYXV0aF91c2VyX2lkIjoiMjAwIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJiY2ZiNWM5YmI5YWRmZWFmNzI0ZGNjOTgwMGQ1OTQ4NTFmZjJjNTg2In0=', '2019-09-05 22:53:51.236646'),
('jgf78xq6qybgdc3j7y37poh0ymaoi08p', 'NmUxNzMyYjc1MjU1Nzk3OWZjZjdiNjAzMTk3ZTA2ZDhlMTJlOTJiYjp7Il9hdXRoX3VzZXJfaWQiOiI0NiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMWM0MDI0NDI3MzhlNGI2MDEzNzJlM2NhMGZiNDJhNDFhZTNjN2E2MiJ9', '2019-07-21 11:52:33.210530'),
('jpppctiorx9ir2n0z37lgvcixugbtak4', 'YzNiZWE3OTAyYjYxM2U4ODNkODUxMmMwZGEyYzRkNWYwZDM1MzI4NTp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIxNWUxMzI4NGZlZDBmZjg4ODEwYzJhMzQ0YTNkM2VlMTg1NDA1YTY2IiwicXVlc3Rpb24iOls1MCwzNDksMjUsMTkwLDU1Niw0OTksMzQxLDc1MSwzNTUsMzk1LDQ5Niw4MzAsNzU5LDMzNyw2NjYsNDM1LDgyNyw4NTYsNzQsMjI0LDI0Miw3NjUsMzU3LDU1NywxNTQsNjMwLDM5Niw2NzEsMTM2LDI5LDE2LDEyLDM4LDI0LDE2Miw4MDMsOCw4MTUsMTIzLDI1OCw2OTUsNDg2LDEyNCwzNjEsNzIxLDUyNywxNzYsNjE4LDExNywyMDEsNDcyXX0=', '2019-07-14 21:08:55.926486'),
('jrxwrul4eahmtwh2nnph3bts5hdt528x', 'ZDYwNmVlNmU2YTEwNzk4MzE5MzY4N2MzMjFjNGRhOGQ5Y2RlMDNmOTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6Ikthd1NheE5OQm1qdDdGMGhPaTJsIiwibmFtZSI6IlVzZXIxIiwiX2F1dGhfdXNlcl9pZCI6IjE0NiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNDA4MTEyN2JiYjgxODFiYjZhOWRhNmMzMzYwYWI4NzZiYjcwMjdlOCIsInF1ZXN0aW9ucyI6WzEwLDU0MCw4NzUsODE3LDMyN10sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMTEyMzU1M30=', '2019-09-04 06:40:53.831917'),
('k5cd1ala90lalaeb24mlhw56gfzl328m', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 21:42:28.303886'),
('k685yutjvxko3rxy88r1shuf41rckimf', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 22:20:27.068832'),
('kggwwfucq3mmq08cenubnwdxav81tga3', 'NjA1Mjc0MDkwMzg4MDBiOWRjZjY5NzlhNDJjYjY0Yzk4MDY0MzAyYTp7Il9hdXRoX3VzZXJfaWQiOiI0NCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYWQwMTBmOTIwYjc0ZTlmOThhOTljNTQwYTcxZjRmOGM5OTlhNTM2OCJ9', '2019-07-20 03:40:20.661862'),
('kz9x007tgn9wpvkaverp64pbk63wgf72', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 21:40:46.093425'),
('l2mm2n4l36dc70omda5zj2hxntcl0vdx', 'NzRiMDRlZGNkMDFiZWI3YmY2MjFjYWZkNWFmZWE1NzExY2Y4ODFhOTp7InVzZXJpZCI6Ikthd1NheE5OQm1qdDdGMGhPaTJsIiwiX2F1dGhfdXNlcl9pZCI6IjY3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJmMDAyOGQ1Y2Q2NWRiYzQ0YmE2ODY2ZTJiNzgwNDhjZmZjMzY1NGUyIiwicXVlc3Rpb25zIjpbNDksNDY0LDUwMywxNzgsNjI5LDg1LDE0Myw1MzgsNDU1LDc3MSw4NCw2MjIsNzkwLDI4MSwxNDIsNTYxLDQ4Niw0ODEsMjk1LDExNiw0MjAsNjYzLDEwOSwyODAsNjMwLDEzNSwxMDksNjMyLDIwNyw0NTEsODEsNTY1LDUwNiw3NDEsNjA2LDM4MSwzOTIsMjY2LDI2Miw4MjQsMzc1LDQxMiwyOTgsNDc1LDc5Myw1NjksMTY3LDc0MywxMDMsNzExXSwic2NvcmUiOjB9', '2019-07-31 19:12:30.896043'),
('lf4odwobm8sz1jpt3c8tn3k28v9vcgm5', 'OTU5YWYwODc4YWY3YzUxYWNkNDA3YjQwNTg0NDJhYmIzNjI5N2U4ZDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJHdXJ1amkifQ==', '2019-09-06 01:03:34.028049'),
('lj7q79u2n9uspr9s5ec0xkmnfx1xn47s', 'YmIxMDU4ZDE1YzY0NzBlZjA5YWZkNTc3ZmNhNTRjYjhmOTc3OTQxNDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJSYW0gQm9ydWRlIiwiX2F1dGhfdXNlcl9pZCI6IjE4OCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiODJmMDRlMjY4OTgyMzFmYjMxYjRiOTFhNjQ4NjU5YTZjMjI0ZmY0ZCIsInF1ZXN0aW9ucyI6WzEwLDEsNjEsNDI0LDc3MiwzMDAsNzc0LDQ1MywzMCw3MTMsNzBdLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjIyMTM4MzF9', '2019-09-05 15:43:31.346554'),
('lx7hx68i04mn5jjw82w3a5cvfps5a4do', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 22:38:14.098554'),
('m0ntsyvhan5ylh5gwoa7975hdyfinw87', 'MWY4YmM4MzA2YzlkY2I2MDNhNWMyYjk5NTJmYmMxYTZmNGVlZTdiYjp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6InNyeWJRZU1hb1Z2bHB1dXY5V1F4IiwibmFtZSI6IkFudWoiLCJfYXV0aF91c2VyX2lkIjoiMTc1IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJiYTExOTIyMjU3MTY0YmU5Mzg5M2IxZjQ4NTkzMTk4MGY3Yzc0M2IxIiwicXVlc3Rpb25zIjpbMTAsMSw3Myw1NjgsMzY5LDYwMyw4NDYsMjIzLDY2LDIzMywzMDNdLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjIxMDM0Mzh9', '2019-09-05 04:39:38.892990'),
('m725euqhe9qfg5e337n0jkubun22k4vn', 'OGViNDBmZjljNmU5Y2FhZmFmNzEzYTc3Nzk5MjZjOGFiN2E4MjRkZTp7InVzZXJpZCI6Ikthd1NheE5OQm1qdDdGMGhPaTJsIiwiX2F1dGhfdXNlcl9pZCI6Ijg0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZTVhOGExNmFjNjVhZjFkODFlZTYyYmYwNjEyMGY5YjNiNjY1OGZiIiwicXVlc3Rpb25zIjpbMTAsNDc0LDY4Nyw2NjYsMTg2LDY5NSw1NzIsMTkzLDczNSwxNzIsODA1XSwic2NvcmUiOjB9', '2019-08-01 17:19:25.812882'),
('mddx7j6sjyjwcsmgsgbkb45y24l1iccg', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 21:48:59.660957'),
('mulveqyn1e4s2hpt9l9f4mskul34txq9', 'OTBkOTJmMmRmZWJiNzg1NmRmYTMzYzMyN2ZlNDA0MjkyZGMzNGRkODp7Il9hdXRoX3VzZXJfaWQiOiI0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJiN2MwMzhlMWYzZjdlMGNhYzU1YmU1NWQ2OTQzZGExNjdlOWExNmJmIiwicXVlc3Rpb24iOls1MCw1MDEsNzk3LDE2NSw1MjQsNjQ2LDYxNSwyODUsMTYzLDYyOSw3MzUsNTA1LDQyNyw3NzQsNzU3LDMzNiwzNyw1NjcsMjQ4LDc2LDUyNCwyMTEsMjMwLDQ3MSw3MTYsNjA1LDYzNSwxNTIsMjI2LDYzNywyMzUsMjgzLDU2OCw0MzAsMjM0LDM2NSw3MSw0MDksNjg0LDY2Miw0NzAsOTUsNTg1LDMzNSwxMyw3MzcsMjI2LDQ5NSwyOTMsNzk2LDcyNV19', '2019-07-15 05:37:37.658341'),
('n8lcvqgk5imjs8ygfbjozjw2b7nolo0f', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 22:14:35.662524'),
('ni0f9glr0b84hht9ko7p1ozkpsi71tfv', 'ZGJkNzEyMWRmM2RhMzFiODNiYzM0NjM0MDI3MzI1YzBmYzA0NDM4Nzp7InVzZXJpZCI6IllFczlXSTRkeHJEek9TeXA2amdtIiwiX2F1dGhfdXNlcl9pZCI6IjE2IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5NzE4ZTM5NzFlZmJmYWRkMTQ1M2M0NTRiNjA4Yzg1MzU5MzEyOTU4IiwicXVlc3Rpb25zIjpbNSwzNTMsNjIzLDc1NCw0OTQsODcxXSwic2NvcmUiOjF9', '2019-07-18 11:45:00.291223'),
('niu2tk3j2g7b68s9052mexgr1t0pjwlz', 'ZDQ3ZDFkNzAyMDYwMmFlMTg3NGNlYjdiODA3OGFiNTI1ZGY5MTJhMzp7Il9hdXRoX3VzZXJfaWQiOiI1NyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiN2I5NzQ1OGFlNTM0OWZiOWE5ZDk1ZjJhZTdkNGVhNGM2MGM5Mzg5MiJ9', '2019-07-31 19:29:41.745543'),
('nuv4x08x2igpwwn1hc8azjrmeasc9ub0', 'MGY0OTM0NzMzZjA5ODExYWI3ODI4Yjg2YzZhOTU5OWYyYjdiYjcxODp7InVzZXJpZCI6IlRGVVREV0ZRV2NmV0hCU0VaamEwIiwiX2F1dGhfdXNlcl9pZCI6IjY2IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJmOTlkM2Y0Y2M5ZDJlZmE0Mzk3MjA0MjRjZTM2ZWFjMTI3N2Y1YWYzIiwicXVlc3Rpb25zIjpbNDksMTgwLDEwOSwzNDEsNzc4LDY2Miw4MjQsNiw1NDcsNzYxLDE5MywyMDgsNjExLDU5LDQ0NSwxNTUsNjAwLDI4MCw0MzQsNzgxLDgyMCwxMiw1NzcsMTYyLDIxOSwyODYsMzQxLDg0NSw3ODIsODMyLDgyNCw4MDUsNDc5LDMyNSw0OTUsMTg5LDg2MSw2MjgsMjg3LDg2Miw3MTksNTk2LDgxMiw2NDgsNzE0LDcyMiwxNyw2NzYsNjkzLDQxMl0sInNjb3JlIjowfQ==', '2019-07-31 19:11:58.783761'),
('o50mfx3jll58h1jcsbav7i3l4289xko6', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 15:35:26.494464'),
('oj6teup2v7lg43u5gdmzx1u62k6epzaq', 'MmM3NWUzZDQ0NmRhNDYwNDc4NjY4ZGZhODZmYzI5MTQ1MDhiOTJmMjp7InVzZXJpZCI6ImFtSWp4ZkdJdzd5OU9KbzE2WG1ZIiwiX2F1dGhfdXNlcl9pZCI6IjI0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3ZmRkN2VhMGYzZGExMjkyMTM5M2ZiYjYzZWIwNTQ1YThhNmEyYzg0IiwicXVlc3Rpb25zIjpbNSwyOTgsNjg2LDYzNSw0NjQsMjk4LDUsNzIyLDYzNSw1NDAsNDQ4LDM4Niw1LDM3MCw4NzcsMzMwLDUxNiw0NjZdLCJzY29yZSI6MX0=', '2019-07-18 12:14:00.764740'),
('oycw393jvpidf1lw763gpshxs5mke494', 'MGYyNmM0NmFhMjA4ODRiNmIxODAzOTUzZDBkMTgwMzAwZDdlMmRkNzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-03 11:30:21.738758'),
('piawcixd4o52sig7f8ni6r26rhab5jzi', 'NzYyOTBjODM3YTIwM2VjMjQzZGQwYWY1NDBhZWQzZGQ2YzQ4NTFmMzp7InVzZXJpZCI6ImJwUGhCZWM3Y2I1T0tzZEpGeEtoIiwiX2F1dGhfdXNlcl9pZCI6IjIwIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIwYTJjMjI2ZGMxOGU2MjYyNjA0YjJkZmRjNTQ1NDRiYTY1NjgxM2M5IiwicXVlc3Rpb25zIjpbMTUsNjIyLDMyOCw3ODIsNjkyLDQ1NCw3NTQsODc3LDU4Miw1MzgsNjc0LDY4OCw3MjAsMzU2LDYzNiw2NjFdLCJzY29yZSI6MjB9', '2019-07-18 12:01:51.088879'),
('pid8ohov375szcmypttekajkruoho8mg', 'MGYyNmM0NmFhMjA4ODRiNmIxODAzOTUzZDBkMTgwMzAwZDdlMmRkNzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-04 05:48:25.929024'),
('pleiykgmm0jsjier5crnf8ydilysgk0d', 'MzU2ZGNlMTQ4OWRkMzA5NzY2YjcyMTdiNzgzOTc0MGQwZTA0YmFkNjp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6IkRqSGxoMG52V25UcTBFc2dxS1ZpIiwibmFtZSI6IkppbmVzaCIsIl9hdXRoX3VzZXJfaWQiOiIxNzAiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6ImM5NTAyNGU0NDRhNDJjYThiZDI4NGMxODQwMjQ3MmI0MWJiMTc2ZTUiLCJxdWVzdGlvbnMiOlsxMCwxLDU1MiwzMTMsMzIyLDc4NSwxNjMsNzA2LDMzOCw1NDYsMzY2XSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIyMDk0ODAxfQ==', '2019-09-05 03:53:01.658253'),
('pybi7bvm2zqahicbkieom1yutgobdsbb', 'ODBlODc4MzljNDNhYmVjOTM3MjdmZWM4MjJjZjk2OTg4MTdhNDI0ZDp7InVzZXJpZCI6IkpHaUdpa2Nhd3dIbk5Vdm5vM2RqIiwiX2F1dGhfdXNlcl9pZCI6IjY4IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhYTU2MTdiZWM5YTkwMWNlMGI5MzRkMDRmNDM0ZjQ4NTMzN2FiNWEyIiwicXVlc3Rpb25zIjpbNDksNjUsMzE2LDMxOSw4NDMsMzM1LDM1OCwyNjEsNjcyLDcsMjI1LDE5MSwzMjQsMzcwLDYyNywxNjgsMzczLDQzNCw3MDgsNzY0LDM0Myw2NjAsNjE2LDg3OCwyMTksNjYsMTA2LDcwOCwyMDIsMzkyLDgyNSwzOTIsMTcwLDcyNyw3MzEsNTUxLDk2LDE1LDgzLDMzMSw1NSw4NjYsODgwLDEzMiwzOTMsNTMyLDQzMSw0NzksMjc3LDIwOF0sInNjb3JlIjowfQ==', '2019-07-31 19:12:59.993059'),
('q39mr7zhwkjtbmhfaj7x4nt5cgm58pig', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 14:52:43.798894'),
('qh0siah385fygk31cqe6punp6lei9xu2', 'NzBhYjEzZTE4NmNiZDhmMDYzOTU3NjM4Y2U5MzQ3MDEwZGE2ZTQzMzp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTgyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhMDk4NTRiY2IzZmY4Y2IyMTU0YzU5ZTI0NDBlNzQyMWE2MTZmZTNmIiwicXVlc3Rpb25zIjpbMTAsMSw2OTMsNTIyLDc3MiwyNjIsMjk3LDUyNSwxMjksMTgwLDgzNV0sInNjb3JlIjowfQ==', '2019-09-05 12:22:17.753531'),
('qyx7so9h1ay6iuyhes6bzwhhxylyx1ip', 'MzRkYmFhY2VmYjg4ODRmZTYwZWMzOTQ5YjFjOGFkZDA0MTM3YzA2Njp7InVzZXJpZCI6IllFczlXSTRkeHJEek9TeXA2amdtIiwiX2F1dGhfdXNlcl9pZCI6IjE3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzZmNhZDI4NmFmNzUwMGRmZDk2NTg2Y2M4N2I2YzcxMTJiMDhhOGQxIiwicXVlc3Rpb25zIjpbNSwyNTcsNTE4LDY5NSwzNzcsNjE3XSwic2NvcmUiOjR9', '2019-07-18 11:49:44.169710'),
('r5shn9k7k4cez6utasq2yazw1sxn5777', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 23:17:36.585501'),
('rbx7pm5i5aqjd4vftsaap9vvi32otryf', 'N2NhZmY4ZWFjNTIzMmYwOGU4NjNiMGU5NWZhY2E1YzY0ZWNhZTZjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTY0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhY2NkNjBhYWY0MDMxODlmYjQ4ZWIzNDMzNDI1MzUxMzcyODlmY2I4IiwicXVlc3Rpb25zIjpbMTAsNDMsNzMwLDM0NCw0MzQsNDU4LDM1NSwzNzEsNDU5LDU5NiwxOTddLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjEyMzQ5MTd9', '2019-09-04 17:54:17.898216'),
('rgciyo2abo1t8ks4of97p1ykrijmnl55', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 14:42:44.346866'),
('rrk2ttd96144j77s5xzcqprjpzs90col', 'Yjc0YzY3YTBmYTI1N2U2YzllOGIxZDE1MWQ2NmM5NTdmNDQyMGU3Yjp7InVzZXJpZCI6ImFtSWp4ZkdJdzd5OU9KbzE2WG1ZIiwiX2F1dGhfdXNlcl9pZCI6IjMzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIwNzI4MzNmNjk1N2JhMzMyMTVkMWUwNTljYjVlYmE0MDNiZTE5N2M3IiwicXVlc3Rpb25zIjpbNSwyOTUsNDYsNjczLDM5Nyw4MjddLCJzY29yZSI6LTV9', '2019-07-18 12:33:52.691867'),
('s0dhlczu1pihlvotszbjux1rgtuu91gl', 'NDhlMGIzYTE0OWZmODc3NDRkZmEzZDdkMWRhNjA3ZTVmM2RjMzk3OTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJwYXNjMTkxOSIsIl9hdXRoX3VzZXJfaWQiOiIyMjMiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6IjhjMGQzMjdlOTY4OGE1NzYyNWQwNmVkNTQ0NGI2NmUyZjliMTM5MzAiLCJxdWVzdGlvbnMiOls0MCwxLDQyLDcwLDM2LDUzLDI3LDkwLDU1LDU2LDEzLDMsMzUsMzgsNjUsNDUsMyw5NSwxMDQsMTEyLDMyLDIzLDExLDExNywxMTcsNiwyMiwyOSw0LDk4LDc3LDUxLDk5LDc5LDc4LDEwOSw3Niw3OSwxMTEsMTA5LDc1XSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIzMDkwMjI5fQ==', '2019-09-06 03:31:29.865191'),
('t5k5kt5dvbpcx81ua3o22awlbk4wsy24', 'MmFmNDM0ZjFmMDI1ZTJiZmI5NDhmZWRkMTgzYzQ1MzNkNDgwN2FkMTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6InRBdng3dmtrdXpNd3hmbTQ1RXh0IiwibmFtZSI6IlVzZXIyIiwiX2F1dGhfdXNlcl9pZCI6IjE5NCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZDYzM2I1ZTEyM2IwZjZhMDU1YjlhNDczZWFiYTA1NzZmNDcxNTc5YiIsInF1ZXN0aW9ucyI6WzEwLDEsNzgzLDYxOCw4NzcsNjk2LDEyMSw1MjUsMjgsMTcwLDEwNF0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMzAxMDAxOX0=', '2019-09-05 19:05:19.715803'),
('t5u9fstbwh3aznr71qfwxjhoh61qayor', 'YTBmYTk0MzQyMDUyZGE4OGIyYjJjNmNkNmNiZGE4NWMyOGRlZjE5NTp7Il9hdXRoX3VzZXJfaWQiOiIzNCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMGFmYzBlNmZiMGVlNzVlNDRhYjM2NjQ3ZWFhNDI4NTc3MDYyZDE4MiIsInF1ZXN0aW9ucyI6WzUsMzksNjExLDQ5OSw0MjIsMzExXSwic2NvcmUiOjB9', '2019-07-18 12:33:39.933828'),
('u3wuab5cotlor245ykyfrpgvubfv5q5a', 'MzRhYjIwNzY2MmVlMTg1NmYzZjQ4OGRjMDE2ODAxMWI4ZGNjMGM1ODp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTM3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI2NDRjMWQxY2M5ZDcyZDg2NTgzYzM4NmUxN2EwYzgxOWVkNDA4NWM4IiwicXVlc3Rpb25zIjpbMTE0LDcyMSw3NTUsMTAsMzddLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjAxODU1NDR9', '2019-09-03 13:00:44.204373'),
('ujs996rzhtsuax3zfhxedi29u6283s3l', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 14:48:24.503714'),
('upbw54rlos5rkkyykq3ax79fgx7ayf5w', 'YTcyNTQxYWVjNjJhNWViMmZjMTEzZGFjNzRmNTU2ZTM4YzFjOGJiODp7Il9hdXRoX3VzZXJfaWQiOiIxMzMiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6ImM0YWRjYjhjY2Q1NzgzN2M3MGE4Zjk1YzQ2ZTgxNmEwNzEwNjg4YWEifQ==', '2019-09-04 06:28:00.100124'),
('vi93z1freyiqzpfekt2lwvz4p6xsjap9', 'OTQxN2ZlZjc4NDNiMjEwZTk5MTIwZjg3OTY5NTRlMDE2ZTM0YmUxNTp7InVzZXJpZCI6ImJwUGhCZWM3Y2I1T0tzZEpGeEtoIiwiX2F1dGhfdXNlcl9pZCI6IjIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI2NjU0ZWI0NDI3ZTE1ZjQ4NGM1YTY3YWEyNGUwNzU1ZTUyMjRmYmUxIiwicXVlc3Rpb25zIjpbNSwyOTgsNjg2LDYzNSw0NjQsMjk4XSwic2NvcmUiOjZ9', '2019-07-18 12:13:51.586639'),
('vpm3f2xyqh7792yj5z9mfc1udszi15dp', 'MTVmNjNmYjE2MDk2MmY0YjQyNWQyNzhkNTFhZjM5MDlmM2U5YzliMzp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTU3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI2NWY1MjU3ZWNiNmZhMTZjNjIyOTQzNGZkYjAzN2UyZjE3OTQwYzllIiwicXVlc3Rpb25zIjpbMTAsNiwxOTAsMzEzLDYzOCw5MSwzMjQsMzQ2LDM4OSw2NDAsMTU2XSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIxMTc1MzUwfQ==', '2019-09-04 11:58:50.949531'),
('w87e8jihbjuf2m0pw18gk9kp067k8fzj', 'ZmFhYWEyMjdmN2ZlYWQ2Y2EyYTg1MTcwYjdlYjc5ZmYzYWExNmZkMTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTc2IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5MGNhMjJhZjgzNTc5MTZiOTA5YzJhYjNkODc5MWY0OGMzMDcyODg5IiwicXVlc3Rpb25zIjpbMTAsMSw1ODQsMTkwLDI3OSw2NDUsNTU5LDksMzk3LDIwOCw0NzZdLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjIxMDQyNTF9', '2019-09-05 04:47:51.379832'),
('x4cndm8qftx2up7fi45w9113p4frcsnm', 'MDY3YmVjNDI3ZDEzN2Q0ZDM4YTQzYjVjNDBiZGQyMzcyNGM1ZTU0MDp7Il9hdXRoX3VzZXJfaWQiOiIzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkZTQ4ZDhkNTdmYmYyY2I0Nzc0YTgwOTMzN2FjYTU0MmRjMzczYjFmIn0=', '2019-07-14 21:00:36.038990'),
('xhtx05sbqjr8kvp6m9pug43zmi9o1j64', 'NmZhODdjYWUxNmMxZWUyNjgzYzg3YWU4NWVmZmQ1MzI3ZmM0ODk1ZTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTQ5IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJiYWYxNjYyNTg4ZGQ0MjdlMDAyMGVjMmM1MWIzZTA1Mzg1ZjRkMWY0IiwicXVlc3Rpb25zIjpbNjI1LDgyLDEwLDI3MCwyOTVdLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjExMzI1MDR9', '2019-09-04 07:30:04.781620'),
('y0wu3nu7mx1ba8du1zb0c2qc0rm0h2g4', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 22:12:12.833690'),
('yp4rrmxbkz0abfn2b0egk825qjbys5yt', 'OTljZGM4YmQ0OWYyMWYzMmNjNmU0YTljZDI5ZmI4ZGIzNDU3ZjNiMzp7InVzZXJpZCI6ImRUMFk3ejNFUGZLanh6SXFhUEEzIiwiX2F1dGhfdXNlcl9pZCI6Ijc5IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3Yzg4YTdhYWQwM2Q4YjBiNjNhYjkyMDIzYTZjNWIyMDM5YWY5ZWE5IiwicXVlc3Rpb25zIjpbOCw2NTQsMzY4LDEyMyw3MzAsNzcxLDg3Miw3MjksMjEwXSwic2NvcmUiOjB9', '2019-08-01 12:47:21.508309'),
('z2po2th8lyrkdyxog7y0uoz3imxd9fzw', 'YzgwZTc1NGJmNmE4OTA4NTJlNjA2YTMzNDBlNGI0MTcwNDBhMzRlNjp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJHdXJ1amkiLCJfYXV0aF91c2VyX2lkIjoiMjAxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI2ZjE1NGE0NzlkOWM5MDEwZjMzOTAxMjc1YmZlYTMxOTQ2NTQ4YWNjIn0=', '2019-09-05 22:55:44.168496'),
('z80isarhssid8d62tj50nberuz3l30vo', 'MWQ1YmVlYjI0YmM3N2Y4YzM2NGNkZDVjNjI4NWIxZDZlNjljM2FmNzp7InVzZXJpZCI6IlRGVVREV0ZRV2NmV0hCU0VaamEwIiwiX2F1dGhfdXNlcl9pZCI6IjY0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIxYWYyNjlkMDc3Nzc2NTZjYzlkN2M0OWY1NmEyMGE0MzYzNGMyMTFjIiwicXVlc3Rpb25zIjpbNDksNTU2LDQ2NCw4MzgsNDAyLDUzOSw3NzgsNzUyLDQxOSwxMjIsNjQyLDE5Nyw0NjAsNjg1LDM2NSw4OSw4MjgsNzQ0LDUyNiw1MDQsNzA1LDQyOCwxNjIsODE2LDIxLDE2MSw4MDAsMTczLDMzNiwyMDcsNTA0LDE3MCw1NDIsMTY2LDQzMCwzMTYsNDEsODE1LDUwOCwxODMsMzQxLDUwLDQ5Myw3LDQ2LDg2MSw2NDcsNTgyLDUzOSw0MV0sInNjb3JlIjowfQ==', '2019-07-31 18:54:28.324854'),
('zcb1gw6s6wfzfz9iuk96cymki740uwy9', 'OTRhYjVkMzI0MGI1NzcwMjk2ZDk4MzA1YjcwMmJiY2NiMDZmZmY0Yzp7Il9hdXRoX3VzZXJfaWQiOiIxMSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZTIyNzE5MDY1ZTI5MjRhN2Q0YjEzMzY5YmFjNWVjMTlmNTIxMzRhYiIsInF1ZXN0aW9ucyI6WzEsMzMwXSwic2NvcmUiOjB9', '2019-07-17 15:35:27.246150'),
('znt6qughj2od8sruhdk62xn7udazcnfx', 'N2Q2ZWFlMjM5NzhmM2FmOGNiMzk0MWRjOWIzMjNjZTNmMjhiMGNhYzp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6IkpHaUdpa2Nhd3dIbk5Vdm5vM2RqIiwibmFtZSI6IlVzZXIzIiwiX2F1dGhfdXNlcl9pZCI6IjE3MyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMGM5MTZiNWM4NTdlZDNhZDFlNmVjYzFmYmY4MzM0ODZmN2E1N2M5MSIsInF1ZXN0aW9ucyI6WzEwLDEsNDMxLDg4MCwzMDIsMTAsMzQ2LDI1Myw4MDgsMTQyLDMxMV0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMjEwMDUwNn0=', '2019-09-05 04:10:06.224881'),
('zsuy52a4wkryuqd5o1u8jbmxuoy6grs4', 'ZDM2NjYxY2EzZTNkOGM5Yzg0MTMyZjI5NzYwZWRlNWY4NTM1M2IzNTp7Il9hdXRoX3VzZXJfaWQiOiIxMzMiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6ImQ3ZWM4MDY1YTIwZjEzOTI1Y2VmNmNhNzNkMGE3NDc2ZGUzZGI1ZGQiLCJhdXRoZW50aWNhdGUiOiJ5ZXMifQ==', '2019-09-05 23:47:57.271995');

-- --------------------------------------------------------

--
-- Table structure for table `questions_auth`
--

CREATE TABLE `questions_auth` (
  `id` int(11) NOT NULL,
  `mail` longtext NOT NULL,
  `participant1` longtext NOT NULL,
  `tickedid` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `questions_question`
--

CREATE TABLE `questions_question` (
  `id` int(3) DEFAULT NULL,
  `problem` varchar(710) DEFAULT NULL,
  `option_a` varchar(236) DEFAULT NULL,
  `option_b` varchar(208) DEFAULT NULL,
  `option_c` varchar(326) DEFAULT NULL,
  `option_d` varchar(208) DEFAULT NULL,
  `correct_option` varchar(2) DEFAULT NULL,
  `level` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions_question`
--

INSERT INTO `questions_question` (`id`, `problem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `level`) VALUES
(1, 'Which of the following is true about this pointer?', 'It is passed as a hidden argument to all function calls', 'It is passed as a hidden argument to all non-static function calls', 'It is passed as a hidden argument to all static functions', 'None of the above', 'b', 1),
(2, 'What is the use of this pointer?', 'When local variable’s name is same as member’s name, we can access member using this pointer.', 'To return reference to the calling object', 'Can be used for chained function calls on an object', 'All of the above', 'd', 1),
(3, 'Predict the output of following C++ program.\n#include<iostream>\nusing namespace std;\n \nclass Test\n{\nprivate:\n  int x;\npublic:\n  Test(int x = 0) { this->x = x; }\n  void change(Test *t) { this = t; }\n  void print() { cout << \"x = \" << x << endl; }\n};\n \nint main()\n{\n  Test obj(5);\n  Test *ptr = new Test (10);\n  obj.change(ptr);\n  obj.print();\n  return 0;\n}', 'x=15', 'x=10', 'Compiler Error', 'Runtime Error', 'c', 1),
(4, 'Predict the output of following C++ program\n#include<iostream>\nusing namespace std;\n \nclass Test\n{\nprivate:\n  int x;\n  int y;\npublic:\n  Test(int x = 0, int y = 0) { this->x = x; this->y = y; }\n  static void fun1() { cout << \"Inside fun1()\"; }\n  static void fun2() { cout << \"Inside fun2()\"; this->fun1(); }\n};\n \nint main()\n{\n  Test obj;\n  obj.fun2();\n  return 0;\n}', 'Inside fun2() Inside fun1()', 'Inside fun2()', 'Inside fun1() Inside fun2()', 'Compiler Error', 'd', 1),
(5, 'Predict the output of following C++ program?\n#include<iostream>\nusing namespace std;\n \nclass Test\n{\nprivate:\n  int x;\npublic:\n  Test() {x = 0;}\n  void destroy()  { delete this; }\n  void print() { cout << \"x = \" << x; }\n};\n \nint main()\n{\n  Test obj;\n  obj.destroy();\n  obj.print();\n  return 0;\n}', 'x = 0', 'undefined behavior', 'compiler error', 'x = 1', 'b', 1),
(6, 'Which of the following in Object Oriented Programming is supported by Function overloading and default arguments features of C++.', 'Inheritance', 'Polymorphism', 'Encapsulation', 'None of the above', 'b', 1),
(7, 'Output?\n#include<iostream>\nusing namespace std;\n \nint fun(int x = 0, int y = 0, int z)\n{  return (x + y + z); }\n \nint main()\n{\n   cout << fun(10);\n   return 0;\n}', '10', '0', '20', 'Compiler Error', 'd', 1),
(8, 'Which of the following overloaded functions are NOT allowed in C++? 1) Function declarations that differ only in the return type\n    int fun(int x, int y);\n         void fun(int x, int y); \n2) Functions that differ only by static keyword in return type\n    int fun(int x, int y);\n         static int fun(int x, int y); \n3)Parameter declarations that differ only in a pointer * versus an array []\nint fun(int *ptr, int n);\nint fun(int ptr[], int n); \n4) Two parameter declarations that differ only in their default arguments\nint fun( int x, int y); \nint fun( int x, int y = 10); ', 'All of the above', 'All except 2)', 'All except 1)', 'All except 2 and 4', 'a', 1),
(9, 'Predict the output of following C++ program?\ninclude<iostream>\nusing namespace std;\n  \nclass Test\n{\nprotected:\n    int x;\npublic:\n    Test (int i):x(i) { }\n    void fun() const  { cout << \"fun() const \" << endl; }\n    void fun()        {  cout << \"fun() \" << endl;     }\n};\n  \nint main()\n{\n    Test t1 (10);\n    const Test t2 (20);\n    t1.fun();\n    t2.fun();\n    return 0;\n}', 'Compiler Error', 'fun() \nfun() const', 'fun() const \nfun() const', 'fun() \nfun()', 'b', 1),
(10, '// Assume that integers take 4 bytes. \n#include<iostream> \n\n  \n\nusing namespace std;    \n\n  \n\nclass Test \n{ \n\n  static int i; \n\n  int j; \n}; \n\n  \n\nint Test::i; \n\n  \n\nint main() \n{ \n\n    cout << sizeof(Test); \n\n    return 0; \n} ', '4', '8', '6', 'None of these', 'a', 1),
(11, 'Output of following program?\n#include <iostream>\nusing namespace std;\n \nint fun(int=0, int = 0);\n \nint main()\n{\n  cout << fun(5);\n  return 0;\n}\n \nint fun(int x, int y) { return (x+y); }', 'Compiler Error', '5', '0', '10', 'b', 1),
(12, 'What is the output of this C++ program?\n#include \nusing namespace std;\nvoid square (int *x)\n{\n*x = (*x)++ * (*x);\n}\nvoid square (int *x, int *y)\n{\n*x = (*x) * --(*y);\n}\nint main ( )\n{\nint number = 30;\nsquare(&number, &number);\ncout << number;\nreturn 0;\n}', '910', '920', '870', '900', 'c', 1),
(13, '#include<iostream> \n\n  \n\nusing namespace std; \n\nclass Base1 { \n\n public: \n\n     Base1() \n\n     { cout << \" Base1\'s constructor called\" << endl;  } \n}; \n\n  \n\nclass Base2 { \n\n public: \n\n     Base2() \n\n     { cout << \"Base2\'s constructor called\" << endl;  } \n}; \n\n  \n\nclass Derived: public Base1, public Base2 { \n\n   public: \n\n     Derived() \n\n     {  cout << \"Derived\'s constructor called\" << endl;  } \n}; \n\n  \n\nint main() \n{ \n\n   Derived d; \n\n   return 0; \n} \n ', 'Derived’s constructor called\nBase1’s constructor called\nBase2’s constructor called', 'Base1’s constructor called\nBase2’s constructor called\nDerived’s constructor called', 'Derived’s constructor called\nBase2’s constructor called\nBase1’s constructor called', 'Base2’s constructor called\nDerived’s constructor called\nBase1’s constructor called', 'b', 1),
(14, 'Predict the output of following C++ program.\n#include <iostream>\nusing namespace std;\n \nclass Test\n{\n    static int x;\npublic:\n    Test() { x++; }\n    static int getX() {return x;}\n};\n \nint Test::x = 0;\n \nint main()\n{\n    cout << Test::getX() << \" \";\n    Test t[5];\n    cout << Test::getX();\n}', '0 0', '5 5', '0 5', 'Compiler Error', 'c', 1),
(15, '#include<iostream> \n\nusing namespace std; \n \n\nclass A {  \n\n public: \n\n    A(int ii = 0) : i(ii) {} \n\n    void show() { cout << \"i = \" << i << endl;} \n\n private: \n\n    int i; \n}; \n \n\nclass B { \n\n public: \n\n    B(int xx) : x(xx) {} \n\n    operator A() const { return A(x); } \n\n private: \n\n    int x; \n}; \n \n\nvoid g(A a) \n{  a.show(); } \n \n\nint main() { \n\n  B b(10); \n\n  g(b); \n\n  g(20); \n\n  getchar(); \n\n  return 0; \n}  \n ', 'i = 20\ni = 10', 'i=20', 'i = 10\ni = 20', 'None of these', 'c', 1),
(16, '#include <iostream>\nusing namespace std;\n \nclass Player\n{\nprivate:\n    int id;\n    static int next_id;\npublic:\n    int getID() { return id; }\n    Player()  {  id = next_id++; }\n};\nint Player::next_id = 1;\n \nint main()\n{\n  Player p1;\n  Player p2;\n  Player p3;\n  cout << p1.getID() << \" \";\n  cout << p2.getID() << \" \";\n  cout << p3.getID();\n  return 0;\n}', 'Compiler Error', '1 2 3', '2 3 4', '3 3 3', 'b', 1),
(17, '//size of integer is 4 bytes\n#include<iostream> \n\nusing namespace std; \n\n  \n\nclass base { \n\n    int arr[10];      \n}; \n\n  \n\nclass b1: public base { }; \n\n  \n\nclass b2: public base { }; \n\n  \n\nclass derived: public b1, public b2 {}; \n\n  \n\nint main(void) \n{  \n\n  cout<<sizeof(derived); \n\n  getchar(); \n\n  return 0; \n}', '40', '80', '60', 'Can\'t be determined', 'b', 1),
(18, 'Which of the following is true?', 'Static methods cannot be overloaded.', 'Static data members can only be accessed by static methods.', 'Non-static data members can be accessed by static methods.', 'Static methods can only access static members (data and methods)', 'd', 1),
(19, 'Predict the output of following C++ program.\n#include <iostream>\nusing namespace std;\n \nclass A\n{\nprivate:\n    int x;\npublic:\n    A(int _x)  {  x = _x; }\n    int get()  { return x; }\n};\n \nclass B\n{\n    static A a;\npublic:\n   static int get()\n   {  return a.get(); }\n};\n \nint main(void)\n{\n    B b;\n    cout << b.get();\n    return 0;\n}', '0', 'Linker Error: Undefined reference B::a', 'Linker Error: Cannot access static a', 'Linker Error: multiple functions with same name get()', 'b', 1),
(20, '#include<iostream> \n\n  \n\nusing namespace std; \n\nclass P { \n\npublic: \n\n   void print() \n\n   { cout <<\" Inside P\"; } \n}; \n\n  \n\nclass Q : public P { \n\npublic: \n\n   void print() \n\n   { cout <<\" Inside Q\"; } \n}; \n\n  \n\nclass R: public Q { \n}; \n\n  \n\nint main(void) \n{ \n\n  R r; \n\n  \n\n  r.print(); \n\n  return 0; \n} ', 'Inside P', 'Inside Q', 'Inside R\nInside Q', 'Inside P\nInside Q\nInside R', 'b', 1),
(21, 'What is the output :\n\n#include<iostream>\nusing namespace std;\n \nclass Test\n{\nprivate:\n    static int count;\npublic:\n    Test& fun(); \n};\n \nint Test::count = 0;\n \nTest& Test::fun()\n{\n    Test::count++;\n    cout << Test::count << \" \";\n    return *this;\n}\n \nint main()\n{\n    Test t;\n    t.fun().fun().fun().fun();\n    return 0;\n}', 'Compiler Error', '4 4 4 4', '1 1 1 1', '1 2 3 4', 'd', 1),
(22, '#include<iostream> \n#include<stdio.h> \n\n  \n\nusing namespace std; \n\n  \n\nclass Base \n{ \n\npublic: \n\n  Base() \n\n  { \n\n    fun(); //note: fun() is virtual \n\n  } \n\n  virtual void fun() \n\n  { \n\n    cout<<\"\\nBase Function\"; \n\n  } \n}; \n\n  \n\nclass Derived: public Base \n{ \n\npublic: \n\n  Derived(){} \n\n  virtual void fun() \n\n  { \n\n    cout<<\"\\nDerived Function\"; \n\n  } \n}; \n\n  \n\nint main() \n{ \n\n  Base* pBase = new Derived(); \n\n  delete pBase; \n\n  return 0; \n} ', 'Derived Function', 'Base Function', 'Base Function\nDerived Function', 'Derived Function\nBase Function', 'b', 1),
(23, 'Output of following C++ program?\n#include <iostream>\nclass Test\n{\npublic:\n    void fun();\n};\nstatic void Test::fun()   \n{\n    std::cout<<\"fun() is staticn\";\n}\nint main()\n{\n    Test::fun();   \n    return 0;\n}', 'fun() is static', 'Empty Screen', 'Compiler Error', 'Runtime error', 'c', 1),
(24, '#include<iostream> \n\nusing namespace std; \n\nint x;  \n\nint main() \n{ \n\n    int x = 10; \n    cout<< ::x << endl; \n    cout<< x;  \n    return 0; \n} ', '10\n0', '0\n10', '10\n10', '0\n0', 'b', 1),
(25, 'Predict the output of following program.\n#include <iostream>\nusing namespace std;\nclass A\n{\nprotected:\n    int x;\npublic:\n    A() {x = 0;}\n    friend void show();\n};\n \nclass B: public A\n{\npublic:\n    B() : y (0) {}\nprivate:\n    int y;\n};\n \nvoid show()\n{\n    A a;\n    B b;\n    cout << \"The default value of A::x = \" << a.x << \" \";\n    cout << \"The default value of B::y = \" << b.y;\n}', 'Compiler Error in show() because x is protected in class A', 'Compiler Error in show() because y is private in class b', 'The default value of A::x = 0 The default value of B::y = 0', 'Compiler Dependent', 'b', 1),
(26, '\n#include<iostream> \n\nusing namespace std; \n\n  \n\nint x = 10; \n\nvoid fun() \n{ \n\n    int x = 2; \n\n    { \n\n        int x = 1; \n\n        cout << ::x << endl;  \n\n    } \n} \n\n  \n\nint main() \n{ \n\n    fun(); \n\n    return 0; \n}', '1', '2', '10', '0', 'c', 1),
(27, '#include <iostream> \nusing namespace std; \nint a = 90; \n\nint fun(int x, int *y = &a) \n{ \n    *y = x + *y; \n    return x + *y; \n} \n\nint main() \n{ \n\n    int a = 5, b = 10; \n\n\n    a = fun(a); \n\n    cout << a << \" \" << b << endl; \n\n \n    b = fun(::a,&a); \n\n    cout << a << \" \" << b << endl; \n\n    return 0; \n}', '100  10\n195  290', '195 10\n 290 100', '100 290\n195 10', '100 195\n290 10', 'a', 1),
(28, 'Predict the output the of following program.\n#include <iostream>\nusing namespace std;\n \nclass B;\nclass A {\n    int a;\npublic:\n    A():a(0) { }\n    void show(A& x, B& y);\n};\n \nclass B {\nprivate:\n    int b;\npublic:\n    B():b(0) { }\n    friend void A::show(A& x, B& y);\n};\n \nvoid A::show(A& x, B& y) {\n    x.a = 10;\n    cout << \"A::a=\" << x.a << \" B::b=\" << y.b;\n}\n \nint main() {\n    A a;\n    B b;\n    a.show(a,b);\n    return 0;\n}', 'Compiler Error', 'A::a=10 B::b=0', 'A::a=0 B::b=0', 'Runtime error', 'b', 1),
(29, '#include <iostream> \nusing namespace std; \n\nint main() \n{ \n    char *A[] = { \"abcx\", \"dbba\", \"cccc\"}; \n    char var = *(A+1) - *A+1; \n    cout << (*A + var); \n} ', 'bba', 'abb', 'aab', 'aba', 'a', 1),
(30, 'If a function is friend of a class, which one of the following is wrong?', 'A function can only be declared a friend by a class itself.', 'Friend functions are not members of a class, they are associated with it.', 'Friend functions are members of a class.', 'It can have access to all members of the class, even private ones.', 'c', 1),
(31, '#include <iostream> \nusing namespace std; \n\nint main() \n{\n    char a = \'a\', b = \'x\'; \n    char c = (b ^ a >> 1 * 2) +(b && a >> 1 * 2 ); \n    cout<< c; \n}', '97', '12', '29', '0', 'a', 1),
(32, 'Which one of the following is correct, when a class grants friend status to another class?', 'The member functions of the class generating friendship can access the members of the friend class.', 'All member functions of the class granted friendship have unrestricted access to the members of the class granting the friendship.', 'Class friendship is reciprocal to each other.', 'There is no such concept.', 'b', 1),
(33, '#include<iostream> \n\nusing namespace std; \n\nclass Point { \n\nprivate: \n\n    int x; \n\n    int y; \n\npublic: \n\n    Point(int i, int j);  // Constructor \n}; \n\n  \n\nPoint::Point(int i = 0, int j = 0)  { \n\n    x = i; \n\n    y = j; \n\n    cout << \"Constructor called\"; \n} \n\n  \n\nint main() \n{ \n\n   Point t1, *t2; \n\n   return 0; \n} \n ', 'Constructor called', 'No output on screen', 'Compilation Error', 'Runtime Error', 'a', 1),
(34, '#include<iostream> \n\nusing namespace std; \n\n  \n\nclass Point { \n\nprivate: \n\n    int x; \n\n    int y; \n\npublic: \n\n    Point(int i = 0, int j = 0);    // Normal Constructor \n\n    Point(const Point &t); // Copy Constructor \n}; \n\n  \n\nPoint::Point(int i, int j)  { \n\n    x = i; \n\n    y = j; \n\n    cout << \"Normal Constructor called\\n\"; \n} \n\n  \n\nPoint::Point(const Point &t) { \n\n   y = t.y; \n\n   cout << \"Copy Constructor called\\n\"; \n} \n\n  \n\nint main() \n{ \n\n   Point *t1, *t2; \n\n   t1 = new Point(10, 15); \n\n   t2 = new Point(*t1); \n\n   Point t3 = *t1; \n\n   Point t4; \n\n   t4 = t3; \n\n   return 0; \n} \n \n', 'Normal Constructor called\nCopy Constructor called\nCopy Constructor called\nNormal Constructor called', 'Copy Constructor called\nNormal Constructor called\nNormal Constructor called\nCopy Constructor called', 'Normal Constructor called\nNormal Constructor called\nCopy Constructor called\nCopy Constructor called', 'Copy Constructor called\nCopy Constructor called\nNormal Constructor called\nNormal Constructor called', 'a', 1),
(35, '#include <iostream> \nusing namespace std;\nint a = 2; \n\nint fun(int *a) \n{ \n    ::a *= *a; \n    cout << ::a << endl; \n    return *a; \n} \nint main() \n{ \n    int a = 9; \n    int &x = ::a; \n    ::a += fun(&x); \n    cout << x; \n}', '4\n8', '9\n9', '7\n4', '5\n7', 'a', 1),
(36, '#include<iostream>\n  \nusing namespace std;\nclass Base1 {\n public:\n     Base1()\n     { cout << \" Base1\'s constructor called\" << endl;  }\n};\n  \nclass Base2 {\n public:\n     Base2()\n     { cout << \"Base2\'s constructor called\" << endl;  }\n};\n  \nclass Derived: public Base1, public Base2 {\n   public:\n     Derived()\n     {  cout << \"Derived\'s constructor called\" << endl;  }\n};\n  \nint main()\n{\n   Derived d;\n   return 0;\n}', 'Compiler Dependent', 'Base1′s constructor called\nBase2′s constructor called\nDerived’s constructor called', 'Base2′s constructor called\nBase1′s constructor called\nDerived’s constructor called', 'Compiler Error', 'b', 1),
(37, '#include<iostream> \n\nusing namespace std; \n\n  \n\nclass Point \n{ \n\nprivate: \n\n    int x; \n\n    int y; \n\npublic: \n\n    Point(const Point&p) { x = p.x; y = p.y; } \n\n    void setX(int i) {x = i;} \n\n    void setY(int j) {y = j;} \n\n    int getX() {return x;} \n\n    int getY() {return y;} \n\n    void print() { cout << \"x = \" << getX() << \", y = \" << getY(); } \n}; \n\n  \n\n  \n\nint main() \n{ \n\n    Point p1; \n\n    p1.setX(10); \n\n    p1.setY(20); \n\n    Point p2 = p1; \n\n    p2.print(); \n\n    return 0; \n}', 'Compiler Error in fifth line of main(), ', 'Compiler Error in fourth line of main()', 'Compiler Error in first line of main(),', 'Successfully executed', 'c', 1),
(38, '\n#include<iostream> \n\nusing namespace std; \n\n  \n\nclass Test { \n\n    int value; \n\npublic: \n\n    Test(int v); \n}; \n\n  \n\nTest::Test(int v) { \n\n    value = v; \n} \n\n  \n\nint main() { \n\n    Test t[100]; \n\n    return 0; \n} ', 'Compiler Error', '100', 'Runtime Error', 'None of These', 'a', 1),
(39, 'Output?\n#include <iostream>  \nusing namespace std;\n \nclass Base1 {\n public:\n     ~Base1()  { cout << \" Base1\'s destructor\" << endl; }\n};\n   \nclass Base2 {\n public:\n     ~Base2()  { cout << \" Base2\'s destructor\" << endl; }\n};\n   \nclass Derived: public Base1, public Base2 {\n   public:\n     ~Derived()  { cout << \" Derived\'s destructor\" << endl; }\n};\n   \nint main()\n{\n   Derived d;\n   return 0;\n}', 'Base1\'s destructor\nBase2\'s destructor\nDerived\'s destructor', 'Derived\'s destructor\nBase2\'s destructor\nBase1\'s destructor', 'z', 'Compiler Dependent', 'b', 1),
(40, '\n#include<iostream> \n\nusing namespace std; \n\n  \n\nint main() \n{ \n\n    int *ptr = new int(5); \n\n    cout << *ptr; \n\n    return 0; \n} \n ', '5', 'Compilation Error', 'Runtime Error', 'Memory Allocation error due to use of new operator', 'a', 1),
(41, '\n#include<iostream> \n\nusing namespace std; \n\nint &fun() { \n\n  static int a = 10; \n\n  return a; \n} \n\n  \n\nint main() { \n\n  int &y = fun(); \n\n  y = y +30; \n\n  cout<<fun(); \n\n  return 0; \n}', '40', '10', '30', 'None of These', 'a', 1),
(42, '#include <iostream> \nusing namespace std; \nint main() \n{ \n    int a = b = c = 0; \n    cout << a << \"*\" << b << \"*\" << c; \n    return 0; \n}', '0*0*0', 'Compilation Error', 'No output', 'Run-time Error', 'b', 1),
(43, 'Assume that an integer takes 4 bytes and there is no alignment in following classes, predict the output.\n#include<iostream>\nusing namespace std;\n \nclass base {\n    int arr[10];\n};\n \nclass b1: public base { };\n \nclass b2: public base { };\n \nclass derived: public b1, public b2 {};\n \nint main(void)\n{\n  cout << sizeof(derived);\n  return 0;\n}', '40', '80', '0', '4', 'b', 1),
(44, '\n#include <iostream> \n\nusing namespace std; \n\n  \n\nclass Fraction \n{ \n\nprivate: \n\n    int den; \n\n    int num; \n\npublic: \n\n   void print() { cout << num << \"/\" << den; } \n\n   Fraction() { num = 1; den = 1; } \n\n   int &Den() { return den; } \n\n   int &Num() { return num; } \n}; \n\n  \n\nint main() \n{ \n\n   Fraction f1; \n\n   f1.Num() = 7; \n\n   f1.Den() = 9; \n\n   f1.print(); \n\n   return 0; \n}', '7/9', 'Compilation error in main()', 'Runtime error', 'Compilation error in class', 'a', 1),
(45, '#include<iostream> \n\nusing namespace std; \n\n  \n\nclass Test \n{ \n\npublic: \n\n  Test(); \n}; \n\n  \nTest::Test()  { \n\n    cout<<\"Constructor Called \\n\"; \n} \n\n  \n\nint main() \n{ \n\n    cout<<\"Start \\n\"; \n\n    Test t1(); \n\n    cout<<\"End \\n\"; \n\n    return 0; \n} \n ', 'Start\nEnd', 'End\nStart', 'Start\nConstructor Called\nEnd', 'Compilation Error', 'a', 1),
(46, '#include<iostream>\n  \nusing namespace std;\nclass P {\npublic:\n   void print()  { cout <<\" Inside P\"; }\n};\n  \nclass Q : public P {\npublic:\n   void print() { cout <<\" Inside Q\"; }\n};\n  \nclass R: public Q { };\n  \nint main(void)\n{\n  R r; \n  r.print();\n  return 0;\n}', 'Inside P', 'Inside Q', 'Compiler Error: Ambiguous call to print()', 'None of the above', 'b', 1),
(47, '#include <iostream> \nusing namespace std;\nint main() \n{   \n   int i; \n   for (i=0; i<3; i++); \n   cout << \"hello!\" <<i<<\"\\n\"; \n   return 0;\n}', 'hello!0\nhello!1\nhello!2', 'hello!2', 'hello!\nhello!\nhello!', 'hello!3', 'd', 1),
(48, 'Output?\n#include<iostream>\nusing namespace std;\n \nclass Base {\nprivate:\n     int i, j;\npublic:\n    Base(int _i = 0, int _j = 0): i(_i), j(_j) { }\n};\nclass Derived: public Base {\npublic:\n     void show(){\n        cout<<\" i = \"<<i<<\"  j = \"<<j;\n     }\n};\nint main(void) {\n  Derived d;\n  d.show();\n  return 0;\n}', 'i = 0 j = 0', 'Compiler Error: i and j are private in Base', 'Compiler Error: Could not call constructor of Base', 'Runtime error', 'b', 1),
(49, '#include<iostream> \n\n  \n\nusing namespace std; \n\n  \n\nclass Test { \n\n    int value; \n\npublic: \n\n    Test (int v = 0) {value = v;} \n\n    int getValue() { return value; } \n}; \n\n  \n\nint main() { \n\n    const Test t;   \n\n    cout << t.getValue(); \n\n    return 0; \n}', 'Compiler Error', '0', 'Runtime Error', 'None of These', 'a', 1),
(50, '#include <iostream> \n\nusing namespace std; \n\n  \n\nint fun(int a, int b  = 1, int c =2) \n{ \n\n    return (a + b + c); \n} \n\n  \n\nint main() \n{ \n\n    cout << fun(12, ,2); \n\n    return 0; \n} ', 'Compiler Error in function definition', 'Compiler Error in function call fun(12, ,2)', 'Compiler Error in function return ', 'None of the above', 'b', 1),
(51, '#include<iostream>\nusing namespace std;\n \nclass Base {};\n \nclass Derived: public Base {};\n \nint main()\n{\n    Base *bp = new Derived;\n    Derived *dp = new Base;\n}', 'No Compiler Error', 'Compiler Error in line \"Base *bp = new Derived;\"', 'Compiler Error in line \" Derived *dp = new Base;\"', 'Runtime Error', 'c', 1),
(52, '#include<iostream> \n\nusing namespace std; \n\n  \n/* local variable is same as a member\'s name */\n\nclass Test \n{ \n\nprivate: \n\n    int x; \n\npublic: \n\n    void setX (int x) { Test::x = x; } \n\n    void print() { cout << \"x = \" << x << endl; } \n}; \n\n  \n\nint main() \n{ \n\n    Test obj; \n\n    int x = 40; \n\n    obj.setX(x); \n\n    obj.print(); \n\n    return 0; \n} ', 'Runtime error', 'Compilation error', 'x = 0', 'x = 40', 'd', 1),
(53, '\n#include <iostream> \nusing namespace std; \n\nint main() \n{ \n    int i; \n    i = 1 + (1,4,5,6,3); \n    cout << i; \n    return 0; \n}', '4', '2', '6', '5', 'a', 1),
(54, '#include<iostream>\nusing namespace std;\n \nclass Base\n{\npublic:\n    void show()\n    {\n        cout<<\" In Base \";\n    }\n};\n \nclass Derived: public Base\n{\npublic:\n    int x;\n    void show()\n    {\n        cout<<\"In Derived \";\n    }\n    Derived()\n    {\n        x = 10;\n    }\n};\n \nint main(void)\n{\n    Base *bp, b;\n    Derived d;\n    bp = &d;\n    bp->show();\n    cout << bp->x;    \n    return 0;\n}', 'Compiler Error in line \" bp->show()\"', 'Compiler Error in line \" cout << bp->x\"', 'In Base 10', 'In Derived 10', 'b', 1),
(55, '\n\n   \n#include<iostream> \n\n  \n\nusing namespace std; \n\n  \n\nclass Test { \n\n    int &t; \n\npublic: \n\n    Test (int &x) { t = x; } \n\n    int getT() { return t; } \n}; \n\n  \n\nint main() \n{ \n\n    int x = 20; \n\n    Test t1(x); \n\n    cout << t1.getT() << \" \"; \n\n    x = 30; \n\n    cout << t1.getT() << endl; \n\n    return 0; \n} ', '20 30', '30 20', 'Compiler Error', 'None of These', 'c', 1),
(56, '#include<iostream>\nusing namespace std;\n \nclass Base\n{\npublic:\n    int fun()  { cout << \"Base::fun() called\"; }\n    int fun(int i)  { cout << \"Base::fun(int i) called\"; }\n};\n \nclass Derived: public Base\n{\npublic:\n    int fun() {  cout << \"Derived::fun() called\"; }\n};\n \nint main()\n{\n    Derived d;\n    d.fun(5);\n    return 0;\n}', 'Base::fun(int i) called', 'Derived::fun() called', 'Base::fun() called', 'Compiler Error', 'd', 1),
(57, '#include <iostream> \nusing namespace std; \nint main() \n{ \n    int a = 0, b; \n    b = (a = 50) + 10; \n    cout << a << \"$\" << b; \n    return 0; \n}', '50$60', '0$10', '50$10', 'Compilation Error', 'a', 1),
(58, '#include<iostream> \n\n  \n\nusing namespace std; \n\n  \n\nclass Test { \n\n    int &t; \n\npublic: \n\n    Test (int &x):t(x) {  } \n\n    int getT() { return t; } \n}; \n\n  \n\nint main() { \n\n    int x = 20; \n\n    Test t1(x); \n\n    cout << t1.getT() << \" \"; \n\n    x = 30; \n\n    cout << t1.getT() << endl; \n\n    return 0; \n} ', '20 30', '30 20', 'Compilation Error', 'None of These', 'a', 1),
(59, '\n#include<iostream> \n\nusing namespace std; \n\n  \n\nclass Test  \n{ \n\nprivate: \n\n    int x; \n\n    static int count; \n\npublic: \n\n    Test(int i = 0) : x(i) {} \n\n    Test(const Test& rhs) : x(rhs.x) { ++count;  } \n\n    static int getCount() { return count; } \n}; \n\n  \n\nint Test::count = 0; \n\n  \nTest fun()  \n{ \n\n    return Test(); \n} \n\n  \n\nint main() \n{ \n\n    Test a = fun(); \n\n    cout<< Test::getCount(); \n\n    return 0; \n} \n \n', 'Compilation error', 'Compiler Dependent', 'Runtime error', 'Successfully executed', 'b', 1),
(60, 'class Test1 { \n\n    int y; \n}; \n\n  \n\nclass Test2 { \n\n    int x; \n\n    Test1 t1; \n\npublic: \n\n    operator Test1() { return t1; } \n\n    operator int() { return x; } \n}; \n\n  \n\nvoid fun ( int x)  { }; \n\nvoid fun ( Test1 t ) { }; \n\n  \n\nint main() { \n\n    Test2 t; \n\n    fun(t); \n\n    return 0; \n} ', 'Compilation Error', 't1', 't2', 'None of These', 'a', 1),
(61, '#include<iostream> \nusing namespace std; \n\nint main(int x) \n{ \n    static int i = 5; \n    if (--i) \n    {\n        cout << i; \n        main(10); \n    } \n    return 0; \n}', '4321', '5', 'Compilation Error', '100', 'a', 1),
(62, '#include<iostream> \n\nusing namespace std; \n\n  \n\nclass A \n{ \n\n    // data members of A \n\npublic: \n\n    A ()           { cout << \"\\n A\'s constructor\"; /* Initialize data members */ } \n\n    A (const A &a) { cout << \"\\n A\'s Copy constructor\";  /* copy data members */} \n\n    A& operator= (const A &a) // Assignemt Operator \n\n    { \n\n        // Handle self-assignment: \n\n        if(this == &a) return *this; \n\n  \n\n        // Copy data members \n\n        cout << \"\\n A\'s Assignment Operator\";  return *this; \n\n    } \n}; \n\n  \n\nclass B \n{ \n\n    A a; \n\n    // Other members of B \n\npublic: \n\n    B(A &a) { this->a = a; cout << \"\\n B\'s constructor\"; } \n}; \n\n  \n\nint main() \n{ \n\n    A a1; \n\n    B b(a1); \n\n    return 0; \n} ', 'Runtime error', ' A\'s constructor\n A\'s constructor\n A\'s Assignment Operator\n B\'s constructor', ' A\'s constructor\n A\'s Copy constructor\n A\'s Assignment Operator\n B\'s constructor', '0', 'b', 1),
(63, '#include<iostream>\nusing namespace std;\n \nclass Base {\npublic:\n    int fun()          {    cout << \"Base::fun() called\";     }\n    int fun(int i)     {   cout << \"Base::fun(int i) called\";  }\n};\n \nclass Derived: public Base  {\npublic:\n    int fun()   {     cout << \"Derived::fun() called\";   }\n};\n \nint main()  {\n    Derived d;\n    d.Base::fun(5);\n    return 0;\n}', 'Compiler Error', 'Base::fun(int i) called', 'Runtime Error', 'Derived::fun() called', 'b', 1),
(64, '#include <iostream> \nusing namespace std; \nint main() \n{ \n    int n = 10; \n    for (int i = 0; i < n; i++ ) \n    { \n        n++; \n        continue; \n        cout<< n; \n    } \n    return 1; \n}', '10', '123456789', 'No output', '12345678910', 'c', 1),
(65, '\n#include<iostream> \n\nusing namespace std; \n\n  \n\nclass A \n{ \n\n    // data members of A \n\npublic: \n\n    A()           { cout << \"\\n A\'s constructor\"; /* Initialize data members */ } \n\n    A(const A &a) { cout << \"\\n A\'s Copy constructor\"; /* Copy data members */ } \n\n    A& operator= (const A &a) // Assignemt Operator \n\n    { \n\n        // Handle self-assignment: \n\n        if(this == &a) return *this; \n\n  \n\n        // Copy data members \n\n        cout << \"\\n A\'s Assignment Operator\";  return *this; \n\n    } \n}; \n\n  \n\nclass B \n{ \n\n    A a; \n\n    // Other members of B \n\npublic: \n\n    B(A &a):a(a) {  cout << \"\\n B\'s constructor\"; } \n}; \n\n  \n\nint main() \n{ \n\n    A a; \n\n    B b(a); \n\n    return 0; \n} \n \n', 'A\'s constructor\n A\'s Copy constructor\nA\'s Assignment Operator ', 'A\'s constructor\nA\'s Assignment Operator \n B\'s constructor', 'A\'s constructor\n A\'s Copy constructor\nA\'s Assignment Operator \n B\'s constructor', 'A\'s constructor\nA\'s Copy constructor\nB\'s constructor', 'd', 1),
(66, 'Output of following program?\n#include <iostream>\n#include<string>\nusing namespace std;\n \nclass Base\n{\npublic:\n    virtual string print() const\n    {\n        return \"This is Base class\";\n    }\n};\n \nclass Derived : public Base\n{\npublic:\n    virtual string print() const\n    {\n        return \"This is Derived class\";\n    }\n};\n \nvoid describe(Base p)\n{\n    cout << p.print() << endl;\n}\n \nint main()\n{\n    Base b;\n    Derived d;\n    describe(b);\n    describe(d);\n    return 0;\n}', 'This is Derived class\nThis is Base class', 'This is Base class\nThis is Derived class', 'This is Base class\nThis is Base class', 'Compiler Error', 'c', 1),
(67, '#include <iostream> \n\nusing namespace std; \n\n  \n\nclass A \n{ \n\n    int id; \n\npublic: \n\n    A (int i) { id = i; } \n\n    void print () { cout << id << endl; } \n}; \n\n  \n\nint main() \n{ \n\n    A a[2]; \n\n    a[0].print(); \n\n    a[1].print(); \n\n    return 0; \n} \n ', 'Compilation error', 'Runtime error', 'Compiler dependent', 'Successfully executed', 'a', 1),
(68, '#include <iostream> \n\nusing namespace std; \n\n  \n\nclass A \n{ \n\n    int id; \n\n    static int count; \n\npublic: \n\n    A() \n\n    { \n\n        count++; \n\n        id = count; \n\n        cout << \"constructor called \" << id << endl; \n\n    } \n\n    ~A() \n\n    { \n\n        cout << \"destructor called \" << id << endl; \n\n    } \n}; \n\n  \n\nint A::count = 0; \n\n  \n\nint main() \n{ \n\n    A a[2]; \n\n    return 0; \n} ', 'constructor called 1\nconstructor called 2\ndestructor called 1\ndestructor called 2', 'constructor called 1\nconstructor called 2\ndestructor called 2\ndestructor called 1', 'constructor called 2\nconstructor called 1\ndestructor called 2\ndestructor called 1', 'constructor called 1\ndestructor called 1\nconstructor called 2\ndestructor called 2', 'b', 1),
(69, '#include<iostream>\nusing namespace std;\n \nclass Base\n{\npublic :\n    int x, y;\npublic:\n    Base(int i, int j){ x = i; y = j; }\n};\n \nclass Derived : public Base\n{\npublic:\n    Derived(int i, int j):x(i), y(j) {}\n    void print() {cout << x <<\" \"<< y; }\n};\n \nint main(void)\n{\n    Derived q(10, 10);\n    q.print();\n    return 0;\n}', '10 10', 'Compiler Error', '0 0', '0 1', 'b', 1),
(70, '\n#include <iostream> \n\nusing namespace std; \n\n  \n\nclass A \n{ \n\n   int aid; \n\npublic: \n\n   A(int x) \n\n   { aid = x; } \n\n   void print() \n\n   { cout << \"A::aid = \" <<aid; } \n}; \n\n  \n\nclass B \n{ \n\n    int bid; \n\npublic: \n\n    static A a; \n\n    B (int i) { bid = i; } \n}; \n\n  \n\nint main() \n{ \n\n  B b(10); \n\n  b.a.print(); \n\n  return 0; \n} \n \n', 'Compilation Error', 'Runtime error', 'Successfully executed', 'Compiler dependent', 'a', 1),
(71, '#include<iostream>\nusing namespace std;\n \nclass Base\n{\nprotected:\n    int a;\npublic:\n    Base() {a = 0;}\n};\n \nclass Derived1:  public Base\n{\npublic:\n    int c;\n};\n \n \nclass Derived2:  public Base\n{\npublic:\n    int c;\n};\n \nclass DerivedDerived: public Derived1, public Derived2\n{\npublic:\n    void show()  {   cout << a;  }\n};\n \nint main(void)\n{\n    DerivedDerived d;\n    d.show();\n    return 0;\n}', 'Compiler Error in Line \"cout << a;\"', 'Compiler Error in Line \"class DerivedDerived: public Derived1, public Derived2\"', '0', 'Runtime Error', 'a', 1),
(72, '\n#include <iostream> \n\nusing namespace std; \n\n  \n\nclass A \n{ \n\npublic: \n\n    void print() { cout << \"A::print()\"; } \n}; \n\n  \n\nclass B : private A \n{ \n\npublic: \n\n    void print() { cout << \"B::print()\"; } \n}; \n\n  \n\nclass C : public B \n{ \n\npublic: \n\n    void print() { A::print(); } \n}; \n\n  \n\nint main() \n{ \n\n    C b; \n\n    b.print(); \n} ', 'Memory allocation error', 'Compiler Error', 'Runtime error', 'Undefined reference error', 'b', 1),
(73, '#include <iostream> \nusing namespace std; \nint main() \n{ \n    int n = 10, i; \n    for (i=0; i<n; i++) \n    { \n        n++; \n        cout<< n << endl; \n        goto x; \n    }\nx: \n    do\n    { \n        cout << \"label x\"<< endl; \n        break; \n    } \n    while( 0 ) ; \n    return 1; \n}', '11\nlabel x', 'label x', '11', 'Error', 'a', 1),
(74, '#include<iostream>\nusing namespace std;\n \nclass Base1\n{\npublic:\n    char c;\n};\n \nclass Base2\n{\npublic:\n    int c;\n};\n \nclass Derived: public Base1, public Base2\n{\npublic:\n    void show()  { cout << c; }\n};\n \nint main(void)\n{\n    Derived d;\n    d.show();\n    return 0;\n}', 'Compiler Error in \"cout << c;\"', 'Garbage Value', 'Compiler Error in \"class Derived: public Base1, public Base2\"', '0', 'a', 1),
(75, '#include<iostream> \n\nusing namespace std; \n\n  \n\nclass base \n{ \n\npublic: \n\n    virtual void show()  { cout<<\" In Base \\n\"; } \n}; \n\n  \n\nclass derived: public base \n{ \n\n    int x; \n\npublic: \n\n    void show() { cout<<\"In derived \\n\"; } \n\n    derived()   { x = 10; } \n\n    int getX() const { return x;} \n}; \n\n  \n\nint main() \n{ \n\n    derived d; \n\n    base *bp = &d; \n\n    bp->show(); \n\n    cout << bp->getX(); \n\n    return 0; \n} ', 'Compilation error', 'Runtime error', 'No errors', 'Compiler dependent ', 'a', 1),
(76, 'Consider the below C++ program.\n#include<iostream>\nusing namespace std;\nclass A\n{\npublic:\n     A(){ cout <<\"1\";}\n     A(const A &obj){ cout <<\"2\";}\n};\n \nclass B: virtual A\n{\npublic:\n    B(){cout <<\"3\";}\n    B(const B & obj){cout<<\"4\";}\n};\n \nclass C: virtual A\n{\npublic:\n   C(){cout<<\"5\";}\n   C(const C & obj){cout <<\"6\";}\n};\n \nclass D:B,C\n{\npublic:\n    D(){cout<<\"7\";}\n    D(const D & obj){cout <<\"8\";}\n};\n \nint main()\n{\n   D d1;\n   D d(d1);\n}', '2', '4', '6', 'All of the above', 'd', 1),
(77, '\n#include<iostream> \n\nusing namespace std; \n\n  \n\nclass Test \n{ \n\n    int value; \n\npublic: \n\n    Test(int v = 0) { value = v; } \n\n    int getValue()  { return value; } \n}; \n\n  \n\nint main() \n{ \n\n    const Test t; \n\n    cout << t.getValue(); \n\n    return 0; \n} ', 'No Errors', 'Runtime Error', 'Compiler Error', 'Compiler dependent', 'c', 1),
(78, 'When the inheritance is private, the private methods in base class are __________ in the derived class (in C++).', 'inaccessible', 'accessible', 'protected', 'public', 'a', 1),
(79, '#include<iostream> \n\nusing namespace std; \n\n  \n\nclass Base  \n{ \n\npublic: \n\n    int fun()      { cout << \"Base::fun() called\"; } \n\n    int fun(int i) { cout << \"Base::fun(int i) called\"; } \n}; \n\n  \n\nclass Derived: public Base  \n{ \n\npublic: \n\n    int fun(char x)   { cout << \"Derived::fun(char ) called\"; } \n}; \n\n  \n\nint main()  \n{ \n\n    Derived d; \n\n    d.fun(); \n\n    return 0; \n} ', 'Compiler Error', 'Runtime Error', 'Compiler dependent ', 'Successfully executed', 'a', 1),
(80, 'Predict the output of following program\n#include <iostream>\nusing namespace std;\nint main()\n{\n    const char* p = \"12345\";\n    const char **q = &p;\n    *q = \"abcde\";\n    const char *s = ++p;\n    p = \"XYZWVU\";\n    cout << *++s;\n    return 0;\n}', 'Compiler Error', 'c', 'b', 'Garbage Value', 'b', 1),
(81, '\n#include<iostream> \n\nusing namespace std; \n\nclass Base  \n{ \n\n   protected: \n\n      int x; \n\n   public: \n\n      Base (int i){ x = i;} \n}; \n\n  \n\nclass Derived : public Base  \n{ \n\n   public: \n\n      Derived (int i):x(i) { } \n\n      void print() { cout << x ; } \n}; \n\n  \n\nint main() \n{ \n\n    Derived d(10); \n\n    d.print(); \n} \n \n', 'Compiler Dependent', 'No Errors', 'Runtime Error', 'Compiler Error', 'd', 1),
(82, 'In C++, const qualifier can be applied to 1) Member functions of a class 2) Function arguments 3) To a class data member which is declared as static 4) Reference variables', 'Only 1, 2 and 3', 'Only 1, 2 and 4', 'All', 'Only 1, 3 and 4', 'c', 1),
(83, '#include <iostream> \n\nusing namespace std; \n\n  \n\nclass X { \n\nprivate: \n\n  static const int a = 76; \n\npublic: \n\n  static int getA() { return a; } \n}; \n\n  \n\nint main() { \n\n  cout <<X::getA()<<endl; \n\n  return 0; \n} ', '76', 'Nothing will be printed', 'Compilation Error', 'None of These', 'a', 1),
(84, '#include<iostream> \n\nusing namespace std; \n\nclass Base { \n\n   protected: \n\n      int x; \n\n   public: \n\n      Base (int i){ x = i;} \n}; \n\n  \n\nclass Derived : public Base { \n\n   public: \n\n      Derived (int i):Base(i) { } \n\n      void print() { cout << x; } \n}; \n\n  \n\nint main() \n{ \n\n    Derived d(10); \n\n    d.print(); \n} ', 'No Output', 'Compilation Error', '10', 'Runtime error due to invalid access of memory', 'c', 1),
(85, '\n#include <iostream> \n\nusing namespace std; \n\n  \n\nclass A \n{ \n\n    public: \n\n    A& operator=(const A&a) \n\n    { \n\n        cout << \"A\'s assignment operator called\" << endl; \n\n        return *this; \n\n    } \n}; \n\n  \n\nclass B \n{ \n\n    A a[2]; \n}; \n\n  \n\nint main() \n{ \n\n    B b1, b2; \n\n    b1 = b2; \n\n    return 0; \n} ', 'Compilation error ', 'A\'s assignment operator called\nA\'s assignment operator called', 'A\'s assignment operator called', 'No output', 'b', 1),
(86, '\n#include<stdlib.h> \n#include<iostream> \n\n  \n\nusing namespace std; \n\n  \n\nclass Test { \n\npublic: \n\n    void* operator new(size_t size); \n\n    void operator delete(void*); \n\n    Test() { cout<<\"\\n Constructor called\"; } \n\n    ~Test() { cout<<\"\\n Destructor called\"; } \n}; \n\n  \n\nvoid* Test::operator new(size_t size) \n{ \n\n    cout<<\"\\n new called\"; \n\n    void *storage = malloc(size); \n\n    return storage; \n} \n\n  \n\nvoid Test::operator delete(void *p ) \n{ \n\n    cout<<\"\\n delete called\"; \n\n    free(p); \n} \n\n  \n\nint main() \n{ \n\n    Test *m = new Test(); \n\n    delete m; \n\n    return 0; \n} ', 'Runtime Error', 'new called\n Constructor called\n delete called\n Destructor called', 'new called\n delete called\n Constructor called\n Destructor called', 'new called\n Constructor called\n Destructor called\n delete called', 'd', 1),
(87, '#include <iostream> \n\nusing namespace std; \n\n  \n\ntemplate <int N> \n\nclass A { \n\n   int arr[N]; \n\npublic: \n\n   virtual void fun() { cout << \"A::fun()\"; } \n}; \n\n  \n\nclass B : public A<2> { \n\npublic: \n\n   void fun() { cout << \"B::fun()\"; } \n}; \n\n  \n\nclass C : public B { }; \n\n  \n\nint main() { \n\n   A<2> *a = new C; \n\n   a->fun(); \n\n   return 0; \n} \n ', 'A::fun()', 'B::fun()', 'C::fun()', 'Compilation error', 'b', 1),
(88, '#include <iostream> \n\nusing namespace std; \n\n  \n\ntemplate <int i> \n\nint fun() \n{ \n\n   i =20;  \n} \n\n  \n\nint main() { \n\n   fun<4>(); \n\n   return 0; \n} \n ', 'Compiler Error', 'Runtime Error', '20', '4', 'a', 1),
(89, '\n#include <iostream> \n#include <string.h> \n\nusing namespace std; \n\n  \n\nint main() \n{ \n\n    cout << sizeof(\"GeeksforGeeks\") << endl; \n\n    cout << strlen(\"GeeksforGeeks\"); \n\n    return 0; \n}\n ', '13\n14', '13\n13', '14\n13', '14\n14', 'c', 1),
(90, '\n#include <iostream> \n\nusing std::cout; \n\nclass Test \n{ \n\npublic: \n\n    Test(); \n\n    ~Test(); \n}; \nTest::Test() \n{ \n\n    cout << \"Constructor is executed\\n\"; \n} \nTest::~Test() \n{ \n\n    cout << \"Destructor is executed\\n\"; \n} \n\nint main() \n{ \n\n    delete new Test(); \n\n    return 0; \n}\n \n', 'Constructor is executed\nDestructor is executed', 'Constructor is executed', 'Runtime Error', 'Compilation Error', 'a', 1),
(91, '\n#include<iostream> \n\nusing namespace std; \n\n  \n\nclass Test1 \n{ \n\n    int x; \n\npublic: \n\n    void show() {  } \n}; \n\n  \n\nclass Test2 \n{ \n\n    int x; \n\npublic: \n\n    virtual void show() {  } \n}; \n\n  \n\nint main(void) \n{ \n\n    cout<<sizeof(Test1)<<endl; \n\n    cout<<sizeof(Test2)<<endl; \n\n    return 0; \n}', '4\n8', '8\n4', '8', '4', 'a', 1),
(92, '#include <iostream> \n\nusing std::cout; \n\nclass main  \n{ \n\npublic: \n\n    main()  {cout << \"ctor is called\\n\";} \n\n    ~main() {cout << \"dtor is called\\n\";} \n}; \n\nint main()  \n{ \n\n    main m;    \n}', 'Successfully executed', 'Compilation Error', 'Runtime error', 'Compiler dependent', 'b', 1),
(93, '#include<iostream> \n\nusing namespace std; \n\nint main() \n{ \n\n    int x = 1 , y = 1; \n\n    cout << ( ++x  || ++y ) << endl;   // outputs 1; \n\n    cout << x << \" \" << y;             // x = 2 , y = 1; \n\n    return 0; \n} ', '1\n2 2', '1\n1 2', '1\n1 1', '1\n2 1', 'd', 1),
(94, '\n#include<iostream> \n\nusing namespace std; \n\nint main() \n{ \n\n    int x = 1 , y = 1; \n\n    cout << ( ++x && ++y ) << endl;     //outputs 1; \n\n    cout << x << \" \" << y;              // x = 2 , y = 2; \n\n    return 0; \n} ', '1\n2 2', '1\n1 1', '1\n1 2', '1\n2 1', 'a', 1),
(95, 'Predict the output of following program.\n#include <iostream>\nusing namespace std;\nclass Point\n{\n    int x, y;\npublic:\n Point(int i = 0, int j =0)\n   { x = i; y = j;  }\n   int getX() const { return x; }\n   int getY() {return y;}\n};\n \nint main()\n{\n    const Point t;\n    cout << t.getX() << \" \";\n    cout << t.gety();\n    return 0;\n}', 'Garbage Values', '0 0', 'Compiler Error in line cout << t.getX() << \" \";', 'Compiler Error in line cout << t.gety();', 'd', 1),
(96, NULL, '1\n2 1 1', '1\n1 1 1', '1 \n1 2 1', '1 \n2 2 1', 'a', 1),
(97, '#include <stdio.h>\nint main()\n{\n   const int x;\n   x = 10;\n   printf(\"%d\", x);\n   return 0;\n}', 'Compiler Error', '10', '0', 'Runtime Error', 'a', 1),
(98, '#include <iostream> \nusing namespace std; \nint main() \n{ \n    int choice = 1 ; \n    switch(choice) \n    { \n        cout << \"\\nFirst Statement\"; \n    case 1 : \n        cout << \"\\nInside Switch case 1\"; \n    case 2 : \n        cout << \"\\nInside Switch case 2\"; \n        break;\n    case 3 : \n        cout << \"\\nInside Switch case 3\"; \n        break; \n    default: \n        cout << \"bye bye\"; \n    } \n    return(0); \n}', 'Inside Switch case 1\nInside Switch case 2', 'First Statement\nInside Switch case 1\nInside Switch case 2', 'Inside Switch case 1', 'bye bye', 'a', 1),
(99, '#include<stdio.h> \nint main() \n{ \nint n; \nfor(n = 7; n!=0; n--) \nprintf(\"n = %d\", n--); \ngetchar(); \nreturn 0; \n}\n', 'Compilation error', 'Execution error', 'Infinite loop', 'Runtime error', 'c', 1),
(100, 'Output of C++ program?\n#include <iostream>\nint const s=9;\nint main()\n{\n    std::cout << s;\n    return 0;\n}', '9', 'Compile time error', '0', 'None of the above', 'a', 1),
(101, '#include <iostream> \nusing namespace std; \nint main() \n{ \n    cout << sizeof(\'x\'); \n    cout << sizeof(char);     \n    return 0; \n}', '11', '21', '22', '12', 'a', 1),
(102, '#include<stdio.h> \nint main() \n{ \nprintf(\"%x\", -1<<1); \ngetchar(); \nreturn 0; \n} \n', 'Compiler dependent', 'Compilation error', 'fffffffe ', 'fffe', 'a', 1),
(103, 'How to create a dynamic array of pointers (to integers) of size 10 using new in C++?', 'int *arr = new int *[10];', 'int **arr = new int *[10];', 'int *arr = new int [10];', 'Not Possible', 'b', 1),
(104, '# include <stdio.h> \n# define scanf \"%s Geeks For Geeks \" \nmain() \n{ \nprintf(scanf, scanf); \ngetchar(); \nreturn 0; \n}\n', '%s Geeks For Geeks Geeks For Geeks', 'Compilation error', 'Declaration error', 'No Output', 'a', 1),
(105, 'Which of the following is true about new when compared with malloc. 1) new is an operator, malloc is a function 2) new calls constructor, malloc doesn\'t 3) new returns appropriate pointer, malloc returns void * and pointer needs to typecast to appropriate type.', '1 and 3', '2 and 3', '1 and 2', 'All 1, 2 and 3', 'd', 1),
(106, '#include <iostream> \nusing namespace std; \nint main() \n{ \n    void *ptr1; \n    char *ptr2; \n    ptr2 = ptr1; // statement 1 \n    return 0; \n}', 'Compilation Error ', 'Successfully Executed', 'Run-time error', 'None', 'a', 1),
(107, 'Predict the output?\n#include <iostream>\nusing namespace std;\n \nclass Test \n{\n  int x;\n  Test() { x = 5;}\n};\n \nint main()\n{\n   Test *t = new Test;\n   cout << t->x;\n}', 'Compiler Error', 'Garbage Value', '0', '5', 'a', 1),
(108, '#include <stdlib.h> \n#include <stdio.h> \nenum {false, true}; \nint main() \n{ \nint i = 1; \ndo\n{ \nprintf(\"%d\\n\", i); \ni++; \nif (i < 15) \ncontinue; \n} while (false); \n\ngetchar(); \nreturn 0; \n} \n', 'Infinite loop', '1', '0', 'Runtime error', 'b', 1),
(109, 'char *getString() \n{ \nchar *str = \"Nice test for strings\"; \nreturn str; \n} \n\nint main() \n{ \nprintf(\"%s\", getString()); \ngetchar(); \nreturn 0; \n} \n', 'Nice', 'Compilation error', '“Nice test for strings”', 'Stack Overflow', 'c', 1),
(110, 'What happens when delete is used for a NULL pointer?\nint *ptr = NULL;\ndelete ptr;', 'Compiler Error', 'Run-time Crash', 'No Effect', 'None of the above', 'c', 1),
(111, 'char *getString() \n{ \nchar str[] = \"Will I be printed?\"; \nreturn str; \n} \nint main() \n{ \nprintf(\"%s\", getString()); \ngetchar(); \n} \n', 'Garbage value', 'Will I be printed?', 'Compilation error', 'No Output', 'a', 1),
(112, 'Which of the followings is/are automatically added to every class, if we do not write our own.', 'Non-parameterized Construtor', 'Copy constructor', 'Assignment operator', 'All of the above', 'd', 1),
(113, 'When a copy constructor may be called?', 'When an object of the class is returned by value.', 'When an object of the class is passed (to a function) by value as an argument.\n', 'When an object of the class is passed (to a function) by value as an argument.\n', 'All of the above', 'd', 1),
(114, 'int main() \n{ \nstatic int i=5; \nif(--i){ \nmain(); \nprintf(\"%d \",i); \n} \n} \n', 'Compilation error due to changing value of static variable', '4 3 2 1', '0 0 0 0 ', 'Stack Overflow', 'c', 1),
(115, 'int main() \n{ \nstatic int var = 5; \nprintf(\"%d \",var--); \nif(var) \nmain(); \n} \n', '0 0 0 0 0 ', 'No Output', '5 4 3 2 1', 'Compilation error', 'c', 1),
(116, '#include<iostream>\nusing namespace std;\nclass Point {\n    Point() { cout << \"Constructor called\"; }\n};\n \nint main()\n{\n   Point t1;\n   return 0;\n}', 'Compilation Error', 'Constructor called', 'Run time error', 'No output', 'a', 1),
(117, 'int main() \n{ \nint x; \nprintf(\"%d\",scanf(\"%d\",&x)); \n/* Suppose that input value given \nfor above scanf is 20 */\nreturn 1; \n} \n', '1', '20', '0', 'Compilation error', 'a', 1),
(118, '# include <stdio.h> \nint main() \n{ \nint i=0; \nfor(i=0; i<20; i++) \n{ \nswitch(i) \n{ \ncase 0: \ni+=5; \ncase 1: \ni+=2; \ncase 5: \ni+=5; \ndefault: \ni+=4; \nbreak; \n} \nprintf(\"%d \", i); \n} \n\ngetchar(); \nreturn 0; \n} \n', 'Compilation error ', '16 21', '21 16', 'Runtime error', 'b', 1),
(119, '#include<iostream>\nusing namespace std;\nclass Point {\npublic:\n    Point() { cout << \"Constructor called\";<<\"\\n\" }\n};\n \nint main()\n{\n   Point t1, *t2;\n   return 0;\n}', 'Constructor called\nConstructor called', 'Constructor called', 'Error', 'No output', 'b', 1),
(120, '#include <stdio.h> \nint main() \n{ \nprintf(\"%p\", main); \ngetchar(); \nreturn 0; \n} \n', 'Runtime error ', 'Address of function main', 'Compilation error', 'Invalid reference', 'b', 1),
(121, '#include <stdio.h> \nint main() \n{ \nprintf(\"\\new_c_question\\by\"); \nprintf(\"\\rgeeksforgeeks\"); \n\ngetchar(); \nreturn 0; \n} \n', 'new c questions by\ngeeksforgeeks', 'geeksforgeeks', 'Runtime error', 'Compilation error', 'b', 1),
(122, '#include <stdio.h> \nint main() \n{ \nint i; \ni = 1, 2, 3; \nprintf(\"i = %d\\n\", i); \n\ngetchar(); \nreturn 0; \n} \n', '1', '1 2 3 ', '1\n2\n3', 'None of above', 'a', 1),
(123, '#include <stdio.h> \nint main() \n{ \nint first = 50, second = 60, third; \nthird = first /* Will this comment work? */ + second; \nprintf(\"%d /* And this? */ \\n\", third); \n\ngetchar(); \nreturn 0; \n} \n', 'Runtime error', '110 /* And this? */', 'Compilation error', '110', 'b', 1),
(124, '#include‹stdio.h› \nint main() \n{ \nstruct site \n{ \nchar name[] = \"GeeksforGeeks\"; \nint no_of_pages = 200; \n}; \nstruct site *ptr; \nprintf(\"%d\",ptr->no_of_pages); \nprintf(\"%s\",ptr->name); \ngetchar(); \nreturn 0; \n} \n', 'Runtime error', 'Compiler error', 'Compiler dependent ', 'None of the above', 'b', 1),
(125, 'int main() \n{ \nchar a[2][3][3] = {\'g\',\'e\',\'e\',\'k\',\'s\',\'f\',\'o\', \n\'r\',\'g\',\'e\',\'e\',\'k\',\'s\'}; \nprintf(\"%s \", **a); \ngetchar(); \nreturn 0; \n} \n', 'g', 'gs', 'geeksforgeeks', 'ge', 'c', 1),
(126, 'Which of the following is true about virtual functions in C++.', 'Virtual functions are functions that can be overridden in derived class with the same signature.', 'Virtual functions enable run-time polymorphism in a inheritance hierarchy.', 'If a function is \'virtual\' in the base class, the most-derived class\'s implementation of the function is called according to the actual type of the object referred to, regardless of the declared type of the pointer or reference. In non-virtual functions, the functions are called according to the type of reference or pointer.', 'All of the above', 'd', 1),
(127, 'int main() \n{ \nchar str[]= \"geeks\\nforgeeks\"; \nchar *ptr1, *ptr2; \n\nptr1 = &str[3]; \nptr2 = str + 5; \nprintf(\"%c\", ++*str - --*ptr1 + *ptr2 + 2); \nprintf(\"%s\", str); \n\ngetchar(); \nreturn 0; \n} \n', 'heejs\nforgeeks', 'Compilation error', 'geeksforgeeks', 'geeks\\nforgeeks', 'a', 1),
(128, '\n#include <stdio.h> \nint fun(int n) \n{ \nint i, j, sum = 0; \nfor(i = 1;i<=n;i++) \nfor(j=i;j<=i;j++) \nsum=sum+j; \nreturn(sum); \n} \n\nint main() \n{ \nprintf(\"%d\", fun(15)); \ngetchar(); \nreturn 0; \n} \n', '10', '120', '1', '15', 'b', 1);
INSERT INTO `questions_question` (`id`, `problem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `level`) VALUES
(129, 'Predict output of the following program\n#include<iostream>\nusing namespace std;\n \nclass Base\n{\npublic:\n    virtual void show() { cout<<\" In Base n\"; }\n};\n \nclass Derived: public Base\n{\npublic:\n    void show() { cout<<\"In Derived n\"; }\n};\n \nint main(void)\n{\n    Base *bp = new Derived;\n    bp->show();\n \n    Base &br = *bp;\n    br.show();\n \n    return 0;\n}', 'In Base \nIn Base', 'In Base \nIn Derived', 'In Derived\nIn Derived', 'In Derived\nIn Base', 'c', 1),
(130, '#include <stdio.h> \nint main() \n{ \nint c = 5, no = 1000; \ndo { \nno /= c; \n} while(c--); \n\nprintf (\"%d\\n\", no); \nreturn 0; \n} \n', 'Compiler dependent', 'Runtime error', 'Exception – Divide by zero', 'Compilation error', 'c', 1),
(131, 'Output of following program\n#include<iostream>\nusing namespace std;\n \nclass Base\n{\npublic:\n    virtual void show() { cout<<\" In Base n\"; }\n};\n \nclass Derived: public Base\n{\npublic:\n    void show() { cout<<\"In Derived n\"; }\n};\n \nint main(void)\n{\n    Base *bp, b;\n    Derived d;\n    bp = &d;\n    bp->show();\n    bp = &b;\n    bp->show();\n    return 0;\n}', 'In Base \nIn Base', 'In Base \nIn Derived', 'In Derived\nIn Derived', 'In Derived\nIn Base', 'd', 1),
(132, 'int main() \n{ \nwhile(1){ \nif(printf(\"%d\",printf(\"%d\"))) \nbreak; \nelse\ncontinue; \n} \nreturn 0; \n} \n', 'Can’t be predicted', '%d %d', 'Compilation error', 'Runtime error', 'a', 1),
(133, 'template <class S, class T> class Pair \n{ \n\nprivate: \n\n    S x; \n\n    T y; \n/* ... */\n}; \n\n  \n\ntemplate <class S> class Element \n{ \n\nprivate: \n\n    S x; \n/* ... */\n}; \n\n  \n\nint main () \n{ \n\n    Pair <Element<int>, Element<char>> p; \n\n    return 0; \n} \n ', 'Compiler Error', 'Compiles and runs perfectly', 'Runtime Error', 'None of These', 'a', 1),
(134, '#include<iostream>\nusing namespace std;\n \nclass Point {\npublic:\n    Point() { cout << \"Normal Constructor called\\n\"; }\n    Point(const Point &t) { cout << \"Copy constructor called\\n\"; }\n};\n \nint main()\n{\n   Point *t1, *t2;\n   t1 = new Point();\n   t2 = new Point(*t1);\n   Point t3 = *t1;\n   Point t4;\n   t4 = t3;\n   return 0;\n}', 'Normal Constructor called\nNormal Constructor called\nNormal Constructor called\nCopy Constructor called\nCopy Constructor called\nNormal Constructor called\nCopy Constructor called\n', 'Normal Constructor called\nCopy Constructor called\nCopy Constructor called\nNormal Constructor called\nCopy Constructor called\n', 'Normal Constructor called\nCopy Constructor called\nCopy Constructor called\nNormal Constructor called', 'None of the above', 'c', 1),
(135, 'int main() \n{ \nunsigned int i=10; \nwhile(i-- >= 0) \nprintf(\"%u \",i); \nreturn 0; \n} \n', 'No Output', '9 8 7 6 5 4 3 2 1 0 65535 65534 ….', '9 8 7 6 5 4 3 2 1 0 4294967295 4294967294 ……', 'Machine dependent', 'd', 1),
(136, 'Which of the following is true about pure virtual functions? \n1) Their implementation is not provided in a class where they are declared. \n2) If a class has a pure virtual function, then the class becomes abstract class and an instance of this class cannot be created.', 'Both 1 and 2', 'Only 1', 'Only 2', 'Neither 1 nor 2', 'c', 1),
(137, 'int main() \n{ \nint x,y=2,z,a; \nif ( x = y%2) \nz =2; \na=2; \nprintf(\"%d %d \",z,x); \nreturn 0; \n} \n', 'Compilation error', '< some garbage value of z > 0', 'Runtime error ', '0', 'b', 1),
(138, '#include<iostream>\nusing namespace std;\n \nclass Base\n{\npublic:\n    virtual void show() = 0;\n};\n \nint main(void)\n{\n    Base b;\n    Base *bp;\n    return 0;\n}', 'There are compiler errors in lines \"Base b;\" and \"Base bp;\"', 'There is compiler error in line \"Base b;\"', 'There is compiler error in line \"Base bp;\"', 'No compiler Error', 'b', 1),
(139, '#include <iostream>\nusing namespace std;\nclass Test\n{\npublic:\n      Test() { cout << \"Hello from Test()\\n \"; }\n} a;\n \nint main()\n{\n    cout << \"Main Started\\n \";\n    return 0;\n}', 'Hello from Test()', 'Hello from Test()\nMain Started', 'Main Started\nHello from Test()', 'Main Started', 'b', 1),
(140, '#include<iostream> \n\nusing namespace std; \n\n  \n\nclass Test  \n{ \n\nprivate: \n\n    static int count; \n\npublic: \n\n    static Test& fun(); \n}; \n\n  \n\nint Test::count = 0; \n\n  \nTest& Test::fun()  \n{ \n\n    Test::count++; \n\n    cout<<Test::count<<\" \"; \n\n    return *this; \n} \n\n  \n\nint main()   \n{ \n\n    Test t; \n\n    t.fun().fun().fun().fun(); \n\n    return 0; \n} ', 'Compiler Error', '1 2 3 4', '4 3 2 1', 'None of These', 'a', 1),
(141, '\nint main() \n{ \nint a[10]; \nprintf(\"%d\",*a+1-*a+3); \nreturn 0; \n} \n', '-2', '4', '10', 'Compilation error', 'b', 1),
(142, '#define prod(a,b) a*b \nint main() \n{ \nint x=3,y=4; \nprintf(\"%d\",prod(x+2,y-1)); \nreturn 0; \n} \n', '8', '9', '10', '12', 'c', 1),
(143, '#include<iostream> \n\nusing namespace std; \n\n  \n\nclass Test  \n{ \n\nprivate: \n\n    static int count; \n\npublic: \n\n    Test& fun(); // fun() is non-static now \n}; \n\n  \n\nint Test::count = 0; \n\n  \nTest& Test::fun()  \n{ \n\n    Test::count++; \n\n    cout<<Test::count<<\" \"; \n\n    return *this; \n} \n\n  \n\nint main()   \n{ \n\n    Test t; \n\n    t.fun().fun().fun().fun(); \n\n    return 0; \n} ', '1 2 3 4', 'Compiler Error', 'None Of These', '0 0 0 0 ', 'a', 1),
(144, 'Predict the output of following program.\n#include<iostream>\nusing namespace std;\nclass Base\n{\npublic:\n    virtual void show() = 0;\n};\n \nclass Derived : public Base { };\n \nint main(void)\n{\n    Derived q;\n    return 0;\n}', 'Compiler Error: there cannot be an empty derived class', 'Compiler Error: Derived is abstract', 'No compiler Error', 'None of the above', 'b', 1),
(145, '#include<iostream>\nusing namespace std;\n  \nclass Empty {};\n  \nint main()\n{\n  cout << sizeof(Empty);\n  return 0;\n}', 'a non zero value', '0', 'Error', 'No output', 'a', 1),
(146, '#include<iostream>\nusing namespace std;\n \nclass Base\n{\npublic:\n    virtual void show() = 0;\n};\n \nclass Derived: public Base\n{\npublic:\n    void show() { cout<<\"In Derived n\"; }\n};\n \nint main(void)\n{\n    Derived d;\n    Base &br = d;\n    br.show();\n    return 0;\n}', 'Compiler Error in line \"Base &br = d;\"', 'Empty Output', 'In Derived', 'None of the above', 'c', 1),
(147, '#include<iostream> \n#include<string.h> \n\nusing namespace std; \n\n  \n\nclass String \n{ \n\n    char *p; \n\n    int len; \n\npublic: \n\n    String(const char *a); \n}; \n\n  \n\nString::String(const char *a) \n{ \n\n    int length = strlen(a); \n\n    p = new char[length +1]; \n\n    strcpy(p, a); \n\n    cout << \"Constructor Called \" << endl; \n} \n\n  \n\nint main() \n{ \n\n    String s1(\"Geeks\"); \n\n    const char *name = \"forGeeks\"; \n\n    s1 = name; \n\n    return 0; \n} ', 'Constructor called\nConstructor called', 'Constructor called', 'None Of These', 'Compilation Error', 'a', 1),
(148, 'int main() \n{ \nunsigned int i=65000; \nwhile ( i++ != 0 ); \nprintf(\"%d\",i); \nreturn 0; \n} \n', '65000', '1', 'Runtime error', 'Compilation error', 'b', 1),
(149, '#include<iostream> \n\n  \n\nusing namespace std; \n\n  \n\nclass A \n{ \n\n    public: \n\n    virtual void fun() {cout << \"A\" << endl ;} \n}; \n\nclass B: public A \n{ \n\n    public: \n\n    virtual void fun() {cout << \"B\" << endl;} \n}; \n\nclass C: public B \n{ \n\n    public: \n\n    virtual void fun() {cout << \"C\" << endl;} \n}; \n\n  \n\nint main() \n{ \n\n    A *a = new C; \n\n    A *b = new B; \n\n    a->fun(); \n\n    b->fun(); \n\n    return 0; \n} ', 'C\nB', 'A\nB', 'B\nC', 'B\nA', 'a', 1),
(150, 'class Test {\n    int x; \n};\nint main()\n{\n  Test t;\n  cout << t.x;\n  return 0;\n}', 'Compilation Error', '0', 'Garbage value', 'No output', 'a', 1),
(151, 'Which of the following is true?', 'All objects of a class share all data members of class\n', 'Objects of a class do not share codes of non-static methods, they have their own copy\n', 'Objects of a class do not share non-static members. Every object has its own copy.\n', 'None of the above', 'c', 1),
(152, '#include<iostream>\nusing namespace std;\nclass Base  {\npublic:\n    Base()    { cout<<\"Constructor: Base\"<<endl; }\n    virtual ~Base()   { cout<<\"Destructor : Base\"<<endl; }\n};\nclass Derived: public Base {\npublic:\n    Derived()   { cout<<\"Constructor: Derived\"<<endl; }\n    ~Derived()  { cout<<\"Destructor : Derived\"<<endl; }\n};\nint main()  {\n    Base *Var = new Derived();\n    delete Var;\n    return 0;\n}', 'Constructor: Base\nConstructor: Derived\nDestructor : Derived\nDestructor : Base', 'Constructor: Base\nConstructor: Derived\nDestructor : Base', 'Constructor: Base\nConstructor: Derived\nDestructor : Derived', 'Constructor: Derived\nDestructor : Derived', 'a', 1),
(153, 'int main() \n{ \nint i=0; \nwhile ( +(+i--) != 0) \ni-=i++; \nprintf(\"%d\",i); \nreturn 0; \n} \n', '-1', 'Compilation error', '1', 'Runtime error', 'a', 1),
(154, 'Assume that an integer and a pointer each takes 4 bytes. Also, assume that there is no alignment in objects. Predict the output following program.\n\n\n#include<iostream>\nusing namespace std;\n \nclass Test\n{\n    static int x;\n    int *ptr;\n    int y;\n};\n \nint main()\n{\n    Test t;\n    cout << sizeof(t) << \" \";\n    cout << sizeof(Test *);\n}\n', '12 4', '12 12', '8 4', '8 8', 'c', 1),
(155, 'int main() \n{ \nfloat f=5,g=10; \nenum{i=10,j=20,k=50}; \nprintf(\"%d\\n\",++k); \nprintf(\"%f\\n\",f<<2); \nprintf(\"%lf\\n\",f%g); \nprintf(\"%lf\\n\",fmod(f,g)); \nreturn 0; \n} \n', 'Program will compile', 'Program will not compile and give 3 errors', 'Program will not compile and give 2 errors', 'Program will not compile and give 1 errors', 'b', 1),
(156, 'Predict the output of following C++ program. Assume that there is no alignment and a typical implementation of virtual functions is done by the compiler.\n#include <iostream>\nusing namespace std;\n \nclass A\n{\npublic:\n    virtual void fun();\n};\n \nclass B\n{\npublic:\n   void fun();\n};\n \nint main()\n{\n    int a = sizeof(A), b = sizeof(B);\n    if (a == b) cout << \"a == b\";\n    else if (a > b) cout << \"a > b\";\n    else cout << \"a < b\";\n    return 0;\n}', 'a > b', 'a == b', 'a < b', 'Compiler Error', 'a', 1),
(157, '\nint main() \n{ \nint i=10; \nvoid pascal f(int,int,int); \nf(i++, i++, i++); \nprintf(\" %d\",i); \nreturn 0; \n} \nvoid pascal f(integer :i,integer:j,integer :k) \n{ \nwrite(i,j,k); \n} \n', 'Runtime error', 'Compile time error', 'Invalid reference error', 'No errors', 'b', 1),
(158, '#include<stdio.h> \nint fun(int n, int *fg) \n{ \n   int t, f; \n   if(n <= 1) \n   { \n     *fg = 1; \n      return 1; \n   } \n   t = fun(n-1, fg); \n   f = t + *fg; \n   *fg = t; \n   return f; \n} \nint main( ) \n{ \n  int x = 15; \n  printf ( \"%d\\n\", fun (5, &x)); \n  getchar(); \n  return 0; \n} ', '6', '8', '9', 'Compilation Error', 'b', 1),
(159, '#include <iostream>\nusing namespace std;\n  \nclass A\n{\npublic:\n    virtual void fun() { cout << \"A::fun() \"; }\n};\n  \nclass B: public A\n{\npublic:\n   void fun() { cout << \"B::fun() \"; }\n};\n  \nclass C: public B\n{\npublic:\n   void fun() { cout << \"C::fun() \"; }\n};\n  \nint main()\n{\n    B *bp = new C;\n    bp->fun();\n    return 0;\n}', 'A::fun()', 'B::fun()', 'C::fun()', 'Compiler Error', 'c', 1),
(160, 'A member function can always access the data in __________ , (in C++).', 'the public part of its class', 'the object of which it is a member', 'the private part of its class\n', 'the class of which it is member', 'd', 1),
(161, 'void pascal f(int i,int j,int k) \n{ \nprintf(\"%d %d %d\",i, j, k); \n} \n\nvoid cdecl f(int i,int j,int k) \n{ \nprintf(\"%d %d %d\",i, j, k); \n} \n\nmain() \n{ \nint i=10; \nf(i++,i++,i++); \nprintf(\" %d\\n\",i); \ni=10; \nf(i++,i++,i++); \nprintf(\" %d\",i); \n} \n', 'Compilation error', 'Successfully executed ', 'Compiler dependent', 'Runtime error ', 'c', 1),
(162, 'int fun(char *str1) \n{ \n  char *str2 = str1; \n  while(*++str1); \n  return (str1-str2); \n}     \n  \nint main() \n{ \n  char *str = \"geeksforgeeks\"; \n  printf(\"%d\", fun(str)); \n  getchar(); \n  return 0; \n} ', '12', '13', 'Compiler Error', 'None of These', 'b', 1),
(163, 'Which of the following is not correct for virtual function in C++ ?', 'Must be declared in public section of class.', 'Virtual function can be static.', 'Virtual function should be accessed using pointers.', 'Virtual function is defined in base class.', 'b', 1),
(164, 'Predict the output of following C++ program\n#include<iostream>\nusing namespace std;\n \nclass Base\n{\npublic:\n    virtual void show() { cout<<\" In Base n\"; }\n};\n \nclass Derived: public Base\n{\npublic:\n    void show() { cout<<\"In Derived n\"; }\n};\n \nint main(void)\n{\n    Base *bp = new Derived;\n    bp->Base::show();\n    return 0;\n}', 'In Base', 'In Derived', 'Compiler Error', 'Runtime Error', 'a', 1),
(165, 'int main() \n{ \nint i = 0; \nwhile (i <= 4) \n{ \nprintf(\"%d\", i); \nif (i > 3) \ngoto inside_foo; \ni++; \n} \ngetchar(); \nreturn 0; \n} \n\nvoid foo() \n{ \ninside_foo: \nprintf(\"PP\"); \n} \n', 'Successfully executed', 'Compilation error', 'Runtime error', 'Compiler dependent', 'b', 1),
(166, 'void fun(int *p) \n{ \n  static int q = 10; \n  p = &q; \n}     \n  \nint main() \n{ \n  int r = 20; \n  int *p = &r; \n  fun(p); \n  printf(\"%d\", *p); \n  getchar(); \n  return 0; \n} ', '10', '20', 'None of These', 'Compilation Error', 'b', 1),
(167, '#define a 10 \nint main() \n{ \n#define a 50 \nprintf(\"%d\",a); \n\ngetchar(); \nreturn 0; \n} \n', '10', '50', 'Multiple declarations error', 'Runtime error', 'b', 1),
(168, 'Which of the following is true about templates.\n1) Template is a feature of C++ that allows us to write one code for different data types.\n\n2) We can write one function that can be used for all data types including user defined types. Like sort(), max(), min(), ..etc.\n\n3) We can write one class or struct that can be used for all data types including user defined types. Like Linked List, Stack, Queue ..etc.\n\n4) Template is an example of compile time polymorphism.', '1 and 2', '1, 2 and 3', '1, 2 and 4', '1, 2, 3 and 4', 'd', 1),
(169, 'void fun(int **p) \n{ \n  static int q = 10; \n  *p = &q; \n}     \n  \nint main() \n{ \n  int r = 20; \n  int *p = &r; \n  fun(&p); \n  printf(\"%d\", *p); \n  getchar(); \n  return 0; \n} ', '10', '20', 'None of These', 'Compilation Error', 'a', 1),
(170, 'Predict the output?\n#include <iostream>\nusing namespace std;\n \ntemplate <typename T>\nvoid fun(const T&x)\n{\n    static int count = 0;\n    cout << \"x = \" << x << \" count = \" << count << endl;\n    ++count;\n    return;\n}\n \nint main()\n{\n    fun<int> (1); \n    cout << endl;\n    fun<int>(1); \n    cout << endl;\n    fun<double>(1.1);\n    cout << endl;\n    return 0;\n}', 'x = 1 count = 0\n\nx = 1 count = 1\n\nx = 1.1 count = 0', 'x = 1 count = 0\n\nx = 1 count = 0\n\nx = 1.1 count = 0', 'x = 1 count = 0\n\nx = 1 count = 1\n\nx = 1.1 count = 2', 'Compiler Error', 'a', 1),
(171, 'Inline functions are useful when\n', 'Function is large with many nested loops\n', 'Function has many static variables\n', 'Function is small and we want to avoid function call overhead.\n', 'None of the above\n', 'c', 1),
(172, 'int main() \n{ \nchar str[] = \"geeksforgeeks\"; \nchar *s1 = str, *s2 = str; \nint i; \n\nfor(i = 0; i < 7; i++) \n{ \nprintf(\" %c \", *str); \n++s1; \n} \n\nfor(i = 0; i < 6; i++) \n{ \nprintf(\" %c \", *s2); \n++s2; \n} \n\ngetchar(); \nreturn 0; \n} \n', 'g e e k s f o r g e e k s', 'g', 'g g g g g g g g e e k s f', 'Compiler error', 'c', 1),
(173, '#include<iostream>\nusing namespace std;\nint x = 1;\nvoid fun()\n{\n    int x = 2;\n    {\n        int x = 3;\n        cout << ::x << endl;\n    }\n}\nint main()\n{\n    fun();\n    return 0;\n}', '1', '0', '2', '3', 'a', 1),
(174, 'int main() \n{ \n  char arr[] = \"geeksforgeeks\"; \n  printf(\"%d\", sizeof(arr)); \n  getchar(); \n  return 0; \n} \n', '13', '14', 'Can\'t say', '26', 'b', 1),
(175, 'int main() \n{ \nchar str[] = \"geeksforgeeks\"; \nint i; \nfor(i=0; str[i]; i++) \nprintf(\"\\n%c%c%c%c\", str[i], *(str+i), *(i+str), i[str]); \n\ngetchar(); \nreturn 0; \n} \n', 'Compilation error', 'geeksforgeeks', 'gggg\neeee\neeee\nkkkk\nssss\nffff\noooo\nrrrr\ngggg\neeee\neeee\nkkkk\nssss', 'Stack overflow', 'c', 1),
(176, '#include <iostream>\nusing namespace std;\n \ntemplate <typename T>\nT max(T x, T y)\n{\n    return (x > y)? x : y;\n}\nint main()\n{\n    cout << max(3, 7) << std::endl;\n    cout << max(3.0, 7.0) << std::endl;\n    cout << max(3, 7.0) << std::endl;\n    return 0;\n}', '7\n7.0\n7.0', 'Compiler Error in all cout statements as data type is not specified.', 'Compiler Error in last cout statement as call to max is ambiguous.', 'None of the above', 'c', 1),
(177, 'int main() \n{ \nchar *p; \nprintf(\"%d %d \", sizeof(*p), sizeof(p)); \n\ngetchar(); \nreturn 0; \n} \n', '1 4', 'Compiler dependent ', 'Compilation error', '4 1', 'b', 1),
(178, 'Which of the following is true about inline functions and macros.', 'Inline functions do type checking for parameters, macros don\'t\n', 'Macros are processed by pre-processor and inline functions are processed in later stages of compilation.\n', 'Macros cannot have return statement, inline functions can.\n', 'All of the above', 'd', 1),
(179, 'Output of following program?\n#include <iostream>\nusing namespace std;\n \ntemplate <class T>\nclass Test\n{\nprivate:\n    T val;\npublic:\n    static int count;\n    Test()  {   count++;   }\n};\n \ntemplate<class T>\nint Test<T>::count = 0;\n \nint main()\n{\n    Test<int> a;\n    Test<int> b;\n    Test<double> c;\n    cout << Test<int>::count   << endl;\n    cout << Test<double>::count << endl;\n    return 0;\n}', '0\n0', '1\n1', '2\n1', '1\n0', 'c', 1),
(180, '#include<stdio.h> \nint main() \n{ \nint x = 5, p = 10; \nprintf(\"%*d\", x, p); \n\ngetchar(); \nreturn 0; \n} \n', '5 10', '10', '5', '5 2', 'b', 1),
(181, 'Output of following program? Assume that the size of char is 1 byte and size of int is 4 bytes, and there is no alignment done by the compiler.\n#include<iostream>\n#include<stdlib.h>\nusing namespace std;\n \ntemplate<class T, class U>\nclass A  {\n    T x;\n    U y;\n    static int count;\n};\n \nint main()  {\n   A<char, char> a;\n   A<int, int> b;\n   cout << sizeof(a) << endl;\n   cout << sizeof(b) << endl;\n   return 0;\n}', '6\n12', '2\n8', 'Compiler Error: There can not be more than one template arguments.', '8\n8', 'b', 1),
(182, '#include<iostream>\nusing namespace std;\n \nint x[100];\nint main()\n{\n    cout << x[99] << endl;\n}', 'Garbage Value', '0', '1', '-1', 'b', 1),
(183, 'int main() \n{ \nchar arr[] = \"geeksforgeeks\"; \nchar *ptr = arr; \n\nwhile(*ptr != \'\\0\') \n++*ptr++; \nprintf(\"%s %s\", arr, ptr); \n\ngetchar(); \nreturn 0; \n} \n', 'geeksforgeeks', 'Compiler dependent ', 'hffltgpshfflt', 'Compiler error', 'c', 1),
(184, 'Output of following program? Assume that the size of int is 4 bytes and size of double is 8 bytes, and there is no alignment done by the compiler.\n#include<iostream>\n#include<stdlib.h>\nusing namespace std;\n \ntemplate<class T, class U, class V=double>\nclass A  {\n    T x;\n    U y;\n    V z;\n    static int count;\n};\n \nint main()\n{\n   A<int, int> a;\n   A<double, double> b;\n   cout << sizeof(a) << endl;\n   cout << sizeof(b) << endl;\n   return 0;\n}', '16\n24', '8\n16', '20\n28', 'Compiler Error: template parameters cannot have default values.', 'a', 1),
(185, 'int main() \n{ \nsigned char i=0; \nfor(; i >= 0; i++); \nprintf(\"%d\\n\", i); \n\ngetchar(); \nreturn 0; \n} \n', '127', '-128', '-127', '128', 'b', 1),
(186, '#include <stdio.h> \nvoid fun(const char **p) { } \nint main(int argc, char **argv) \n{ \nfun(argv); \ngetchar(); \nreturn 0; \n} \n', 'Compiler error', 'Runtime error', 'Compiler dependent ', 'No errors', 'a', 1),
(187, 'Output of following program.\n#include <iostream>\nusing namespace std;\n \ntemplate <class T, int max>\nint arrMin(T arr[], int n)\n{\n   int m = max;\n   for (int i = 0; i < n; i++)\n      if (arr[i] < m)\n         m = arr[i];\n \n   return m;\n}\n \nint main()\n{\n   int arr1[]  = {10, 20, 15, 12};\n   int n1 = sizeof(arr1)/sizeof(arr1[0]);\n \n   char arr2[] = {1, 2, 3};\n   int n2 = sizeof(arr2)/sizeof(arr2[0]);\n \n   cout << arrMin<int, 10000>(arr1, n1) << endl;\n   cout << arrMin<char, 256>(arr2, n2);\n   return 0;\n}', 'Compiler error, template argument must be a data type.', '10\n1', '10000\n256', '1\n1', 'b', 1),
(188, 'int main() \n{ \nint c=5; \nprintf(\"%d\\n%d\\n%d\", c, c <<= 2, c >>= 2); \ngetchar(); \n} \n', 'Compilation error', 'Runtime error', 'Compiler dependent ', 'No error ', 'c', 1),
(189, 'int main() \n{ \nchar arr[] = {1, 2, 3}; \nchar *p = arr; \nif(&p == &arr) \nprintf(\"Same\"); \nelse\nprintf(\"Not same\"); \ngetchar(); \n} \n', 'Same', 'Not Same', 'Compilation error', 'Compiler dependent ', 'b', 1),
(190, 'c', '4 4', '4 3', '2 3', '3 3', 'b', 1),
(191, 'int x = 0; \nint f() \n{ \nreturn x; \n} \n\nint g() \n{ \nint x = 1; \nreturn f(); \n} \n\nint main() \n{ \nprintf(\"%d\", g()); \nprintf(\"\\n\"); \ngetchar(); \n} \n', '1', '0', '1 0', '0 1', 'b', 1),
(192, 'The associativity of which of the following operators is Left to Right, in C++ ?', 'Unary operator', 'Binary operator', 'Array element access', 'logical not', 'c', 1),
(193, '#include<stdio.h> \nint main() \n{ \ntypedef int i; \ni a = 0; \nprintf(\"%d\", a); \ngetchar(); \nreturn 0; \n} \n', '1', 'Syntax error', '0', 'Runtime error', 'c', 1),
(194, '#include<stdio.h> \nint main() \n{ \ntypedef int *i; \nint j = 10; \ni *a = &j; \nprintf(\"%d\", **a); \ngetchar(); \nreturn 0; \n} \n', 'Runtime error ', 'Compilation error', 'Compiler dependent ', 'No errors', 'b', 1),
(195, 'How can we restrict dynamic allocation of objects of a class using new?', 'By overloading new operator\n', 'By making an empty private new operator.\n', 'By making an empty private new and new[] operators\n', 'By overloading new operator and new[] operators\n', 'c', 1),
(196, '#include<stdio.h> \nint main() \n{ \ntypedef static int *i; \nint j; \ni a = &j; \nprintf(\"%d\", *a); \ngetchar(); \nreturn 0; \n} \n', 'Compiler dependent ', 'No errors ', 'Compilation error', 'Runtime error ', 'c', 1),
(197, '#include<stdio.h> \nint main() \n{ \ntypedef int *i; \nint j = 10; \ni a = &j; \nprintf(\"%d\", *a); \ngetchar(); \nreturn 0; \n} \n', '10', 'Syntax error', 'Compiler Dependent ', 'Run-time error ', 'a', 1),
(198, 'Output?\n#include <iostream>\nusing namespace std;\n \ntemplate <int i>\nvoid fun()\n{\n   i = 20;\n   cout << i;\n}\n \nint main()\n{\n   fun<10>();\n   return 0;\n}', '10', '20', 'Compiler Error', 'Runtime Error', 'c', 1),
(199, 'Output?\n#include <iostream>\nusing namespace std;\n \ntemplate <class T>\nT max (T &a, T &b)\n{\n    return (a > b)? a : b;\n}\n \ntemplate <>\nint max <int> (int &a, int &b)\n{\n    cout << \"Called \";\n    return (a > b)? a : b;\n}\n \nint main ()\n{\n    int a = 10, b = 20;\n    cout << max <int> (a, b);\n}', '20', 'Called 20', 'Compiler Error', 'Runtime Error', 'b', 1),
(200, 'Output?\n#include <iostream>\nusing namespace std;\n  \ntemplate<int n> struct funStruct\n{\n    static const int val = 2*funStruct<n-1>::val;\n};\n  \ntemplate<> struct funStruct<0>\n{\n    static const int val = 1 ;\n};\n  \nint main()\n{\n    cout << funStruct<10>::val << endl;\n    return 0;\n}', 'Compiler Error', '1024', '2', '1', 'b', 1),
(201, 'Which of the following operators cannot be overloaded', '?: (Ternary or Conditional Operator )\n', '*(Multiplication)', '-(Subtraction)', '+(Addition)', 'a', 1),
(202, 'Which of the following provides the best description of an entity type?', 'A specific concrete object with a defined set of processes (e.g. Jatin with diabetes)', 'A value given to a particular attribute (e.g. height - 230 cm)', 'A thing that we wish to collect data about zero or more, possibly real world examples of it may exist', 'A template for a group of things with the same set of characteristics that may exist in the real world', 'd', 1),
(203, 'Which of the following is incorrect in C++ ? \n(1)When we write overloaded function we must code the function for each usage.\n (2)When we write function template we code the function only once.\n (3)It is difficult to debug macros\n (4)Templates are more efficient than macros', '(1) and (2)', '(1), (2) and (3)', '(3) and (4)', 'All of the above', 'd', 1),
(204, 'Which of the following operators are overloaded by default by the compiler in every user defined classes even if user has not written?\n1) Comparison Operator ( == )\n2) Assignment Operator ( = ) ', 'Both 1 and 2', 'Only 1', 'Only 2', 'None', 'c', 1),
(205, 'what would you put in place of “?” to print “geeks”?\nint main() \n{ \n  char arr[] = \"geeksforgeeks\"; \n  printf(\"%s\", ?); \n  getchar(); \n  return 0; \n} ', '(arr+8)', '(arr+7)', '(arr+4)', 'None of These', 'a', 1),
(206, '#include <iostream>\nusing namespace std;\nint main()\n{\n   int x = -1;\n   try {\n      cout << \"Inside try n\";\n      if (x < 0)\n      {\n         throw x;\n         cout << \"After throw n\";\n      }\n   }\n   catch (int x ) {\n      cout << \"Exception Caught n\";\n   }\n \n   cout << \"After catch n\";\n   return 0;\n}', 'Inside try\nException Caught\nAfter throw \nAfter catch', 'Inside try\nException Caught\nAfter catch', 'Inside try\nException Caught', 'Inside try\nAfter throw\nAfter catch', 'b', 1),
(207, 'What is the advantage of exception handling?\n\n1) Remove error-handling code from the software\'s main line of code.\n\n2) A method writer can chose to handle certain exceptions and delegate \n   others to the caller.\n\n3) An exception that occurs in a function can be handled anywhere in\n   the function call stack. ', 'Only 1', '1, 2 and 3', '1 and 3', '1 and 2', 'b', 1),
(208, 'What should be put in a try block?\n\n1. Statements that might cause exceptions\n2. Statements that should be skipped in case of an exception', 'Only 1', 'Only 2', 'Both 1 and 2', 'None', 'c', 1),
(209, 'Output of following program\n#include<iostream>\nusing namespace std;\n \nclass Base {};\nclass Derived: public Base {};\nint main()\n{\n   Derived d;\n   try {\n       throw d;\n   }\n   catch(Base b) {\n        cout<<\"Caught Base Exception\";\n   }\n   catch(Derived d) {\n        cout<<\"Caught Derived Exception\";\n   }\n   return 0;\n}', 'Caught Derived Exception', 'Caught Base Exception', 'Compiler Error', 'Runtime Error', 'b', 1),
(210, '#include <iostream>\nusing namespace std;\n \nint main()\n{\n    try\n    {\n       throw \'a\';\n    }\n    catch (int param)\n    {\n        cout << \"int exceptionn\";\n    }\n    catch (...)\n    {\n        cout << \"default exceptionn\";\n    }\n    cout << \"After Exception\";\n    return 0;\n}', 'default exception\nAfter Exception', 'int exception\nAfter Exception', 'int exception', 'default exception', 'a', 1),
(211, 'int main() \n{ \n  int x, y = 5, z = 5; \n  x = y==z; \n  printf(\"%d\", x); \n    \n  getchar(); \n  return 0; \n} ', '1', '5', 'Compiler Error', 'None of These', 'a', 1),
(212, '#include <iostream>\nusing namespace std;\n \nint main()\n{\n    try\n    {\n       throw 10;\n    }\n    catch (...)\n    {\n        cout << \"default exceptionn\";\n    }\n    catch (int param)\n    {\n        cout << \"int exceptionn\";\n    }\n \n    return 0;\n}', 'default exception', 'int exception', 'Compiler Error', 'Runtime Error', 'c', 1),
(213, '#include <iostream>\nusing namespace std;\n \nint main()\n{\n    try\n    {\n        try\n        {\n            throw 20;\n        }\n        catch (int n)\n        {\n            cout << \"Inner Catchn\";\n            throw;\n        }\n    }\n    catch (int x)\n    {\n        cout << \"Outer Catchn\";\n    }\n    return 0;\n}', 'Outer Catch', 'Inner Catch', 'Inner Catch\nOuter Catch', 'Compiler Error', 'c', 1),
(214, '#include <iostream>\nusing namespace std;\n \nclass Test {\npublic:\n   Test() { cout << \"Constructing an object of Test \" << endl; }\n  ~Test() { cout << \"Destructing an object of Test \"  << endl; }\n};\n \nint main() {\n  try {\n    Test t1;\n    throw 10;\n  } catch(int i) {\n    cout << \"Caught \" << i << endl;\n  }\n}', 'Caught 10', 'Constructing an object of Test \nCaught 10', 'Constructing an object of Test \nDestructing an object of Test \nCaught 10', 'Compiler Errror', 'c', 1),
(215, 'int main() \n{ \n  printf(\" \\\"GEEKS %% FOR %% GEEKS\\\"\"); \n  getchar(); \n  return 0; \n} ', '\"GEEKS % FOR % GEEKS\" ', 'GEEKS % FOR % GEEKS', '\"GEEKS %% FOR % %GEEKS\" ', 'None Of These', 'a', 1),
(216, '#include <iostream>\nusing namespace std;\n \nclass Test {\n  static int count;\n  int id;\npublic:\n  Test() {\n    count++;\n    id = count;\n    cout << \"Constructing object number \" << id << endl;\n    if(id == 4)\n       throw 4;\n  }\n  ~Test() { cout << \"Destructing object number \" << id << endl; }\n};\n \nint Test::count = 0;\n \nint main() {\n  try {\n    Test array[5];\n  } catch(int i) {\n    cout << \"Caught \" << i << endl;\n  }\n}', 'Constructing object number 1\nConstructing object number 2\nConstructing object number 3\nConstructing object number 4\nDestructing object number 1\nDestructing object number 2\nDestructing object number 3\nDestructing object number 4\nCaught 4', 'Constructing object number 1\nConstructing object number 2\nConstructing object number 3\nConstructing object number 4\nDestructing object number 3\nDestructing object number 2\nDestructing object number 1\nCaught 4', 'Constructing object number 1\nConstructing object number 2\nConstructing object number 3\nConstructing object number 4\nDestructing object number 4\nDestructing object number 3\nDestructing object number 2\nDestructing object number 1\nCaught 4', 'Constructing object number 1\nConstructing object number 2\nConstructing object number 3\nConstructing object number 4\nDestructing object number 1\nDestructing object number 2\nDestructing object number 3\nCaught 4', 'b', 1),
(217, 'Which of the following is true about exception handling in C++? \n1) There is a standard exception class like Exception class in Java.\n 2) All exceptions are unchecked in C++, i.e., compiler doesn\'t check if the exceptions are caught or not.\n 3) In C++, a function can specify the list of exceptions that it can throw using comma separated list like following.\n  void fun(int a, char b) throw (Exception1, Exception2, ..)', '1 and 3', '1, 2 and 3', '1 and 2', '3 and 2', 'b', 1),
(218, 'What happens in C++ when an exception is thrown and not caught anywhere like following program.\n#include <iostream>\nusing namespace std;\n \nint fun() throw (int)\n{\n    throw 10;\n}\n \nint main() {\n \n  fun();\n \n  return 0;\n}', 'Compiler error', 'Abnormal program termination', 'Program doesn\'t print anything and terminates normally', 'None of the above', 'b', 1),
(219, 'What happens when a function throws an error but doesn\'t specify it in the list of exceptions it can throw. For example, what is the output of following program?\n#include <iostream>\nusing namespace std;\n \nint fun()\n{\n    throw 10;\n}\n \nint main()\n{\n    try\n    {\n        fun();\n    }\n    catch (int )\n    {\n        cout << \"Caught\";\n    }\n    return 0;\n}', 'Compiler Error', 'Runtime Error', 'No compiler Error. Output is \"Caught\"', 'None of the above', 'c', 1),
(220, '#include<stdio.h> \nint main() \n{ \n   int a; \n   char *x; \n   x = (char *) &a; \n   a = 512; \n   x[0] = 1; \n   x[1] = 2; \n   printf(\"%d\\n\",a); \n  \n   getchar(); \n   return 0; \n}  ', 'Machine Dependent', '513', '258', '512', 'a', 1),
(221, 'int main() \n{ \n  int f = 0, g = 1; \n  int i; \n  for(i = 0; i < 15; i++)  \n  { \n    printf(\"%d \\n\", f); \n    f = f + g; \n    g = f - g; \n  } \n  getchar(); \n  return 0; \n} ', '0 \n1 \n1 \n2 \n3 \n5 \n8 \n13 \n21 \n34 \n55 \n89 \n144 \n233 \n376\n', '0 \n1 \n1 \n2 \n3 \n5 \n8 \n13 \n21 \n34 \n55 \n89 \n144 \n233 \n377 \n \n\n', '0 \n1 \n1 \n2 \n3 \n5 \n8 \n13 \n21 \n34 \n55 \n144 \n233 \n378\n', '0 \n1 \n1 \n2 \n3 \n5 \n8 \n13 \n21 \n34 \n55 \n89 \n144 \n233 \n377 \n444', 'b', 1),
(222, '#include<stdio.h> \n  \nint main() \n{ \n  int a[] = {1, 2, 3, 4, 5, 6}; \n  int *ptr = (int*)(&a+1); \n  printf(\"%d \", *(ptr-1) ); \n  getchar(); \n  return 0; \n}  ', '6', '5', '1', '2', 'a', 1),
(223, '#include <stdio.h> \n  \nchar* fun() \n{ \n  return \"awake\"; \n} \nint main() \n{ \n  printf(\"%s\",fun()+ printf(\"I see you\")); \n  getchar(); \n  return 0; \n} ', 'Some string starting with “I see you”', 'I see you', '“I see you”', 'None of These', 'a', 1),
(224, '#include <stdio.h> \n  \nint main() \n{ \n  unsigned i ; \n  for( i = 0 ; i < 4 ; ++i ) \n  { \n    fprintf( stdout , \"i = %d\\n\" , (\"11213141\") ) ; \n  } \n  \n  getchar(); \n  return 0 ; \n} ', 'Machine Dependent', '11213141', '\"11213141\"', '1 2 3 4', 'a', 1),
(225, 'void fun(int *p) \n{ \n  int q = 10; \n  p = &q; \n}     \n   \nint main() \n{ \n  int r = 20; \n  int *p = &r; \n  fun(p); \n  printf(\"%d\", *p); \n  return 0; \n}', '10', '20', 'Runtime Error', 'Compiler Error', 'b', 1),
(226, 'Assume sizeof an integer and a pointer is 4 byte. Output?\n#include <stdio.h>\n \n#define R 10\n#define C 20\n \nint main()\n{\n   int (*p)[R][C];\n   printf(\"%d\",  sizeof(*p));\n   getchar();\n   return 0;\n}', '200', '4', '800', '80', 'c', 1),
(227, '#include <stdio.h>\nint main()\n{\n    int a[5] = {1,2,3,4,5};\n    int *ptr = (int*)(&a+1);\n    printf(\"%d %d\", *(a+1), *(ptr-1));\n    return 0;\n}', '2 5', 'Garbage Value', 'Compiler Error', 'Segmentation Fault', 'a', 1),
(228, '// size of int is 4 bytes\n#include<stdio.h> \n  \n#define R 10 \n#define C 20 \n  \nint main() \n{ \n   int (*p)[R][C]; \n   printf(\"%d\",  sizeof(*p)); \n   getchar(); \n   return 0; \n} ', '800', '400', 'Compilation Error', '200', 'a', 1),
(229, 'Assume that the size of int is 4.\n#include <stdio.h>\nvoid f(char**);\nint main()\n{\n    char *argv[] = { \"ab\", \"cd\", \"ef\", \"gh\", \"ij\", \"kl\" };\n    f(argv);\n    return 0;\n}\nvoid f(char **p)\n{\n    char *t;\n    t = (p += sizeof(int))[-1];\n    printf(\"%sn\", t);\n}', 'ab', 'cd', 'ef', 'gh', 'd', 1),
(230, '#include<stdio.h> \n#define f(g,g2) g##g2 \nint main() \n{ \n   int var12 = 100; \n   printf(\"%d\", f(var,12)); \n   getchar(); \n   return 0; \n} ', '100', '12', 'Compilation Error', 'None of These', 'a', 1),
(231, '#include <stdio.h>\nint main()\n{\n    int a[][3] = {1, 2, 3, 4, 5, 6};\n    int (*ptr)[3] = a;\n    printf(\"%d %d \", (*ptr)[1], (*ptr)[2]);\n    ++ptr;\n    printf(\"%d %dn\", (*ptr)[1], (*ptr)[2]);\n    return 0;\n}', '2 3 5 6', '2 3 4 5', '4 5 0 0', 'none of the above', 'a', 1),
(232, '#include <stdio.h>\n#include <stdlib.h>\n \nint main(void)\n{\n    int i;\n    int *ptr = (int *) malloc(5 * sizeof(int));\n \n    for (i=0; i<5; i++)\n        *(ptr + i) = i;\n \n    printf(\"%d \", *ptr++);\n    printf(\"%d \", (*ptr)++);\n    printf(\"%d \", *ptr);\n    printf(\"%d \", *++ptr);\n    printf(\"%d \", ++*ptr);\n}', 'Compiler Error', '0 1 2 2 3', '0 1 2 3 4', '1 2 3 4 5', 'b', 1),
(233, 'Output of following program\n#include <stdio.h>\nint fun(int arr[]) {\n   arr = arr+1; \n   printf(\"%d \", arr[0]);\n}\nint main(void) {\n   int arr[2] = {10, 20};\n   fun(arr);\n   printf(\"%d\", arr[0]);\n   return 0;\n}', 'Compiler Error', '20 10', '20 20', '10 10', 'b', 1),
(234, 'What is printed by the following C program?\n$include <stdio.h>\nint f(int x, int *py, int **ppz)\n{\n  int y, z;\n  **ppz += 1; \n   z  = **ppz;\n  *py += 2;\n   y = *py;\n   x += 3;\n   return x + y + z;\n}\n  \nvoid main()\n{\n   int c, *b, **a;\n   c = 4;\n   b = &c;\n   a = &b; \n   printf( \"%d\", f(c,b,a));\n   getchar();\n}', '18', '19', '21', '22', 'b', 1),
(235, 'What is the output of the following C code? Assume that the address of x is 2000 (in decimal) and an integer requires four bytes of memory.\n#include <stdio.h>\nint main()\n{ \n   unsigned int x[4][3] = {{1, 2, 3}, {4, 5, 6}, \n                           {7, 8, 9}, {10, 11, 12}};\n   printf(\"%u, %u, %u\", x+3, *(x+3), *(x+2)+3);\n}', '2036, 2036, 2036', '2012, 4, 2204', '2036, 10, 10', '2012, 4, 6', 'a', 1),
(236, '#include<stdio.h> \nint main()  \n{ \n   unsigned int x = -1; \n   int y = ~0; \n   if(x == y) \n      printf(\"same\"); \n   else\n      printf(\"not same\"); \n   printf(\"\\n x is %u, y is %u\", x, y); \n   getchar(); \n   return 0; \n} ', '\"same x is MAXUINT, y is MAXUINT” Where MAXUINT is the maximum possible value for an unsigned integer.', '\"same x is MINUINT, y is MAXUINT” Where MAXUINT is the maximum possible value for an unsigned integer and MINUINT is minimum possible value for an unsigned integer.', '\"same x is MAXUINT, y is MINUINT” Where MAXUINT is the maximum possible value for an unsigned integer and MINUINT is minimum possible value for an unsigned integer.', '\"same x is MINUINT, y is MINUINT” Where MINUINT is the minimum possible value for an unsigned integer.', 'a', 1),
(237, 'Consider the following C program.\n# include \nint main( )\n{\n  static int a[] = {10, 20, 30, 40, 50};\n  static int *p[] = {a, a+3, a+4, a+1, a+2};\n  int **ptr = p;\n  ptr++;\n  printf(\"%d%d\", ptr - p, **ptr};\n}\nThe output of the program is _________', '140', '120', '100', '40', 'a', 1),
(238, '#include \"stdlib.h\"\nint main()\n{\n int *pInt;\n int **ppInt1;\n int **ppInt2;\n \n pInt = (int*)malloc(sizeof(int));\n ppInt1 = (int**)malloc(10*sizeof(int*));\n ppInt2 = (int**)malloc(10*sizeof(int*));\n \n free(pInt);\n free(ppInt1);\n free(*ppInt2);\n return 0;\n}\n\nChoose the correct statement w.r.t. above C program.', 'malloc() for ppInt1 and ppInt2 isn’t correct. It’ll give compile time error.', 'free(*ppInt2) is not correct. It’ll give compile time error.', 'free(*ppInt2) is not correct. It’ll give run time error.', 'No issue with any of the malloc() and free() i.e. no compile/run time error.', 'd', 1),
(239, '#include \"stdio.h\" \nint main()\n{\n void *pVoid;\n pVoid = (void*)0;\n printf(\"%lu\",sizeof(pVoid));\n return 0;\n}\n\nPick the best statement for the above C program snippet.', 'Assigning (void *)0 to pVoid isn’t correct because memory hasn’t been allocated. That’s why no compile error but it\'ll result in run time error.', 'Assigning (void *)0 to pVoid isn’t correct because a hard coded value (here zero i.e. 0) can’t assigned to any pointer. That’s why it\'ll result in compile error.', 'No compile issue and no run time issue. And the size of the void pointer i.e. pVoid would equal to size of int.', 'sizeof() operator isn’t defined for a pointer of void type.', 'c', 1),
(240, '#include<stdio.h> \nint fun() \n{ \n  static int num = 40; \n  return num--; \n} \n  \nint main() \n{ \n  for(fun(); fun(); fun()) \n  { \n    printf(\"%d \", fun()); \n  } \n  getchar(); \n  return 0; \n} ', '38 35 32 29 26 23 20 17 14 11 8 5 2', 'to fill', 'to fill', 'to fill', 'a', 1),
(241, 'In the context of the below program snippet, pick the best answer.\n#include \"stdio.h\"\nint arr[10][10][10];\nint main()\n{\n arr[5][5][5] = 123;\n return 0;\n}\n\nWhich of the given printf statement(s) would be able to print arr[5][5][5]\n(i) printf(\"%d\",arr[5][5][5]);\n(ii) printf(\"%d\",*(*(*(arr+5)+5)+5));\n(iii) printf(\"%d\",(*(*(arr+5)+5))[5]);\n(iv) printf(\"%d\",*((*(arr+5))[5]+5));', 'only (i), (ii) and (iii) would compile and all three would print 123.', 'all (i), (ii), (iii) and (iv) would compile and all would print 123.', 'both (i) and (ii) would compile and both would print 123.', 'only (i) would compile and print 123.', 'b', 1),
(242, 'Find out the correct statement for the following program.\n#include \"stdio.h\"\n \ntypedef int (*funPtr)(int);\n \nint inc(int a)\n{\n printf(\"Inside inc() %dn\",a);\n return (a+1);\n}\n \nint main()\n{\n \n funPtr incPtr1 = NULL, incPtr2 = NULL;\n \n incPtr1 = &inc; /* (1) */\n incPtr2 = inc; /* (2) */\n \n (*incPtr1)(5); /* (3) */\n incPtr2(5); /* (4)*/\n \n return 0;\n}', 'Line with comment (1) will give compile error', 'Line with comment (2) will give compile error', 'Lines with (1) & (3) will give compile error.', 'No compile error and program will run without any issue.', 'd', 1),
(243, '#include<stdio.h> \nint main() \n{ \n  char *s[] = { \"knowledge\",\"is\",\"power\"}; \n  char **p; \n  p = s; \n  printf(\"%s \", ++*p); \n  printf(\"%s \", *p++); \n  printf(\"%s \", ++*p); \n  \n  getchar(); \n  return 0; \n} ', 'nowledge nowledge s', '\nnowledge nowledge is', 'nowledge nowledge ower', 'None of These', 'a', 1),
(244, '‘ptrdata’ is a pointer to a data type. The expression *ptrdata++ is evaluated as (in C++) :', '*(ptrdata++)', '(*ptrdata)++', '*(ptrdata)++', 'Depends on compiler', 'a', 1),
(245, 'Consider the following C function\n#include <stdio.h>\nint main(void)\n   {\n    char c[ ] = \"ICRBCSIT17\";\n    char *p=c;\n    printf(\"%s\", c+2[p] – 6[p] – 1);\n    return 0;\n   }', 'SI', 'IT', 'TI', '17', 'd', 1),
(246, '#include <stdio.h> \nint main() \n{ \n  int a = 10, b = 20, c = 30; \n  if (c > b > a) \n  { \n    printf(\"TRUE\"); \n  } \n  else\n  { \n    printf(\"FALSE\"); \n  } \n  getchar(); \n  return 0; \n}', '1', '0', 'Compilation Error', 'None of These', 'b', 1),
(247, 'What will be output of the following program? Assume that you are running this program in little-endian processor.\n#include<stdio.h>\n \nint main() {\n    short a = 320;\n    char * ptr;\n    ptr = (char * ) & a;\n    printf(\"%d\", * ptr);\n    return 0;\n}', '1', '320', '64', 'Compilation error', 'c', 1),
(248, 'int main() \n{ \n  int x = 10; \n  static int y = x; \n  \n  if(x == y) \n     printf(\"Equal\"); \n  else if(x > y) \n     printf(\"Greater\"); \n  else\n     printf(\"Less\"); \n  \n  getchar(); \n  return 0; \n} ', 'Equal', 'Greater', 'Less', 'Compilation Error', 'd', 1),
(249, 'Which of the following true about FILE *fp', 'FILE is a keyword in C for representing files and fp is a variable of FILE type.', 'FILE is a structure and fp is a pointer to the structure of FILE type', 'FILE is a stream', 'FILE is a buffered stream', 'b', 1),
(250, 'When fopen() is not able to open a file, it returns', 'EOF', NULL, 'Runtime Error', 'Compiler Dependent', 'b', 1),
(251, '#include <stdio.h> \n  \nint main() \n{ \n  int i; \n  \n  for (i = 1; i != 10; i += 2) \n  { \n    printf(\" GeeksforGeeks \"); \n  } \n  \n  getchar(); \n  return 0; \n}', 'Infinite times GeeksforGeeks', '5 times GeeksforGeeks', '6 times GeeksforGeeks', 'Compilation Error', 'a', 1),
(252, '#include<stdio.h> \nstruct st \n{ \n    int x; \n    struct st next; \n}; \n  \nint main() \n{ \n    struct st temp; \n    temp.x = 10; \n    temp.next = temp; \n    printf(\"%d\", temp.next.x); \n  \n    getchar(); \n    return 0; \n}', 'Compiler Error', '10', 'Runtime Error', '10.1', 'a', 1),
(253, 'getc() returns EOF when', 'End of files is reached', 'When getc() fails to read a character', 'Both of the above', 'None of the above', 'c', 1),
(254, 'In fopen(), the open mode \"wx\" is sometimes preferred \"w\" because. 1) Use of wx is more efficient. 2) If w is used, old contents of file are erased and a new empty file is created. When wx is used, fopen() returns NULL if file already exists.', 'Only 1', 'Only 2', 'Both 1 and 2', 'Neither 1 nor 2', 'b', 1),
(255, '#include<stdio.h> \n#define fun (x) (x)*10 \n  \nint main() \n{ \n    int t = fun(5); \n    int i;  \n    for(i = 0; i < t; i++) \n       printf(\"GeesforGeeks\\n\"); \n  \n    return 0; \n} ', 'Compiler Error', 'Prints 50 times GeesforGeeks', 'Prints nothing', 'None of These', 'a', 1),
(256, 'fseek() should be preferred over rewind() mainly because', 'rewind() doesn\'t work for empty files', 'rewind() may fail for large files', 'In rewind, there is no way to check if the operations completed successfully', 'All of the above', 'c', 1),
(257, '#include<stdio.h> \n#define fun(x) (x)*10 \n  \nint main() \n{ \n    int t = fun(5); \n    int i;  \n    for(i = 0; i < t; i++) \n       printf(\"GeesforGeeks\\n\"); \n  \n    return 0; \n} ', 'Compiler Error', 'Prints 50 times GeesforGeeks', 'Prints nothing', 'None Of These', 'b', 1),
(258, '#include<stdio.h> \nint main() \n{ \n    int i = 20,j; \n    i = (printf(\"Hello\"), printf(\" All Geeks \")); \n    printf(\"%d\", i); \n  \n    return 0; \n} ', 'Hello All Geeks 11', 'Hello All Geeks 20', 'Hello All Geeks 17', 'None of These', 'a', 1),
(259, '#include<stdio.h> \n  \nint main() \n{ \n    enum channel {star, sony, zee}; \n    enum symbol {hash, star}; \n  \n    int i = 0; \n    for(i = star; i <= zee; i++) \n    { \n        printf(\"%d \", i); \n    } \n  \n    return 0; \n} ', 'compiler error: redeclaration of enumerator \'star\'', '0 1 2', '012', 'None of These', 'a', 1),
(260, '#include<stdio.h> \n  \nint main() \n{ \n    enum channel {star, sony, zee}; \n  \n    int i = 0; \n    for(i = star; i <= zee; i++) \n    { \n        printf(\"%d \", i); \n    } \n  \n    return 0; \n} ', '0 1 2', '012', 'Compiler Error', 'None of These', 'a', 1),
(261, '#include<stdio.h> \n  \nint main() \n{ \n    int i, j; \n    int p = 0, q = 2; \n  \n    for(i = 0, j = 0; i < p, j < q; i++, j++) \n    { \n      printf(\"GeeksforGeeks\\n\"); \n    } \n  \n    return 0; \n} ', 'GeeksforGeeks\nGeeksforGeeks', 'GeeksforGeeks', 'GeeksforGeeks\nGeeksforGeeks\nGeeksforGeeks\nGeeksforGeeks', 'None of These', 'a', 1),
(262, 'Consider the following two C lines\nint var1;\nextern int var2;', 'Both statements only declare variables, don\'t define them.', 'First statement declares and defines var1, but second statement only declares var2', 'Both statements declare define variables var1 and var2', 'None of the above', 'b', 1),
(263, 'Predict the output\n#include <stdio.h>\nint var = 20;\nint main()\n{\n    int var = var;\n    printf(\"%d \", var);\n    return 0;\n}', 'Garbage Value', '20', 'Compiler Error', 'Runtime Error', 'a', 1),
(264, '#include <stdio.h>\nextern int var;\nint main()\n{\n    var = 10;\n    printf(\"%d \", var);\n    return 0;\n}', 'Compiler Error: var is not defined', '20', '0', 'Garbage value', 'a', 1),
(265, '#include <stdio.h>\nextern int var = 0;\nint main()\n{\n    var = 10;\n    printf(\"%d \", var);\n    return 0;\n}', '10', 'Compiler Error: var is not defined', '0', 'Runtime error', 'a', 1),
(266, 'Output?\nint main()\n{\n  {\n      int var = 10;\n  }\n  {\n      printf(\"%d\", var);  \n  }\n  return 0;\n}', '10', 'Compiler Error', 'Garbage Value', 'None of the above', 'b', 1),
(267, 'int main()\r\n{\r\n  int x = 032;\r\n  printf(\"%d\", x);\r\n  return 0;\r\n}', '32', '0', '26', '50', 'c', 1),
(268, 'int main()\n{\n  int x = 032;\n  printf(\"%d\", x);\n  return 0;\n}', '32', '0', '26', '50', 'c', 1),
(269, 'Consider the following C program, which variable has the longest scope?\nint a;\nint main()\n{\n   int b;\n   // ..\n   // ..\n}\nint c;', 'a', 'b', 'c', 'All have same scope', 'a', 1),
(270, 'Consider the following variable declarations and definitions in C\ni) int var_9 = 1;\nii) int 9_var = 2;\niii) int _ = 3;\nChoose the correct statement w.r.t. above variables.', 'Both i) and iii) are valid.', 'Only i) is valid.', 'Both i) and ii) are valid.', 'All are valid.', 'a', 1),
(271, 'Find out the correct statement for the following program.\n#include \"stdio.h\"\n \nint * gPtr;\n \nint main()\n{\n int * lPtr = NULL;\n \n if(gPtr == lPtr)\n {\n   printf(\"Equal!\");\n }\n else\n {\n  printf(\"Not Equal\");\n }\n \n return 0;\n}', 'It’ll always print Equal.', 'It’ll always print Not Equal.', 'Since gPtr isn’t initialized in the program, it’ll print sometimes Equal and at other times Not Equal.', 'Error', 'a', 1),
(272, 'Consider the program below in a hypothetical language which allows global variable and a choice of call by reference or call by value methods of parameter passing.\nint i ;\nprogram main ()\n{\n    int j = 60;\n    i = 50;\n    call f (i, j);\n    print i, j;\n}\nprocedure f (x, y)\n{           \n    i = 100;\n    x = 10;\n    y = y + i ;\n}\nWhich one of the following options represents the correct output of the program for the two parameter passing mechanisms?', 'Call by value : i = 70, j = 10; Call by reference : i = 60, j = 70', 'Call by value : i = 50, j = 60; Call by reference : i = 50, j = 70', 'Call by value : i = 10, j = 70; Call by reference : i = 100, j = 60', 'Call by value : i = 100, j = 60; Call by reference : i = 10, j = 70', 'd', 1),
(273, 'What will be the output of the following C code?\n#include <stdio.h>\nmain( )\n{\nint i;\nfor ( i=0; i<5; i++ )\n{\n   int i = 10;\n   printf ( \"%d \", i );\n   i++;\n}\nreturn 0;\n}', '10 11 12 13 14', '10 10 10 10 10', '0 1 2 3 4', 'Compilation error', 'b', 1),
(274, 'What is the output of the following program?\n#include \nint tmp=20;\nmain( )\n{\nprintf(\"%d \",tmp);\nfunc( );\nprintf(\"%d \",tmp);\n}\nfunc( )\n{\nstatic int tmp=10;\nprintf(\"%d \",tmp);\n}', '20 10 10', '20 10 20', '20 20 20', '10 10 10', 'b', 1),
(275, 'Given i= 0, j = 1, k = – 1 x = 0.5, y = 0.0 What is the output of given ‘C’ expression ? x * 3 & & 3 || j | k', '-1', '0', '1', '2', 'c', 1),
(276, 'Assume that the program ‘P’ is implementing parameter passing with ‘call by reference’. What will be printed by following print statements in P? \nProgram P( ) { x = 10; y = 3; funb (y, x, x) print x; print y; } funb (x, y, z) { y = y + 4; z = x + y + z; }', '10, 7', '31, 3', '10, 3', '31, 7', 'b', 1),
(277, 'When an array is passed as parameter to a function, which of the following statements is correct?', 'The function can change values in the original array.', 'In C, parameters are passed by value, the function cannot change the original value in the array.', 'It results in compilation error when the function tries to access the elements in the array.', 'Results in a run time error when the function tries to access the elements in the array.', 'a', 1);
INSERT INTO `questions_question` (`id`, `problem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `level`) VALUES
(278, 'Consider the following statements S1, S2 and S3 : \nS1 : In call-by-value, anything that is passed into a function call is unchanged in the caller’s scope when the function returns.\nS2 : In call-by-reference, a function receives implicit reference to a variable used as argument.\nS3 : In call-by-reference, caller is unable to see the modified variable used as argument.', 'S3 and S2 are true.', 'S3 and S1 are true', 'S1 and S2 are true', 'S1, S2 and S3 are true', 'c', 1),
(279, '#include <stdio.h>\n#define square(x) x*x\nint main()\n{\n  int x;\n  x = 36/square(6);\n  printf(\"%d\", x);\n  return 0;\n}', '1', '36', 'Compiler Error', 'Runtime Error', 'b', 1),
(280, '#include <stdio.h>\n#define a 10\nint main()\n{\n  printf(\"%d \",a);\n \n  #define a 50\n \n  printf(\"%d \",a);\n  return 0;\n}', 'Compiler Error', '10 50', '50 50', '10 10', 'b', 1),
(281, 'Output?\n#include<stdio.h> \n#define f(g,g2) g##g2 \nint main() \n{ \n   int var12 = 100; \n   printf(\"%d\", f(var,12)); \n   return 0; \n}', '100', 'Compiler Error', '0', '1', 'a', 1),
(282, 'Which file is generated after pre-processing of a C program?', '.p', '.i', '.o', '.m', 'b', 1),
(283, 'What is the use of \"#pragma once\"?', 'Used in a header file to avoid its inclusion more than once.', 'Used to avoid multiple declarations of same variable.', 'Used in a c file to include a header file at least once.', 'Used to avoid assertions', 'a', 1),
(284, '#include <stdio.h>\n#define MAX 1000\nint main()\n{\n   int MAX = 100;\n   printf(\"%d \", MAX);\n   return 0;\n}', '1000', '100', 'Compiler Error', 'Garbage Value', 'c', 1),
(285, 'Output of following C program?\n#include<stdio.h>\n#define max abc\n#define abc 100\n \nint main()\n{\n    printf(\"maximum is %d\", max);\n    return 0;\n}', 'maximum is 100', 'abcimum is 100', '100imum is 100', 'abcimum is abc', 'a', 1),
(286, 'Suppose someone writes increment macro (i.e. which increments the value by one) in following ways:\n#define INC1(a) ((a)+1)\n \n#define INC2 (a) ((a)+1)\n \n#define INC3( a ) (( a ) + 1)\n \n#define INC4 ( a ) (( a ) + 1)\n\nPick the correct statement for the above macros.', 'Only INC1 is correct.', 'All (i.e. INC1, INC2, INC3 and INC4) are correct.', 'Only INC1 and INC3 are correct.', 'Only INC1 and INC2 are correct.', 'c', 1),
(287, 'What is the output for the following code snippet?\n#include<stdio.h>\n#define A -B\n#define B -C\n#define C 5\n\nint main()\n{\n  printf(\"The value of A is %dn\", A); \n  return 0;\n} ', 'The value of A is 4', 'The value of A is 5', 'Compilation Error', 'Runtime Error', 'b', 1),
(288, 'Consider the following statements\n#define hypotenuse (a, b) sqrt (a*a+b*b); \nThe macro call hypotenuse(a+2,b+3);', 'Finds the hypotenuse of a triangle with sides a+2 and b+3', 'Finds the square root of (a+2)2 and (b+3)2', 'Is invalid', 'Find the square root of 3*a + 4*b + 5', 'd', 1),
(289, 'What is the output of the following C program?\n#include<stdio.h>\n#define SQR(x) (x*x)\nint main()\n{\n    int a;\n    int b=4;\n    a=SQR(b+2);\n    printf(\"%dn\",a);\n    return 0;\n}', '14', '36', '18', '20', 'a', 1),
(290, 'The translator which performs macro calls expansion is called:', 'Macro processor', 'Micro pre - processor', 'Macro pre - processor', 'Dynamic Linker', 'c', 1),
(291, 'Which of the following is not a storage class specifier in C?', 'auto', 'extern', 'volatile', 'typedef', 'c', 1),
(292, '#include <stdio.h>\nint main()\n{\n    static int i=5;\n    if(--i){\n        main();\n        printf(\"%d \",i);\n    }\n}', '4 3 2 1', '1 2 3 4 ', '0 0 0 0', 'Compiler Error', 'c', 1),
(293, '#include <stdio.h>\nint main()\n{\n    int x = 5;\n    int * const ptr = &x;\n    ++(*ptr);\n    printf(\"%d\", x);\n    return 0;\n}', 'Compiler Error', 'Runtime Error', '6', '5', 'c', 1),
(294, '#include<stdio.h>\nint main()\n{\n  typedef static int *i;\n  int j;\n  i a = &j;\n  printf(\"%d\", *a);\n  return 0;\n}', 'Runtime Error', '0', 'Garbage Value', 'Compiler Error', 'd', 1),
(295, '#include<stdio.h>\nint main()\n{\n  typedef int *i;\n  int j = 10;\n  i *a = &j;\n  printf(\"%d\", **a);\n  return 0;\n}', 'Compiler Error', 'Garbage Value', '10', '0', 'a', 1),
(296, '#include <stdio.h>\nint fun()\n{\n  static int num = 16;\n  return num--;\n}\n \nint main()\n{\n  for(fun(); fun(); fun())\n    printf(\"%d \", fun());\n  return 0;\n}', 'Infinite loop', '13 10 7 4 1', '14 11 8 5 2', '15 12 8 5 2', 'c', 1),
(297, '#include <stdio.h>\nint main() \n{ \n  int x = 10; \n  static int y = x; \n   \n  if(x == y) \n     printf(\"Equal\"); \n  else if(x > y) \n     printf(\"Greater\"); \n  else\n     printf(\"Less\"); \n  return 0; \n}', 'Compiler Error', 'Equal', 'Greater', 'Less', 'a', 1),
(298, 'Consider the following C function\nint f(int n) \n{ \n   static int i = 1; \n   if (n >= 5) \n      return n; \n   n = n+i; \n   i++; \n   return f(n); \n}\nThe value returned by f(1) is', '5', '6', '7', '8', 'c', 1),
(299, 'In C, static storage class cannot be used with:', 'Global variable', 'Function parameter', 'Function name', 'Local variable', 'b', 1),
(300, 'Output?\n#include <stdio.h>\nint a, b, c = 0;\nvoid prtFun (void);\nint main ()\n{\n    static int a = 1; /* line 1 */\n    prtFun();\n    a += 1;\n    prtFun();\n    printf ( \"n %d %d \" , a, b) ;\n}\n  \nvoid prtFun (void)\n{\n    static int a = 2; /* line 2 */\n    int b = 1;\n    a += ++b;\n    printf (\" n %d %d \" , a, b);\n}', '3 1\n4 1\n4 2', '4 2\n6 1\n6 1', '4 2\n6 2\n2 0', '3 1\n5 2\n5 2', 'c', 1),
(301, 'Output?\n#include <stdio.h>\nint main()\n{\n  register int i = 10;\n  int *ptr = &i;\n  printf(\"%d\", *ptr);\n  return 0;\n}', 'Prints 10 on all compilers', 'May generate compiler Error', 'Prints 0 on all compilers', 'May generate runtime Error', 'b', 1),
(302, 'Output of following program\n#include <stdio.h>\nint fun(int n)\n{\n    static int s = 0;\n    s = s + n;\n    return (s);\n}\n \nint main()\n{\n    int i = 10, x;\n    while (i > 0)\n    {\n        x = fun(i);\n        i--;\n    }\n    printf (\"%d \", x);\n    return 0;\n}', '0', '110', '100', '55', 'd', 1),
(303, '#include <iostream> \nusing namespace std; \n  \nint main() \n{ \n    int a = 32, *ptr = &a; \n    char ch = \'A\', &cho = ch; \n  \n    cho += a; \n    *ptr += ch; \n    cout << a << \", \" << ch << endl; \n    return 0; \n} ', '32, A', '32, a', '129, a', '129, A', 'c', 1),
(304, '#include <iostream> \nusing namespace std; \nint main() \n{ \n    int num[5]; \n    int* p; \n    p = num; \n    *p = 10; \n    p++; \n    *p = 20; \n    p = &num[2]; \n    *p = 30; \n    p = num + 3; \n    *p = 40; \n    p = num; \n    *(p + 4) = 50; \n    for (int i = 0; i < 5; i++) \n        cout << num[i] << \", \"; \n    return 0; \n} ', '10, 20, 30, 40, 50', '10, 20, 30, 40, 50,', 'compile error', 'runtime error', 'b', 1),
(305, '#include <iostream> \nusing namespace std; \nint main() \n{ \n    int a = 10, *pa, &ra; \n    pa = &a; \n    ra = a; \n    cout << \"a=\" << ra; \n    return 0; \n} ', '10', 'no output', 'compile error', 'runtime error', 'c', 1),
(306, '\n#include <iostream> \nusing namespace std; \nint main() \n{ \n    int a = b = c = 10; \n    a = b = c = 50; \n    printf(\"%d %d %d\", a, b, c); \n    return 0; \n} ', '50 50 50', 'Three Gaebage Value', '10 10 10', 'Compile Time Error', 'd ', 1),
(307, '#include <iostream> \nusing namespace std; \nvoid fun(char s[], int n) \n{ \n    for (int i = 0; s[i] != \'\\0\'; i++) \n        if (i % 2 == 0) \n            s[i] = s[i] - n; \n        else\n            s[i] = s[i] + n; \n} \nint main() \n{ \n    char str[] = \"Hello_World\"; \n    fun(str, 2); \n    cout << str << endl; \n    return 0; \n} \n', 'EgjnmaTqpnb', 'FgjnmaUqpnb', 'Fgjnm_Uqpnb', 'EgjnmaTqpnb', 'b', 1),
(308, '\n#include <iostream> \nusing namespace std; \nint main() \n{ \n    char m; \n    switch (m) { \n    case \'c\': \n        cout << \"Computer Science\"; \n    case \'m\': \n        cout << \"Mathematics\"; \n        break; \n    case \'a\': \n        cout << \"Accoutant\"; \n        break; \n    default: \n        cout << \"wrong choice\"; \n    } \n    return 0; \n} ', 'Computer Science, Mathematics', 'Mathematics', 'wrong choice', 'error', 'c', 1),
(309, '\n#include <iostream> \nusing namespace std; \nint max(int& x, int& y, int& z) \n{ \n    if (x > y && y > z) { \n        y++; \n        z++; \n        return x++; \n    } else { \n        if (y > x) \n            return y++; \n        else\n            return z++; \n    } \n} \nint main() \n{ \n    int A, B; \n    int a = 10, b = 13, c = 8; \n    A = max(a, b, c); \n    cout << a++ << \" \" << b-- << \" \" << ++c << endl; \n    B = max(a, b, c); \n    cout << ++A << \" \" << --B << \" \" << c++ << endl; \n    return 0; \n} ', '10 14 8 or 14 13 8', '10 13 8 or 11 14 9', '10 14 9 or 14 12 9', '11 12 8 or 13 14 8', 'c', 1),
(310, '#include <iostream> \nusing namespace std; \n  \nclass abc { \n    void f(); \n    void g(); \n    int x; \n}; \n  \nmain() \n{ \n    cout << sizeof(abc) << endl; \n} ', 'A', '4', '8', 'Compile error', 'b', 1);

-- --------------------------------------------------------

--
-- Table structure for table `questions_scores`
--

CREATE TABLE `questions_scores` (
  `id` int(11) NOT NULL,
  `username` longtext NOT NULL,
  `event` longtext NOT NULL,
  `score` int(11) NOT NULL,
  `created` datetime(6) NOT NULL,
  `firebase` tinyint(1) NOT NULL,
  `name` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Scores_scores`
--

CREATE TABLE `Scores_scores` (
  `id` int(11) NOT NULL,
  `username` longtext NOT NULL,
  `event` longtext NOT NULL,
  `score` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Scores_scores`
--

INSERT INTO `Scores_scores` (`id`, `username`, `event`, `score`) VALUES
(1, 'pratham', 'Cerebro', -5),
(2, 'pratham@pasc.in', 'Cerebro', -5),
(3, 'user1@pasc.in', 'Cerebro', 10),
(4, 'user2@pasc.in', 'Cerebro', 0),
(5, 'user5@pasc.in', 'Cerebro', 10),
(6, 'user3@pasc.in', 'Cerebro', 5),
(7, 'user1@pasc.in', 'Cerebro', -3),
(8, 'user1@pasc.in', 'Cerebro', -2),
(9, 'pratham@pasc.in', 'Cerebro', -9),
(10, 'user3@pasc.in', 'Cerebro', -1),
(11, 'user4@pasc.in', 'Cerebro', 0),
(12, 'pratham@pasc.in', 'Cerebro', -4),
(13, 'joshisiddhesh28@gmail.com', 'Cerebro', -5),
(14, 'user1@pasc.in', 'Cerebro', -5),
(15, 'user5@pasc.in', 'Cerebro', 7),
(16, 'jinesh@pasc.in', 'Cerebro', 0),
(17, 'pratham@pasc.in', 'Cerebro', 12),
(18, 'boss@pasc.in', 'Cerebro', 4),
(19, 'user1@pasc.in', 'Cerebro', 7),
(20, 'anuj@pasc.in', 'Cerebro', 0),
(21, 'jinesh@pasc.in', 'Cerebro', 0),
(22, 'boss@pasc.in', 'Cerebro', -2),
(23, 'apoorv@pasc.in', 'Cerebro', 2),
(24, 'user1@pasc.in', 'Cerebro', 0),
(25, 'user2@pasc.in', 'Cerebro', -1),
(26, 'user3@pasc.in', 'Cerebro', 0),
(27, 'user4@pasc.in', 'Cerebro', 0),
(28, 'user5@pasc.in', 'Cerebro', 8),
(29, 'anuj@pasc.in', 'Cerebro', 0),
(30, 'jinesh@pasc.in', 'Cerebro', -3),
(31, 'jinesh@pasc.in', 'Cerebro', -3),
(32, 'boss@pasc.in', 'Cerebro', 0),
(33, 'pratham@pasc.in', 'Cerebro', 0),
(34, 'raghav@pasc.in', 'Cerebro', 0),
(35, 'manav@pasc.in', 'Cerebro', 0),
(36, 'yash@pasc.in', 'Cerebro', 3),
(37, 'anuj@pasc.in', 'Cerebro', 11),
(38, 'user1@pasc.in', 'Cerebro', 2),
(39, 'user1@pasc.in', 'Cerebro', 2),
(40, 'user3@pasc.in', 'Cerebro', 0),
(41, 'user2@pasc.in', 'Cerebro', -5),
(42, 'yash@pasc.in', 'Cerebro', -1),
(43, 'user5@pasc.in', 'Cerebro', 0),
(44, 'user4@pasc.in', 'Cerebro', 0),
(45, 'user4@pasc.in', 'Cerebro', 0),
(46, 'user4@pasc.in', 'Cerebro', 5),
(47, 'boss@pasc.in', 'Cerebro', 8),
(48, 'apoorv@pasc.in', 'Cerebro', 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `questions_auth`
--
ALTER TABLE `questions_auth`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions_scores`
--
ALTER TABLE `questions_scores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Scores_scores`
--
ALTER TABLE `Scores_scores`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=226;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=278;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `questions_auth`
--
ALTER TABLE `questions_auth`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `questions_scores`
--
ALTER TABLE `questions_scores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `Scores_scores`
--
ALTER TABLE `Scores_scores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
