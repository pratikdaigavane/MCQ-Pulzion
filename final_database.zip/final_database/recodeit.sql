-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 24, 2019 at 10:04 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mcq_pasc`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add question', 7, 'add_question'),
(26, 'Can change question', 7, 'change_question'),
(27, 'Can delete question', 7, 'delete_question'),
(28, 'Can view question', 7, 'view_question'),
(29, 'Can add scores', 8, 'add_scores'),
(30, 'Can change scores', 8, 'change_scores'),
(31, 'Can delete scores', 8, 'delete_scores'),
(32, 'Can view scores', 8, 'view_scores'),
(33, 'Can add scores', 9, 'add_scores'),
(34, 'Can change scores', 9, 'change_scores'),
(35, 'Can delete scores', 9, 'delete_scores'),
(36, 'Can view scores', 9, 'view_scores'),
(37, 'Can add scores', 10, 'add_scores'),
(38, 'Can change scores', 10, 'change_scores'),
(39, 'Can delete scores', 10, 'delete_scores'),
(40, 'Can view scores', 10, 'view_scores'),
(41, 'Can add auth', 11, 'add_auth'),
(42, 'Can change auth', 11, 'change_auth'),
(43, 'Can delete auth', 11, 'delete_auth'),
(44, 'Can view auth', 11, 'view_auth');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(57, 'pbkdf2_sha256$150000$D8IjNcHGWA3S$oa2e0Rbc/5fFvLZ54GquvddW0hUD+xbJRdsxP74yPUc=', '2019-07-23 18:44:07.000000', 1, 'admin', '', '', '', 1, 1, '2019-07-17 13:56:42.000000'),
(133, 'pbkdf2_sha256$150000$TiR4xFxZHNLm$B5XYlb5btCnlkUGvOD4MGXjot5z5vbAwqhItOSGi03M=', '2019-08-22 20:19:00.479536', 1, 'pratik', '', '', '', 1, 1, '2019-08-20 12:12:34.051870');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(40, '2019-07-17 13:57:11.241100', '46', 'admin', 3, '', 4, 57),
(41, '2019-07-17 13:57:11.335424', '40', 'apoorv', 3, '', 4, 57),
(42, '2019-07-17 13:57:11.375374', '41', 'manav', 3, '', 4, 57),
(43, '2019-07-17 13:57:11.470095', '45', 'nachiket', 3, '', 4, 57),
(44, '2019-07-17 13:57:11.503183', '52', 'pratham@pasc.in', 3, '', 4, 57),
(45, '2019-07-17 13:57:11.536615', '44', 'pratik', 3, '', 4, 57),
(46, '2019-07-17 13:57:11.570129', '39', 'raghav', 3, '', 4, 57),
(47, '2019-07-17 13:57:11.603497', '53', 'user1@pasc.in', 3, '', 4, 57),
(48, '2019-07-17 13:57:11.637004', '54', 'user2@pasc.in', 3, '', 4, 57),
(49, '2019-07-17 13:57:11.679267', '56', 'user3@pasc.in', 3, '', 4, 57),
(50, '2019-07-17 13:57:11.712613', '55', 'user5@pasc.in', 3, '', 4, 57),
(51, '2019-07-17 16:40:13.064841', '59', 'user2@pasc.in', 3, '', 4, 57),
(52, '2019-07-17 16:40:13.168583', '58', 'user1@pasc.in', 3, '', 4, 57),
(53, '2019-07-17 18:54:15.317283', '63', 'user5@pasc.in', 3, '', 4, 57),
(54, '2019-07-17 18:54:15.394679', '61', 'user3@pasc.in', 3, '', 4, 57),
(55, '2019-07-17 18:54:15.505744', '60', 'user1@pasc.in', 3, '', 4, 57),
(56, '2019-07-17 18:54:15.547213', '62', 'pratham@pasc.in', 3, '', 4, 57),
(57, '2019-07-17 19:11:48.036327', '65', 'user1@pasc.in', 3, '', 4, 57),
(58, '2019-07-17 19:11:48.169041', '64', 'pratham@pasc.in', 3, '', 4, 57),
(59, '2019-07-17 19:16:58.207675', '69', 'user5@pasc.in', 3, '', 4, 57),
(60, '2019-07-17 19:16:58.608907', '68', 'user3@pasc.in', 3, '', 4, 57),
(61, '2019-07-17 19:16:58.684311', '67', 'user1@pasc.in', 3, '', 4, 57),
(62, '2019-07-17 19:16:58.785934', '66', 'pratham@pasc.in', 3, '', 4, 57),
(63, '2019-07-17 19:29:53.276030', '71', 'pratham@pasc.in', 3, '', 4, 57),
(64, '2019-07-17 19:29:53.363149', '70', 'user1@pasc.in', 3, '', 4, 57),
(65, '2019-07-17 19:29:53.464138', '72', 'user3@pasc.in', 3, '', 4, 57),
(66, '2019-07-17 19:29:53.572272', '73', 'user4@pasc.in', 3, '', 4, 57),
(67, '2019-07-18 12:28:41.308830', '75', 'joshisiddhesh28@gmail.com', 3, '', 4, 57),
(68, '2019-07-18 12:28:41.372581', '74', 'pratham@pasc.in', 3, '', 4, 57),
(69, '2019-07-18 17:18:04.077887', '82', 'anuj@pasc.in', 3, '', 4, 57),
(70, '2019-07-18 17:18:04.122594', '83', 'jinesh@pasc.in', 3, '', 4, 57),
(71, '2019-07-18 17:18:04.164038', '81', 'pratham@pasc.in', 3, '', 4, 57),
(72, '2019-07-18 17:18:04.223186', '76', 'user1@pasc.in', 3, '', 4, 57),
(73, '2019-07-18 17:18:04.289537', '77', 'user2@pasc.in', 3, '', 4, 57),
(74, '2019-07-18 17:18:04.481748', '78', 'user3@pasc.in', 3, '', 4, 57),
(75, '2019-07-18 17:18:04.557140', '79', 'user4@pasc.in', 3, '', 4, 57),
(76, '2019-07-18 17:18:04.615588', '80', 'user5@pasc.in', 3, '', 4, 57),
(77, '2019-07-21 12:39:48.184455', '89', 'boss@pasc.in', 3, '', 4, 57),
(78, '2019-07-21 12:39:48.211988', '88', 'jinesh@pasc.in', 3, '', 4, 57),
(79, '2019-07-21 12:39:48.237174', '85', 'pratham@pasc.in', 3, '', 4, 57),
(80, '2019-07-21 12:39:48.262197', '84', 'user1@pasc.in', 3, '', 4, 57),
(81, '2019-07-21 12:39:48.295629', '86', 'user2@pasc.in', 3, '', 4, 57),
(82, '2019-07-21 12:39:48.328786', '87', 'user3@pasc.in', 3, '', 4, 57),
(83, '2019-07-21 17:02:14.675654', '96', 'anuj@pasc.in', 3, '', 4, 57),
(84, '2019-07-21 17:02:14.714534', '99', 'apoorv@pasc.in', 3, '', 4, 57),
(85, '2019-07-21 17:02:14.739982', '98', 'boss@pasc.in', 3, '', 4, 57),
(86, '2019-07-21 17:02:14.790313', '97', 'jinesh@pasc.in', 3, '', 4, 57),
(87, '2019-07-21 17:02:14.815351', '92', 'pratham@pasc.in', 3, '', 4, 57),
(88, '2019-07-21 17:02:14.840213', '90', 'user1@pasc.in', 3, '', 4, 57),
(89, '2019-07-21 17:02:14.991182', '91', 'user2@pasc.in', 3, '', 4, 57),
(90, '2019-07-21 17:02:15.016277', '93', 'user3@pasc.in', 3, '', 4, 57),
(91, '2019-07-21 17:02:15.041743', '94', 'user4@pasc.in', 3, '', 4, 57),
(92, '2019-07-21 17:02:15.066622', '95', 'user5@pasc.in', 3, '', 4, 57),
(93, '2019-07-22 12:10:11.092675', '105', 'anuj@pasc.in', 3, '', 4, 57),
(94, '2019-07-22 12:10:11.158988', '107', 'boss@pasc.in', 3, '', 4, 57),
(95, '2019-07-22 12:10:11.192445', '106', 'jinesh@pasc.in', 3, '', 4, 57),
(96, '2019-07-22 12:10:11.225956', '110', 'manav@pasc.in', 3, '', 4, 57),
(97, '2019-07-22 12:10:11.259410', '108', 'pratham@pasc.in', 3, '', 4, 57),
(98, '2019-07-22 12:10:11.326200', '109', 'raghav@pasc.in', 3, '', 4, 57),
(99, '2019-07-22 12:10:11.359688', '100', 'user1@pasc.in', 3, '', 4, 57),
(100, '2019-07-22 12:10:11.392833', '101', 'user2@pasc.in', 3, '', 4, 57),
(101, '2019-07-22 12:10:11.493571', '102', 'user3@pasc.in', 3, '', 4, 57),
(102, '2019-07-22 12:10:11.526802', '103', 'user4@pasc.in', 3, '', 4, 57),
(103, '2019-07-22 12:10:11.560479', '104', 'user5@pasc.in', 3, '', 4, 57),
(104, '2019-07-22 12:10:11.594152', '111', 'yash@pasc.in', 3, '', 4, 57),
(105, '2019-07-23 14:26:32.385403', '116', 'yash@pasc.in', 3, '', 4, 57),
(106, '2019-07-23 14:26:32.517819', '117', 'user5@pasc.in', 3, '', 4, 57),
(107, '2019-07-23 14:26:32.558596', '118', 'user4@pasc.in', 3, '', 4, 57),
(108, '2019-07-23 14:26:32.608503', '114', 'user3@pasc.in', 3, '', 4, 57),
(109, '2019-07-23 14:26:32.642362', '115', 'user2@pasc.in', 3, '', 4, 57),
(110, '2019-07-23 14:26:32.683693', '113', 'user1@pasc.in', 3, '', 4, 57),
(111, '2019-07-23 14:26:32.717245', '119', 'jinesh@pasc.in', 3, '', 4, 57),
(112, '2019-07-23 14:26:32.750618', '112', 'anuj@pasc.in', 3, '', 4, 57),
(113, '2019-07-23 18:16:22.341613', '127', 'apoorv@pasc.in', 3, '', 4, 57),
(114, '2019-07-23 18:16:22.387793', '126', 'boss@pasc.in', 3, '', 4, 57),
(115, '2019-07-23 18:16:22.420270', '128', 'manav@pasc.in', 3, '', 4, 57),
(116, '2019-07-23 18:16:22.454162', '120', 'pratham@pasc.in', 3, '', 4, 57),
(117, '2019-07-23 18:16:22.488482', '129', 'raghav@pasc.in', 3, '', 4, 57),
(118, '2019-07-23 18:16:22.521432', '121', 'user1@pasc.in', 3, '', 4, 57),
(119, '2019-07-23 18:16:22.554739', '122', 'user2@pasc.in', 3, '', 4, 57),
(120, '2019-07-23 18:16:22.587936', '123', 'user3@pasc.in', 3, '', 4, 57),
(121, '2019-07-23 18:16:22.622022', '125', 'user4@pasc.in', 3, '', 4, 57),
(122, '2019-07-23 18:16:22.654644', '124', 'yash@pasc.in', 3, '', 4, 57),
(123, '2019-07-23 18:44:36.614351', '130', 'user1@pasc.in', 3, '', 4, 57),
(124, '2019-07-23 18:44:36.661739', '131', 'user2@pasc.in', 3, '', 4, 57),
(125, '2019-07-23 18:44:57.748042', '57', 'admin', 2, '[{\"changed\": {\"fields\": [\"username\"]}}]', 4, 57),
(126, '2019-07-23 18:45:15.752958', '4', 'Scores object (4)', 3, '', 10, 57),
(127, '2019-07-23 18:45:15.783685', '3', 'Scores object (3)', 3, '', 10, 57),
(128, '2019-07-23 18:45:15.817125', '2', 'Scores object (2)', 3, '', 10, 57),
(129, '2019-07-23 18:45:15.850572', '1', 'Scores object (1)', 3, '', 10, 57),
(130, '2019-08-20 12:39:46.724105', '132', 'boss@pasc.in', 3, '', 4, 133),
(131, '2019-08-20 12:39:46.730198', '135', 'manav@pasc.in', 3, '', 4, 133),
(132, '2019-08-20 12:39:46.734291', '134', 'user1@pasc.in', 3, '', 4, 133),
(133, '2019-08-20 14:03:47.029916', '137', 'boss@pasc.in', 3, '', 4, 133),
(134, '2019-08-20 14:03:47.035973', '138', 'manav@pasc.in', 3, '', 4, 133),
(135, '2019-08-20 14:03:47.039808', '136', 'user1@pasc.in', 3, '', 4, 133),
(136, '2019-08-21 05:46:59.548958', '139', 'boss@pasc.in', 3, '', 4, 133),
(137, '2019-08-21 05:46:59.554149', '141', 'raghav@pasc.in', 3, '', 4, 133),
(138, '2019-08-21 05:46:59.557564', '140', 'yash@pasc.in', 3, '', 4, 133),
(139, '2019-08-21 06:34:40.127593', '142', 'boss@pasc.in', 3, '', 4, 133),
(140, '2019-08-21 06:34:40.134820', '143', 'user1@pasc.in', 3, '', 4, 133),
(141, '2019-08-21 07:34:58.958882', '147', 'anuj@pasc.in', 3, '', 4, 133),
(142, '2019-08-21 07:34:58.970769', '149', 'boss@pasc.in', 3, '', 4, 133),
(143, '2019-08-21 07:34:58.974726', '146', 'user1@pasc.in', 3, '', 4, 133),
(144, '2019-08-21 07:34:58.978547', '144', 'user2@pasc.in', 3, '', 4, 133),
(145, '2019-08-21 07:34:58.982642', '148', 'user3@pasc.in', 3, '', 4, 133),
(146, '2019-08-21 07:34:58.986515', '145', 'user4@pasc.in', 3, '', 4, 133),
(147, '2019-08-21 10:07:45.966198', '150', 'boss@pasc.in', 3, '', 4, 133),
(148, '2019-08-21 10:17:59.251548', '152', 'boss@pasc.in', 3, '', 4, 133),
(149, '2019-08-21 10:17:59.257903', '153', 'manav@pasc.in', 3, '', 4, 133),
(150, '2019-08-21 10:17:59.260362', '151', 'user1@pasc.in', 3, '', 4, 133),
(151, '2019-08-21 10:22:33.150662', '154', 'boss@pasc.in', 3, '', 4, 133),
(152, '2019-08-21 11:55:31.938724', '155', 'boss@pasc.in', 3, '', 4, 133),
(153, '2019-08-21 12:00:58.816610', '157', 'boss@pasc.in', 3, '', 4, 133),
(154, '2019-08-21 12:00:58.823123', '156', 'user1@pasc.in', 3, '', 4, 133),
(155, '2019-08-21 12:08:43.984624', '158', 'boss@pasc.in', 3, '', 4, 133),
(156, '2019-08-21 12:08:43.990691', '159', 'user1@pasc.in', 3, '', 4, 133),
(157, '2019-08-21 12:12:28.399259', '160', 'boss@pasc.in', 3, '', 4, 133),
(158, '2019-08-21 17:53:50.217543', '161', 'boss@pasc.in', 3, '', 4, 133),
(159, '2019-08-21 17:53:50.225235', '163', 'mundada.devansh@gmail.com', 3, '', 4, 133),
(160, '2019-08-21 17:53:50.228452', '162', 'vedbhatawadekar@gmail.com', 3, '', 4, 133),
(161, '2019-08-21 18:33:13.216947', '164', 'boss@pasc.in', 3, '', 4, 133),
(162, '2019-08-21 19:05:17.836093', '1', 'Question object (1)', 2, '[{\"changed\": {\"fields\": [\"problem\", \"option_a\", \"option_b\", \"option_c\", \"option_d\", \"correct_option\"]}}]', 7, 133),
(163, '2019-08-21 19:06:12.019300', '166', 'boss@pasc.in', 3, '', 4, 133),
(164, '2019-08-21 19:06:12.025404', '165', 'user1@pasc.in', 3, '', 4, 133),
(165, '2019-08-21 19:06:12.028891', '167', 'yash@pasc.in', 3, '', 4, 133),
(166, '2019-08-22 03:55:13.291740', '168', 'boss@pasc.in', 3, '', 4, 133),
(167, '2019-08-22 03:55:13.297059', '170', 'jinesh@pasc.in', 3, '', 4, 133),
(168, '2019-08-22 03:55:13.300642', '169', 'user1@pasc.in', 3, '', 4, 133),
(169, '2019-08-22 04:47:24.931276', '175', 'anuj@pasc.in', 3, '', 4, 133),
(170, '2019-08-22 04:47:24.943155', '171', 'boss@pasc.in', 3, '', 4, 133),
(171, '2019-08-22 04:47:24.948587', '174', 'user1@pasc.in', 3, '', 4, 133),
(172, '2019-08-22 04:47:24.954101', '172', 'user2@pasc.in', 3, '', 4, 133),
(173, '2019-08-22 04:47:24.957233', '173', 'user3@pasc.in', 3, '', 4, 133),
(174, '2019-08-22 12:21:43.991533', '176', 'boss@pasc.in', 3, '', 4, 133),
(175, '2019-08-22 12:21:43.998719', '178', 'jinesh@pasc.in', 3, '', 4, 133),
(176, '2019-08-22 12:21:44.002401', '180', 'user1@pasc.in', 3, '', 4, 133),
(177, '2019-08-22 12:21:44.004280', '181', 'user2@pasc.in', 3, '', 4, 133),
(178, '2019-08-22 12:21:44.007513', '177', 'user4@pasc.in', 3, '', 4, 133),
(179, '2019-08-22 12:21:44.010899', '179', 'user5@pasc.in', 3, '', 4, 133),
(180, '2019-08-22 17:20:03.106662', '1', 'Question object (1)', 2, '[{\"changed\": {\"fields\": [\"problem\"]}}]', 7, 133),
(181, '2019-08-22 17:47:49.663191', '1', 'Question object (1)', 2, '[{\"changed\": {\"fields\": [\"problem\"]}}]', 7, 133),
(182, '2019-08-22 20:25:42.053852', '172', 'auth object (172)', 1, '[{\"added\": {}}]', 11, 133),
(183, '2019-08-22 20:26:29.807323', '190', 'aj240502@gmail.com', 3, '', 4, 133),
(184, '2019-08-22 20:26:29.814178', '182', 'boss@pasc.in', 3, '', 4, 133),
(185, '2019-08-22 20:26:29.818033', '186', 'bsnsourav@gmail.com', 3, '', 4, 133),
(186, '2019-08-22 20:26:29.822677', '195', 'codeicted@gmail.com', 3, '', 4, 133),
(187, '2019-08-22 20:26:29.827188', '191', 'deoresakshi16@gmail.com', 3, '', 4, 133),
(188, '2019-08-22 20:26:29.832785', '197', 'hpshah294@gmail.com', 3, '', 4, 133),
(189, '2019-08-22 20:26:29.837918', '189', 'jaydoshi9012@gmail.com', 3, '', 4, 133),
(190, '2019-08-22 20:26:29.843214', '184', 'manav@pasc.in', 3, '', 4, 133),
(191, '2019-08-22 20:26:29.848968', '193', 'manlikerathish@gmail.com', 3, '', 4, 133),
(192, '2019-08-22 20:26:29.856809', '187', 'nimu.kelkar@gmail.com', 3, '', 4, 133),
(193, '2019-08-22 20:26:29.863989', '185', 'paramrpatil@gmail.com', 3, '', 4, 133),
(194, '2019-08-22 20:26:29.871092', '188', 'ramborude999@gmail.com', 3, '', 4, 133),
(195, '2019-08-22 20:26:29.876764', '192', 'sudarshanvhon1105@gmail.com', 3, '', 4, 133),
(196, '2019-08-22 20:26:29.883418', '183', 'user1@pasc.in', 3, '', 4, 133),
(197, '2019-08-22 20:26:29.896379', '194', 'user2@pasc.in', 3, '', 4, 133),
(198, '2019-08-22 20:26:29.901906', '196', 'vjyeluri31@gmail.com', 3, '', 4, 133),
(199, '2019-08-22 22:53:39.077872', '198', 'user1@pasc.in', 3, '', 4, 133),
(200, '2019-08-22 22:55:25.108163', '200', 'user1@pasc.in', 3, '', 4, 133),
(201, '2019-08-22 22:58:04.360153', '201', 'user1@pasc.in', 3, '', 4, 133),
(202, '2019-08-22 23:01:53.185433', '202', 'user1@pasc.in', 3, '', 4, 133),
(203, '2019-08-22 23:05:39.397632', '203', 'user1@pasc.in', 3, '', 4, 133),
(204, '2019-08-22 23:07:09.192478', '204', 'user1@pasc.in', 3, '', 4, 133),
(205, '2019-08-22 23:11:13.809398', '205', 'user1@pasc.in', 3, '', 4, 133),
(206, '2019-08-22 23:16:47.160055', '206', 'user1@pasc.in', 3, '', 4, 133),
(207, '2019-08-22 23:20:02.935669', '207', 'user1@pasc.in', 3, '', 4, 133),
(208, '2019-08-22 23:21:27.735765', '208', 'user1@pasc.in', 3, '', 4, 133),
(209, '2019-08-22 23:24:43.826724', '209', 'user1@pasc.in', 3, '', 4, 133),
(210, '2019-08-22 23:33:34.603516', '210', 'user1@pasc.in', 3, '', 4, 133),
(211, '2019-08-22 23:48:34.074106', '211', 'user1@pasc.in', 3, '', 4, 133),
(212, '2019-08-22 23:53:16.111291', '212', 'user1@pasc.in', 3, '', 4, 133),
(213, '2019-08-23 00:31:40.084854', '67', 'Scores object (67)', 3, '', 10, 133),
(214, '2019-08-23 00:31:40.092565', '66', 'Scores object (66)', 3, '', 10, 133),
(215, '2019-08-23 00:31:40.097294', '65', 'Scores object (65)', 3, '', 10, 133),
(216, '2019-08-23 00:31:40.106444', '64', 'Scores object (64)', 3, '', 10, 133),
(217, '2019-08-23 00:31:40.110202', '63', 'Scores object (63)', 3, '', 10, 133),
(218, '2019-08-23 00:31:40.114142', '62', 'Scores object (62)', 3, '', 10, 133),
(219, '2019-08-23 00:31:40.117895', '61', 'Scores object (61)', 3, '', 10, 133),
(220, '2019-08-23 00:31:40.121759', '60', 'Scores object (60)', 3, '', 10, 133),
(221, '2019-08-23 00:31:40.125744', '59', 'Scores object (59)', 3, '', 10, 133),
(222, '2019-08-23 00:31:40.129483', '58', 'Scores object (58)', 3, '', 10, 133),
(223, '2019-08-23 00:31:40.133531', '57', 'Scores object (57)', 3, '', 10, 133),
(224, '2019-08-23 00:31:40.138039', '56', 'Scores object (56)', 3, '', 10, 133),
(225, '2019-08-23 00:31:40.142573', '55', 'Scores object (55)', 3, '', 10, 133),
(226, '2019-08-23 00:31:40.147202', '54', 'Scores object (54)', 3, '', 10, 133),
(227, '2019-08-23 00:31:40.151822', '53', 'Scores object (53)', 3, '', 10, 133),
(228, '2019-08-23 00:31:40.182387', '52', 'Scores object (52)', 3, '', 10, 133),
(229, '2019-08-23 00:31:40.208386', '51', 'Scores object (51)', 3, '', 10, 133),
(230, '2019-08-23 00:31:40.214206', '50', 'Scores object (50)', 3, '', 10, 133),
(231, '2019-08-23 00:31:40.219155', '49', 'Scores object (49)', 3, '', 10, 133),
(232, '2019-08-23 00:31:40.224674', '48', 'Scores object (48)', 3, '', 10, 133),
(233, '2019-08-23 01:02:42.401852', '213', 'user1@pasc.in', 3, '', 4, 133),
(234, '2019-08-23 01:05:03.327977', '214', 'user1@pasc.in', 3, '', 4, 133),
(235, '2019-08-23 01:08:01.842611', '215', 'user1@pasc.in', 3, '', 4, 133),
(236, '2019-08-23 01:08:37.550531', '216', 'user1@pasc.in', 3, '', 4, 133),
(237, '2019-08-23 01:12:31.615395', '217', 'user1@pasc.in', 3, '', 4, 133),
(238, '2019-08-23 01:45:32.195133', '323', 'Question object (323)', 3, '', 7, 133),
(239, '2019-08-23 01:45:32.202205', '322', 'Question object (322)', 3, '', 7, 133),
(240, '2019-08-23 01:45:32.205460', '321', 'Question object (321)', 3, '', 7, 133),
(241, '2019-08-23 01:45:32.209066', '320', 'Question object (320)', 3, '', 7, 133),
(242, '2019-08-23 01:45:32.212867', '319', 'Question object (319)', 3, '', 7, 133),
(243, '2019-08-23 01:45:32.216469', '318', 'Question object (318)', 3, '', 7, 133),
(244, '2019-08-23 01:45:32.219803', '317', 'Question object (317)', 3, '', 7, 133),
(245, '2019-08-23 01:45:32.221467', '316', 'Question object (316)', 3, '', 7, 133),
(246, '2019-08-23 01:45:32.224467', '315', 'Question object (315)', 3, '', 7, 133),
(247, '2019-08-23 01:45:32.227878', '314', 'Question object (314)', 3, '', 7, 133),
(248, '2019-08-23 01:45:32.229696', '313', 'Question object (313)', 3, '', 7, 133),
(249, '2019-08-23 01:45:32.233222', '312', 'Question object (312)', 3, '', 7, 133),
(250, '2019-08-23 01:45:32.237532', '311', 'Question object (311)', 3, '', 7, 133),
(251, '2019-08-23 01:45:32.242406', '310', 'Question object (310)', 3, '', 7, 133),
(252, '2019-08-23 01:45:32.247786', '309', 'Question object (309)', 3, '', 7, 133),
(253, '2019-08-23 01:45:32.252938', '308', 'Question object (308)', 3, '', 7, 133),
(254, '2019-08-23 01:45:32.257998', '307', 'Question object (307)', 3, '', 7, 133),
(255, '2019-08-23 01:45:32.262474', '306', 'Question object (306)', 3, '', 7, 133),
(256, '2019-08-23 01:45:32.267100', '305', 'Question object (305)', 3, '', 7, 133),
(257, '2019-08-23 01:45:32.271610', '304', 'Question object (304)', 3, '', 7, 133),
(258, '2019-08-23 01:45:39.550456', '303', 'Question object (303)', 3, '', 7, 133),
(259, '2019-08-23 01:46:26.686047', '169', 'Question object (169)', 3, '', 7, 133),
(260, '2019-08-23 02:06:08.356961', '218', 'user1@pasc.in', 3, '', 4, 133),
(261, '2019-08-23 02:06:18.215479', '199', 'deoresakshi16@gmail.com', 3, '', 4, 133),
(262, '2019-08-23 02:09:32.749195', '219', 'user1@pasc.in', 3, '', 4, 133),
(263, '2019-08-23 02:13:56.541566', '220', 'user1@pasc.in', 3, '', 4, 133),
(264, '2019-08-23 02:14:05.146206', '1', 'Scores object (1)', 3, '', 10, 133),
(265, '2019-08-23 02:24:27.425360', '221', 'user1@pasc.in', 3, '', 4, 133),
(266, '2019-08-23 02:33:13.999201', '3', 'Scores object (3)', 3, '', 10, 133),
(267, '2019-08-23 02:33:14.004085', '2', 'Scores object (2)', 3, '', 10, 133),
(268, '2019-08-23 02:37:01.618682', '222', 'user1@pasc.in', 3, '', 4, 133),
(269, '2019-08-23 03:31:03.773022', '172', 'auth object (172)', 1, '[{\"added\": {}}]', 11, 133),
(270, '2019-08-23 04:32:09.123283', '223', 'user1@pasc.in', 3, '', 4, 133),
(271, '2019-08-23 04:35:30.820739', '224', 'user1@pasc.in', 3, '', 4, 133),
(272, '2019-08-23 04:35:42.768733', '4', 'Scores object (4)', 3, '', 10, 133);

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(11, 'questions', 'auth'),
(7, 'questions', 'question'),
(10, 'questions', 'scores'),
(9, 'Scores', 'scores'),
(6, 'sessions', 'session'),
(8, 'test_submit', 'scores');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2019-06-30 13:35:00.564237'),
(2, 'auth', '0001_initial', '2019-06-30 13:35:00.732599'),
(3, 'admin', '0001_initial', '2019-06-30 13:35:01.309169'),
(4, 'admin', '0002_logentry_remove_auto_add', '2019-06-30 13:35:01.429526'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2019-06-30 13:35:01.443486'),
(6, 'contenttypes', '0002_remove_content_type_name', '2019-06-30 13:35:01.569100'),
(7, 'auth', '0002_alter_permission_name_max_length', '2019-06-30 13:35:01.582427'),
(8, 'auth', '0003_alter_user_email_max_length', '2019-06-30 13:35:01.603370'),
(9, 'auth', '0004_alter_user_username_opts', '2019-06-30 13:35:01.618331'),
(10, 'auth', '0005_alter_user_last_login_null', '2019-06-30 13:35:01.691136'),
(11, 'auth', '0006_require_contenttypes_0002', '2019-06-30 13:35:01.694129'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2019-06-30 13:35:01.719061'),
(13, 'auth', '0008_alter_user_username_max_length', '2019-06-30 13:35:01.742998'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2019-06-30 13:35:01.772917'),
(15, 'auth', '0010_alter_group_name_max_length', '2019-06-30 13:35:01.789873'),
(16, 'auth', '0011_update_proxy_permissions', '2019-06-30 13:35:01.803836'),
(17, 'questions', '0001_initial', '2019-06-30 13:35:01.855417'),
(18, 'sessions', '0001_initial', '2019-06-30 13:35:01.891321'),
(19, 'test_submit', '0001_initial', '2019-07-07 11:47:06.039550'),
(20, 'Scores', '0001_initial', '2019-07-07 12:01:23.885018'),
(21, 'questions', '0002_scores', '2019-07-23 17:39:03.242529'),
(22, 'questions', '0003_auto_20190812_1353', '2019-08-20 11:26:50.042294'),
(23, 'questions', '0004_auto_20190812_1413', '2019-08-20 11:26:50.083333'),
(24, 'questions', '0005_scores_created', '2019-08-20 11:26:50.093650'),
(25, 'questions', '0006_auto_20190819_0100', '2019-08-20 11:26:50.112335'),
(26, 'questions', '0007_scores_name', '2019-08-21 11:42:19.791963'),
(27, 'questions', '0008_auth', '2019-08-22 13:33:00.733171');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('05t3o1gwfq2nca6v81lir3o7qmzb1en5', 'NmFmYTliZTBlYTg4ZmVmOTIzNTQ5NDQ3YWU3N2M3N2JmZjIxYTUzMDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6InNyeWJRZU1hb1Z2bHB1dXY5V1F4IiwibmFtZSI6IkFudWoiLCJfYXV0aF91c2VyX2lkIjoiMTQ3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI1MzE3NjI1NTMxMDFjZTFkNjI1ZWVhMDUwZGNkOWJlM2YyNzhiNWUzIiwicXVlc3Rpb25zIjpbNzI1LDEwLDc4Myw2MDUsNzYwXSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIxMTIzNTQxfQ==', '2019-09-04 06:40:41.102153'),
('0vy75ncu0luc5dcd0evifpu8o1bnfq2m', 'NjA1Mjc0MDkwMzg4MDBiOWRjZjY5NzlhNDJjYjY0Yzk4MDY0MzAyYTp7Il9hdXRoX3VzZXJfaWQiOiI0NCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYWQwMTBmOTIwYjc0ZTlmOThhOTljNTQwYTcxZjRmOGM5OTlhNTM2OCJ9', '2019-07-18 15:23:01.426375'),
('130zu9ps04k61fd5ik5p0088qn6yze1t', 'MDU0NWYzNjFmYWU2OWU4ZWFlMmJlMDQxNzRiMWE5NDk1YTAxZDNjNjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI2NTMzNmNkZThhNjhjZDY2YzNlYmJjYWYxMjZkZDRlNTExOWE3NDYwIn0=', '2019-07-18 11:44:05.251753'),
('1liujy1uycoe4j0mvacswtaew3stea1s', 'OTNjMjRhNzZjZWQzNjMxMjMzMGQ2MzY1NmMwYTNhZGUwZGMwNjQyMDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6Ikthd1NheE5OQm1qdDdGMGhPaTJsIiwibmFtZSI6IlVzZXIxIiwiX2F1dGhfdXNlcl9pZCI6IjE1MSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZWFjZjg2M2E1ZDA5MDE1MDJiNGVhMTU0ZTI0ZjViZjdhMzI3NGVmMSIsInF1ZXN0aW9ucyI6WzEwLDgyMyw4NzcsNjU0LDkwXSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIxMTQzMzAwfQ==', '2019-09-04 08:38:00.132304'),
('1nq98uvors5ifvqu66c8vtwtc9powoke', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 15:38:44.474962'),
('1o4o46ikott4rg7z7p5c6nukmgm9wara', 'ZTAzMDI4M2NlNDkyZWJmYTM3ZmM0MjgyNDlkYWFjZWM0ZjMzNjc2Yjp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6Ikthd1NheE5OQm1qdDdGMGhPaTJsIiwibmFtZSI6IlVzZXIxIiwiX2F1dGhfdXNlcl9pZCI6IjE3NCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYzRkYzdjODM5MjQ5YjQyODcwNTEyYWFmN2I4ODJhMmU1ZmIwOWQ2NiIsInF1ZXN0aW9ucyI6WzEwLDEsMjA1LDYyMSw1NiwxNDUsMTk2LDcxNSw3Miw3ODgsNTM2XSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIyMTAyOTU2fQ==', '2019-09-05 04:34:56.882589'),
('1zlh2ovocqrec5xkdjzmsxxen3u52eb3', 'NjhkOGRmN2FkMDk1MzIxODk1ZDMwNjBjZGVkZTU1M2MyOTkwYWQ5ODp7Il9hdXRoX3VzZXJfaWQiOiIxMzMiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6ImQ3ZWM4MDY1YTIwZjEzOTI1Y2VmNmNhNzNkMGE3NDc2ZGUzZGI1ZGQifQ==', '2019-09-05 12:14:12.282612'),
('2tskt7yit7kvrgq8mmxnyo78cmsa05ax', 'ZDQ3ZDFkNzAyMDYwMmFlMTg3NGNlYjdiODA3OGFiNTI1ZGY5MTJhMzp7Il9hdXRoX3VzZXJfaWQiOiI1NyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiN2I5NzQ1OGFlNTM0OWZiOWE5ZDk1ZjJhZTdkNGVhNGM2MGM5Mzg5MiJ9', '2019-08-04 15:38:27.630760'),
('39fulc47a5951400s1rf62ae4da0y0ug', 'MDhhZjBjODBmZmNlZjNjNjlkZjgyM2ZkYjg2ZmMxNTExZTY1NTM5YTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTQyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIwZjFiZWZlNzM2YWY3MzQ0ZTQ5ZjY1MzYyYWFiNjdkNzEzZTQxZDM1IiwicXVlc3Rpb25zIjpbMjczLDU4MSwzNjIsMTAsNTgyXSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIxMTE0NDAzfQ==', '2019-09-04 05:49:03.210813'),
('48tysrp6oibvyfbgk1178b43e7bytiq8', 'NzZlYTJiMWM2NGUwZGQ2Y2FmYmYyNDFkY2Q2YWFmNzFlY2Q5Y2VmYTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6IjBIVUFQTkc1dDVsT1JVbmo4VmtkIiwibmFtZSI6InZlZCBiaGF0YXdhZGVrYXIiLCJfYXV0aF91c2VyX2lkIjoiMTYyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIwYmI1MjNhMmQ5ZWU5NjM3MzVlYWEwNjQxODJhYmYxNTUzNTA3MzM1IiwicXVlc3Rpb25zIjpbMTAsODI0LDUxMSw4NDcsNjM3LDQxLDI5Niw4NDksMzIzLDU5NiwzNjZdLCJzY29yZSI6MH0=', '2019-09-04 14:33:21.742937'),
('4c9y7baoonfcf1jzrwnewxbvs0ka5itz', 'YjFmYTNlMDNkMjU1NTA0NTkwMDBiMmI1OWVkOTc0ZTc1YTA1YWU4ODp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJTdWRhcnNoYW4gSG9uIiwiX2F1dGhfdXNlcl9pZCI6IjE5MiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNTNmOGEyMTAxYmE1NGRlNTc0ZjQ3NjU0NmM4MjMyN2M1OWYyYTBlYiIsInF1ZXN0aW9ucyI6WzEwLDEsNzQsNTY4LDI2MCw2OTIsNjY4LDY4LDIwNyw3OSwyNF0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMjIzNDUxNn0=', '2019-09-05 17:50:16.572378'),
('4jkt7eggbtivax4e1w0jqyt4qkfwvxos', 'MTdiMTc1ZmRiOTliMzhhMTcwNGIzYzUyM2FjYjM3MGEzZjE1MjkyYjp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6IkJyTEhjbUJWdVdvdk9JSUJwTWl4IiwibmFtZSI6Inlhc2giLCJfYXV0aF91c2VyX2lkIjoiMTY3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjYTZkYTlmZmIzMWZjYzY5MDdjOWYzMDk2ODk0OTAxZDQzYzdkNDAyIiwicXVlc3Rpb25zIjpbMTAsNjUyLDYyLDgyMywzMTMsNzEyLDQ1LDgxMSw4MzUsNjc3LDU5Nl0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMjAwNTY1NH0=', '2019-09-04 19:01:54.033224'),
('52ouomaarx5od0tp19fdbtk7atvy0w47', 'MDBmNjM4NDBiZDkxNWYzZmFmYmFhMWJiM2U0NmU5NmViMWE3MTQwMDp7InVzZXJpZCI6IlRGVVREV0ZRV2NmV0hCU0VaamEwIiwiX2F1dGhfdXNlcl9pZCI6IjI5IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3YjE0ZTg3NDEyMjZjNDFiZmIxZmY1YzQ1OGRiNmU5YjRlM2NiMDM1IiwicXVlc3Rpb25zIjpbNSwxNzcsNTgzLDQ0NiwzNTYsMzEyXSwic2NvcmUiOjF9', '2019-07-18 12:31:57.185407'),
('5d7u4bge46ikbz9kbhw4fga9504m6ukc', 'MGYyNmM0NmFhMjA4ODRiNmIxODAzOTUzZDBkMTgwMzAwZDdlMmRkNzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-04 10:08:20.238562'),
('5ffk2j2xyyklu1wsfd2ki01lppydo4n2', 'YzJiMzRjMzQ1NTExNjZjNDMwOWZhY2FmYjNmOTI5Mzg3MGQ4YTA3Mzp7Il9hdXRoX3VzZXJfaWQiOiI0MiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMzdlNDlkYWQzYzcyMmRmZDVjOWMyYjlkMjJlMzZmYmQ1ZDg1YWFjYiIsInF1ZXN0aW9ucyI6WzUsNjAzLDU1Nyw3Niw2Miw4NTFdLCJzY29yZSI6MH0=', '2019-07-18 12:49:14.573032'),
('5srba8ah2qt25sw4tyigzty1klib7m2w', 'MjE1YmUwODg5MWUzMThmMjViZmQ3NDRmYjBmZjAxOGFhMDg5OTNkZjp7Il9hdXRoX3VzZXJfaWQiOiIxMCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYjcxN2RhZjEyM2EwNTIzYTZiMWMzZmYwMzJhNmZmZDg5N2IxY2IxNiIsInF1ZXN0aW9ucyI6WzUsNzkwLDc5OSw0MDUsNjAzLDI1MV0sInNjb3JlIjowfQ==', '2019-07-17 15:26:31.525935'),
('5vdwr5088yxdu9d2l0w1tekc0ajdqreu', 'YWY4Zjk5ZGNhZDA5ZWNlOGIxYTcwYmI2OTE2NTFjYmFhYWU0OTIwNTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTUwIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyZjdkMzk1OGYyZTAyYWQ5OTY1OTg5OGM5ZTY0ODBmYTY5NmQ0ZDE3IiwicXVlc3Rpb25zIjpbMTAsODksMzcwLDY4MCwxODRdLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjExMzMwNTF9', '2019-09-04 07:35:51.384969'),
('6ckvg6kh20y5mpj6af9kugr003d7uqgv', 'NjYyNTcwZmYwMjQxY2JmNTcyMGUzNDMxY2JlNTcyY2UxNDg4ZTkxNTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJHdXJ1amkiLCJfYXV0aF91c2VyX2lkIjoiMjA0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI2NDNjZDg4OTdmNWQ0Yjg0Mzg1MDBhZTc0YmY3ZTZhOGRiYjBhY2M3IiwicXVlc3Rpb25zIjpbMTAsMSw3MSwxMDMsMzAyLDU5MywyNTMsNzcsMTM1LDMxMiw4MDRdLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjMwNTAxMDR9', '2019-09-05 23:06:04.531285'),
('6mrvz04lumrazz7j2j1gm7dmxh572jk7', 'ZTkyNTAxOTMzOTcwNTU0MWViMzA5NjVhMjVkMTY2MzM4MDk1NmNkNzp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImJwUGhCZWM3Y2I1T0tzZEpGeEtoIiwibmFtZSI6Im1hbmF2IiwiX2F1dGhfdXNlcl9pZCI6IjEzNSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZGZiZjM2MDVhMjc3ZmQ3NDBiODc3YjE2M2JmNjQzMWNiOWMyNDJkYiIsInF1ZXN0aW9ucyI6Wzc2OCwxNDksODI5LDEwLDg1M10sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMDE4MTA1OH0=', '2019-09-03 12:15:58.449837'),
('6t5e7rg7mkk0maki4gvf9omozq7j8uyo', 'ZDU3NDBjNDI0YmZhOTA3ZDY3MmYxMDA5OWJmMzFiNjJmNGU2N2UwZDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImRUMFk3ejNFUGZLanh6SXFhUEEzIiwibmFtZSI6IlVzZXI0IiwiX2F1dGhfdXNlcl9pZCI6IjE0NSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDg3ODRlMWYzZjU5MTMwOTg3NzNmYTE4NzI3NzYzYzcyZWM4OWUyNiIsInF1ZXN0aW9ucyI6WzUyLDE2NywxMCw2NCw0MjldLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjExMjM1NDB9', '2019-09-04 06:40:40.479376'),
('6uifovek4reqauadfswcafg64zteol0k', 'NDQyNjExOWQ2ZjlkNDQxZTdiYmYzOWMzOTljYmVkZDBjYjVjZjJkZjp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6Ikthd1NheE5OQm1qdDdGMGhPaTJsIiwibmFtZSI6IlVzZXIxIiwiX2F1dGhfdXNlcl9pZCI6IjEzNiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiODVkYmVkY2YwYjM2Y2M5ZDE5YjBiMDU0NDFhNGE2Y2UxZWMxZGY4OCIsInF1ZXN0aW9ucyI6WzM4NCwyNzEsNTM4LDEwLDQ5MF0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMDE4MzcwOH0=', '2019-09-03 12:42:08.941496'),
('6wxptg1qzopcwzj427hd00fthmx83r7e', 'ZmRjM2ZhZjc2NjY0MzgxMDg2MTBmOTFiMGVjZGZkMzRhNDIxZDI2OTp7InF1ZXN0aW9ucyI6WzQ5LDM4MCw0NDQsMTg2LDgxMSw2NTksODIsMzEyLDMzMCwyMTYsMTYxLDgyMSwzNzQsNjI1LDgwNCw2MTksNDYxLDM5MywyMjAsNTcwLDMyMyw2NzcsNjA2LDUwMyw3NzYsNzc0LDUxNiwxNTcsMzY0LDY5NCw1ODEsMzgzLDU1OCw4MTAsNDQsNDgxLDIxNCw1MDMsMjMxLDI5NCw4NDIsNzUzLDYwNyw3MTUsNDMxLDM4NSwyMzcsMTczLDcyOCwzNDFdLCJzY29yZSI6MH0=', '2019-07-31 19:12:10.523242'),
('6zlym8tkbbas7s8qu880hzo8d739u4j2', 'NjVhZTg4YTE2MDdkZjY4YTI2ZWYzYzI1OWM5OTIxMWNhMjc1YjEwZTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6IkpHaUdpa2Nhd3dIbk5Vdm5vM2RqIiwibmFtZSI6IlVzZXIzIiwiX2F1dGhfdXNlcl9pZCI6IjE0OCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiY2FkNmVjMzRhNDVlYzA5N2I5ZDViZjc0NWJjYzg2N2I5ZmM4YTE1NiIsInF1ZXN0aW9ucyI6WzUzOSw2NjksNTg2LDEwLDU3OV0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMTEyMzYwN30=', '2019-09-04 06:41:07.136372'),
('7fa3gjty7o8wbsfdky3ffb1sfnzojgr6', 'ZTgyYTczZTYyMjkzNTc4ZjQwZDdkZWJhNTQ2YTEwMjhmZDBhZTQxNzp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6InRBdng3dmtrdXpNd3hmbTQ1RXh0IiwibmFtZSI6IlVzZXIyIiwiX2F1dGhfdXNlcl9pZCI6IjE0NCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNTA5Y2RiMzE2NTZiNjlkNDM1ZGRhOTcyOTgzMzI5YWRkY2JjNWVhNiIsInF1ZXN0aW9ucyI6WzQxNiw3NzIsMTAsNjM5LDUyM10sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMTEyMzUyOH0=', '2019-09-04 06:40:28.500332'),
('8icjpm5cwmejj93rd0t0npgzbprsbz8z', 'ZDQ3ZDFkNzAyMDYwMmFlMTg3NGNlYjdiODA3OGFiNTI1ZGY5MTJhMzp7Il9hdXRoX3VzZXJfaWQiOiI1NyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiN2I5NzQ1OGFlNTM0OWZiOWE5ZDk1ZjJhZTdkNGVhNGM2MGM5Mzg5MiJ9', '2019-08-04 12:39:33.682526'),
('8ihfvaj1sgizofx8j3z9g0f1odwwh8bf', 'NDgxMWMzNjg0OTEyNDkzYTNiNDQ0Y2NlODFhNjk2NmU2OGI3ZjI5ZDp7InVzZXJpZCI6IkpHaUdpa2Nhd3dIbk5Vdm5vM2RqIiwiX2F1dGhfdXNlcl9pZCI6IjYxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI1MDJkMTQ1NjYxNWNhOWQyOGM4MGViYTg1OGU5OTBjOTQ4ODBmNTZlIiwicXVlc3Rpb25zIjpbNDksMjUwLDQ1OCw3NSw3OTEsNzkyLDU5MiwyOTgsNTM2LDQ4Nyw2MDksNTI4LDc4OCw2ODYsODAyLDc2MywxMTIsMzk5LDc2NiwzMjcsNDk3LDczNCw3Miw0NTQsNTgwLDEzNyw3OTMsNDQ0LDU5Nyw0OTAsNjUxLDIxMiw4NzMsNDcyLDksNTEzLDI3MywzNzksNjc1LDU5LDM5Niw1MjYsMjM3LDY1NCwzMjEsNDUzLDMwNSw4MTQsMTM4LDcxOF0sInNjb3JlIjowfQ==', '2019-07-31 16:47:44.591118'),
('8jrssl597z7d5b2c9h65j0icta1p7l66', 'NTFkOWE5NTgxNjAyNGFlYWQ3NDk1NGRmY2Y3OTQ5YjhmMTY2ZGVhMTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTU4IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0OWVkMmMyOGFiZTVlMzM3M2I2MDY5Yjg1MWNiOTAyNWNjMzEyODI5IiwicXVlc3Rpb25zIjpbMTAsNDIwLDg2MSw5Nyw3NjgsNzQ0LDc4Nyw1OTgsODQwLDUxNiwzMzVdLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjExNzU2MTd9', '2019-09-04 12:01:17.971052'),
('91z2p48ld1rso9mlhcfn1hqwhe7kkljd', 'YTFlNTYwYjg4MWZkMDhjN2IxOGE0ODQ5OTI3MzU2ZmM1MTcwZmRkNzp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6InRBdng3dmtrdXpNd3hmbTQ1RXh0IiwibmFtZSI6IlVzZXIyIiwiX2F1dGhfdXNlcl9pZCI6IjE3MiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMTA5MmYzODBmZGRjOGNhODc2MzRhMTY0ZmVmMmE5YTk0MmEzYjQwNiIsInF1ZXN0aW9ucyI6WzEwLDEsOTAsNTU1LDU4NCw3MDUsODI4LDM5OCw2ODksNTk2LDMwM10sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMjEwMDAxNn0=', '2019-09-05 04:05:16.263797'),
('aszkdvhzf03dctz7ey5woep2n7dwa5kp', 'ZDQ3ZDFkNzAyMDYwMmFlMTg3NGNlYjdiODA3OGFiNTI1ZGY5MTJhMzp7Il9hdXRoX3VzZXJfaWQiOiI1NyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiN2I5NzQ1OGFlNTM0OWZiOWE5ZDk1ZjJhZTdkNGVhNGM2MGM5Mzg5MiJ9', '2019-07-31 13:56:54.632038'),
('aumh0m489i9d2rgmx3kpjonss9i410e3', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 15:26:25.577583'),
('ay314omsfrjuh1cy6s5y80f6d5tl0q3z', 'MmQ3NWQwOWI1N2IxY2JmYWJlYTcxMmM4ODZjN2U3NGE1ZDBiMmE2OTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJOaXJtYXlpIEtlbGthciIsIl9hdXRoX3VzZXJfaWQiOiIxODciLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6ImNjYzJkOTkzMGRmMDc4ODFkZjUxZDM2NTQwYzU0ZDc2MDI4NWY5ZDQiLCJxdWVzdGlvbnMiOlsxMCwxLDgyMywyNyw0MTEsNDgxLDY0OSwzNTgsNTMsMzY2LDcwMV0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMjIxMzUyMH0=', '2019-09-05 15:40:20.576203'),
('b9yqad3n5h7yhulqqb85fijtubrgenil', 'N2E5ZmZkN2ZmZGIzZGVkMDFhMGM3ZmVhMWEzMWY5YTI2NjA1Njc3Mzp7InVzZXJpZCI6IjByUmpBc1VXNkVtM2syQmtPdzV6IiwiX2F1dGhfdXNlcl9pZCI6IjY5IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0ZjBjYjA3YmZmMGM3MDI4YmQyNzZmZTc2ZDA5OGI4ZDdmMThiOTYzIiwicXVlc3Rpb25zIjpbNDksNjE3LDUwNiwxMTYsMjIsMjIwLDEwLDUwOCw3ODUsNTM5LDM0MCw2MjYsMTE3LDQ3Miw0MzQsNDY4LDQyNCwzNDMsNjkzLDY3Miw1MjgsNzIsNzQ4LDM4MCw1NCwyMjcsMzEzLDIxMyw3NjYsNTMsNDA1LDMyNyw4MjIsNTc2LDE5MywzNTgsMTE3LDM1Nyw3NTEsODQwLDQyMiw3NjgsMjg0LDU1OSw2OTMsNjU5LDE2OCw0MDUsODksMjQ2XSwic2NvcmUiOjB9', '2019-07-31 19:16:17.754187'),
('b9yrot6vgb7hwyfetg5jxzf47gbt76qp', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 12:12:30.720509'),
('bejeeqtb94nk5aaphisdobfadiartl9y', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 14:41:23.785270'),
('bv3j643rt7k6cwdz3grbof25r4mt1khp', 'MTgyZDZmMzgzOWRiOTFhYzhlNjU4NTJlZWFhNzk5ZmRjZmZiM2NmODp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6Ikthd1NheE5OQm1qdDdGMGhPaTJsIiwibmFtZSI6IlVzZXIxIiwiX2F1dGhfdXNlcl9pZCI6IjE4MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiN2ZkODUzZDY3NDdjYzNlNDYyNTA5ODM2ZGM5NmJjZGI2MzU5YmJjZiIsInF1ZXN0aW9ucyI6WzEwLDEsMjIwLDc0LDM3NCwyOTcsMzk4LDU5OCwxOTMsMTEzLDUzNF0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMjEwNTQyNX0=', '2019-09-05 04:59:25.041827'),
('bvajs1ttx2j0oswsav6rc7ioydlr0mgp', 'MmRmYzgxY2E5MzIwZWE2OGQ0ZTgxN2IzZmMyZTE2NmY0ZGI5YjMzMjp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6Ikthd1NheE5OQm1qdDdGMGhPaTJsIiwibmFtZSI6IlVzZXIxIiwiX2F1dGhfdXNlcl9pZCI6IjEzNCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZmE4MjE0NWVjOGZjYmEzNzk3ODhhMzA0MTRhZmNhMTcyNTZjNjIxMyIsInF1ZXN0aW9ucyI6WzY2Niw2MDEsNDE5LDEwLDc4XSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIwMTgwOTQwfQ==', '2019-09-03 12:14:40.658184'),
('bykshnl8p21wda67o93ycfo4e6ne8ka2', 'OTU5YWYwODc4YWY3YzUxYWNkNDA3YjQwNTg0NDJhYmIzNjI5N2U4ZDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJHdXJ1amkifQ==', '2019-09-06 01:08:04.847730'),
('c8ha9incisq0lh2975ljvt604wofk6t0', 'Mzg5ZGUyMzc0Y2YwYTRlZTA4YzUwMzg0ZGNhOTU3M2RjOTM5NWY0ZDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6Ikthd1NheE5OQm1qdDdGMGhPaTJsIiwibmFtZSI6IlVzZXIxIiwiX2F1dGhfdXNlcl9pZCI6IjE0MyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiODNjMWI3ZDBhNmE0YzQ1MGRlNzM1N2NkMTk2N2UzNzk3ZmY4NGI1YyIsInF1ZXN0aW9ucyI6WzU1MiwxMCwxNTYsODc2LDIzOV0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMTEyMTM0NX0=', '2019-09-04 06:18:45.241734'),
('cqwzvj5r1p09qxz34w1bl0wzi9n0r5he', 'OTU5YWYwODc4YWY3YzUxYWNkNDA3YjQwNTg0NDJhYmIzNjI5N2U4ZDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJHdXJ1amkifQ==', '2019-09-06 02:07:22.510467'),
('cxw97p4e3veg3261dao9mzgi9qp2x06m', 'OTU5YWYwODc4YWY3YzUxYWNkNDA3YjQwNTg0NDJhYmIzNjI5N2U4ZDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJHdXJ1amkifQ==', '2019-09-06 01:05:35.977716'),
('dggacgrj2lrv797ijky1bqkjff0gu2wq', 'YTA4NWYyMGQ5NjYzYTkwZmZiMWVkZWQzYzdhZWZlYzkwNWMwMWVhODp7InVzZXJpZCI6IjBxUDdIbXNqOHZtTzBwQkZ0ZzFJIiwiX2F1dGhfdXNlcl9pZCI6IjkiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6IjcwM2NjZjZmODJiOGJhZTRiZTNkZTMxOWJhNmNlYWJmZmY3YzRmMzgiLCJxdWVzdGlvbnMiOlsxMCw1MzMsNzc1LDIxNyw1ODIsNzUzLDI4MSw3MDgsNzQxLDczMywyMjZdLCJzY29yZSI6MH0=', '2019-07-17 14:46:50.186936'),
('dqn2ru8nj6bsehng53xuc5v5jb8ynapt', 'NjBmODQ1Nzk0YmRkODk0NTZkZTdmZmQzNDYyNzZiZjM4NWIxZjNiMTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImFtSWp4ZkdJdzd5OU9KbzE2WG1ZIiwibmFtZSI6InJhZ2hhdiIsIl9hdXRoX3VzZXJfaWQiOiIxNDEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6ImI1ZTZmN2Y1MGMyM2ZhOTgzMTJlMGY1NGQ3MTkzY2MxZTY1OGUwNDMiLCJxdWVzdGlvbnMiOlszMCw1MTcsOTksMTMyLDEwXSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIwMjAyMTM2fQ==', '2019-09-03 14:26:36.332790'),
('dwrrph69s73o0fyb4dyw1cpmbiiqt1v3', 'YzVjOGNkNTI5ZmU3YzA5YjkyOTFkMDNlYmU2MTliYzllMzJiOTFjZDp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 18:56:43.090252'),
('e377d1p78c46ppnz1u86jpnn9x3pvgm4', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 21:41:53.703204'),
('e3yewfczhxnje5i4i6jr41se9mcn9k8u', 'YjVmODFiOWNjMzM4ODIyMWQzYTdhNWNkYWJiNDY3ZTVmY2RkNjliYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 04:52:49.378862'),
('es2ql4320pwxt8ht3hidd19ub9b2fwix', 'YWIzOGY2M2EzNDMzZDg3ZjkzNTFkY2I1YWY0NmQzMzliNDZhNTY2NTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJHdXJ1amkiLCJfYXV0aF91c2VyX2lkIjoiMjAyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI1MmU4M2I4NjdmNDYwMzVhZGVjNGMwNjYyMGE1ZGRlNzJjNGMzYzU3In0=', '2019-09-05 22:58:15.599608'),
('f1mzkb2s7x0bv0lbqbq2zi1aamlk2jug', 'MTJmZmJiYzBhY2FhODdkODU2MDZhMTk2OTVhNDg3MzY1OWU4ODEzNzp7InVzZXJpZCI6InRBdng3dmtrdXpNd3hmbTQ1RXh0IiwiX2F1dGhfdXNlcl9pZCI6IjU5IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkYmRmYmNmNmI1YjRmMjY3ZTVmMjZkZGNiOTdlMjBlM2JlNzAyMDNlIiwicXVlc3Rpb25zIjpbNSw4MTQsODIyLDI2Miw1NTAsNDAxXSwic2NvcmUiOjB9', '2019-07-31 14:26:49.233092'),
('fg1bvvofdce3i8z8r420v3h8esl8v6q5', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 14:45:20.081128'),
('fiugcdek4leatj1obh5aug0kcdktdx9c', 'MGFlYjMwYTA4YzBhNTZiODRmODQ1YzUxNjdiOGU0MGViZjYzYmU1ZTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJzYWtzaGkiLCJfYXV0aF91c2VyX2lkIjoiMTk5IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJiODY0OGIzZDQ3ZTMxNjJlNGJmN2Q5N2IxMWRhZTI1YmJiZDk3ZWVjIn0=', '2019-09-05 22:50:45.681582'),
('g3dosry92ez92wfqg9so26qhlat0imks', 'ZmQyOTdkM2U0MDhhOGUyMGQ4NjRkYTYzM2E1NjMzNmYxZDk3NDlmYzp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTcxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJmZmI4Y2IxMmVjZDQwMDJhYjQ0M2MxYzFhYmE3OWE3ODE4NjBhM2U4IiwicXVlc3Rpb25zIjpbMTAsMSw4NiwxMjUsODQ3LDExMCw0NzAsODM5LDUwNSwxNTksNzkwXSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIyMDk1MDUwfQ==', '2019-09-05 03:55:50.238503'),
('greu3k5cmn31asn6tkpskw2fbofb7thx', 'NWNjYjE5YTI1NGMxOTA0YWM3ZmNhOTBmYjczYWUxOTU3ZDIzNzBkYTp7InVzZXJpZCI6IlRGVVREV0ZRV2NmV0hCU0VaamEwIiwiX2F1dGhfdXNlcl9pZCI6IjYyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjMjE4MTkxMDRjMmZmMTQ1OTU0MTYwMjM2YmUzN2U5MWE0Y2NmMTAyIiwicXVlc3Rpb25zIjpbNDksNzg4LDI2NywxNzMsNTAxLDc4MiwzNTcsNjMwLDcyNSw0NzksNzkwLDI2MCw4MzYsNzU1LDgwMSw3NzEsMjQyLDQyNSw4MzYsMjMwLDgzLDQ4Nyw1MDcsMjY5LDczMSwzMzEsNDM2LDM5Miw0NTgsNDA2LDMyOCwzNzQsNDEyLDEzLDg0Miw3NDQsNzkxLDI4OCw0MTQsMjkzLDExNCwyMDYsNzIwLDU2OCwzODksODUwLDQxMCwxMzIsNzA0LDM2XSwic2NvcmUiOjB9', '2019-07-31 18:15:38.501373'),
('gwkpodnuuthcu3iwo0127ryy516r3xkk', 'NmQ0NzFjY2E1NDgwMGY3Y2E1NThiNWNlYTE0MTA0OTRjZTg0MmEwMzp7InF1ZXN0aW9ucyI6WzQ5LDkwLDg0Niw2OTEsNDkxLDgzOSwyOTAsMTg4LDIzNSw1MjcsNDMsNjQ0LDYyLDg0MiwxNTAsNzgxLDU5OCwzODAsNDM1LDE4OSwyNDcsODU3LDU2NSw1OCwyMTMsNjksNjc3LDgzLDcwMCw2NjIsNzgyLDg4LDc4NSw1NzAsNzQ5LDIyLDYxMiwzMzIsODU0LDU3LDE1OSw2ODQsMjYyLDE3Niw2MTEsMzExLDczMCw2MTQsMjMsMzZdLCJzY29yZSI6MH0=', '2019-07-31 19:16:20.738170'),
('h3ldbfkepb0b9id980ms0gfwa3slf8yp', 'MjdiZjY4NmQ3MDFmZmVkNGU5MzNmMzU2NjAzNzE5OGZkODM3MGY1Nzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5MzE3NjljNDJlN2JmNDE2YWM3MzZmNzY2ODQ0NDY0OTAxZGEwZjBiIn0=', '2019-07-15 22:13:31.852363'),
('h5pqc92b75lwz18lfmj0xc9ycclky7hl', 'ZTA2NWRhYzlkNTcyMjcwYTgxMWIwMzM3N2UzNGE5N2RmMDVkMTczOTp7Il9hdXRoX3VzZXJfaWQiOiIyNyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiM2EzOGI1MGMyOTY0NjZlMjk3MTJhY2VhOTQ2YTUwYjI3MGJkOTI3YSIsInF1ZXN0aW9ucyI6WzUsNDI4LDE0MCw3MTcsNTc4LDM5Nl0sInNjb3JlIjowfQ==', '2019-07-18 12:30:20.527883'),
('hbtdtu0l7tdz1kpkdhajkyjb6t3he5yx', 'NWJkOTlkZWE1NDRjN2I4MmM3NTczMDNhYjM2NTZjYTI2YTI3NGM1Yjp7Il9hdXRoX3VzZXJfaWQiOiIzNSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiM2EwNDliNTk1YWQxNjcxMmQ0OGQwNTU5Zjc0ZDU0NTdjNGRjODk1MiIsInF1ZXN0aW9ucyI6WzUsNzMzLDQwNSwyOTgsNzUsMTFdLCJzY29yZSI6MH0=', '2019-07-18 12:35:32.051115'),
('hk8rw39nxmmrqdwrom4f21nd1spzohld', 'NmUxNTcxOWJkMTMyOWE5MjQ0ODNiZGNiNjE4YmM2OTRhNDQxYzExZjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5MzE3NjljNDJlN2JmNDE2YWM3MzZmNzY2ODQ0NDY0OTAxZGEwZjBiIiwiaGVsbG8iOjI5LCJxdWVzdGlvbiI6WzEwLDU4MSwxMzYsODQzLDIxMywxMzMsMzI5LDM2Nyw5NywxNjYsMzM4XX0=', '2019-07-15 07:01:23.334649'),
('hkzs4ki6jqxfxdx62c3hy333lbm8843y', 'N2Q3YmM3ODhiMThiOWYxZTNiNjE5MjM4YzJhNjAyM2U4ZDk1OGQ5Nzp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJHdXJ1amkiLCJfYXV0aF91c2VyX2lkIjoiMjE3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlNTcyYTNjZGIwZGJhMzhjYmJmOWZkYjg5MGE5MjRhNDQxOGI2Y2EwIiwicXVlc3Rpb25zIjpbMTAsMSw0OSw2MSwzMSwyMzQsMTEwLDEyMyw4MCwxOTIsMTg3XSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIzMDY0MTU2fQ==', '2019-09-06 01:10:57.003732'),
('hqx185lnpw120gk6xfhyghwc8tlo4pkp', 'OGZmNGQ3NTU2NzdmOWZiZmIzYWFlZGZlMGZkYjI5MzI2NWRmYjRhMDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTY4IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyMDM0ODY1YjA4NTcyNGI4ZmM0NzU3NzIyNjZhNzczNTRlZDU4YmQxIiwicXVlc3Rpb25zIjpbMTAsMSw5Miw0MTAsMzIyLDU2MCw0ODcsMjI2LDUzNiwzMzksNTg5XSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIyMDEwMjAxfQ==', '2019-09-04 19:07:01.343267'),
('hwcpktzw8t7alsdin9vevrkggxjvry6y', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 22:19:29.918617'),
('i4kvms50qd5db90ctmif9dm7mxbtfiuk', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-06 03:30:18.401069'),
('ighe236t37ajhqu7t5oxys2v2xepqaj9', 'Y2I4ODlhZDgwMGE4ODI0OTFmODgwNTRlYjkyY2U2MWRhNWRkZWI3Zjp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6IjEwdUtvdmZ6cWJ2cm0wZ3dTODJhIiwibmFtZSI6IkRldmFuc2ggTXVuZGFkYSIsIl9hdXRoX3VzZXJfaWQiOiIxNjMiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6IjMzZjdhZWQ0NTlhOGQ4YmZiYTg2NDNhN2M0MmVkMjY1MGUxYzBiZDQiLCJxdWVzdGlvbnMiOlsxMCw4MzcsMjIsNDk4LDQxNSw4NTksMjAxLDczNSwyNzEsNTMwLDU4OV0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMTIwMzcwMn0=', '2019-09-04 14:42:02.388802'),
('iqyjfz9bfq4c3nfefqapjr59f12sqdnv', 'ZGExMWJhYjQyZmRkNzFhMjliM2YwZTFkN2M3YTM1Y2Q0NDIxZTdkOTp7Il9hdXRoX3VzZXJfaWQiOiI1NyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZjkyM2E4NTQzYjJjODJiZWZkYWU5Mzc5OThjYjI1ZmEyMjk4OTI1MSJ9', '2019-08-06 18:16:13.311542'),
('ixz7yb93zxrg0y4zerrkszwao04br1rk', 'MDRjYzhhOTQyOTM5MzY0ZWZhYmJiYzg4ODFiY2NkNjdlZDFkNTAzYjp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIxNWUxMzI4NGZlZDBmZjg4ODEwYzJhMzQ0YTNkM2VlMTg1NDA1YTY2IiwiaGVsbG8iOjMxfQ==', '2019-07-14 20:57:06.351493'),
('jadyodndyqvz5z5roeskn41c27k35evz', 'NjM0Yzk0NzFlMTYwZTEzOGEwMWMwOWM0YWRhZTllNzFiYmQ0OTQwYzp7InVzZXJpZCI6InRBdng3dmtrdXpNd3hmbTQ1RXh0IiwiX2F1dGhfdXNlcl9pZCI6Ijg2IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzMjMwMjY5YzYwNWE0ZmFiMDE1Y2QzMDNiODY2ZmZkZTNlMmFiMTkxIiwicXVlc3Rpb25zIjpbMTAsODc2LDE0MCwyMDksNjgsMjY1LDcyOCwzNzksNTA5LDUzMiw4Nl0sInNjb3JlIjowfQ==', '2019-08-02 16:42:14.690381'),
('jf0ny3js8ilivnwcgg0o628jw50tmhne', 'OTQ5OGE4YTJlY2YyOWJkNDI3ODIzZTYxNTJhNzA3YWVhOGNkMTgyMDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJHdXJ1amkiLCJfYXV0aF91c2VyX2lkIjoiMjAwIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJiY2ZiNWM5YmI5YWRmZWFmNzI0ZGNjOTgwMGQ1OTQ4NTFmZjJjNTg2In0=', '2019-09-05 22:53:51.236646'),
('jgf78xq6qybgdc3j7y37poh0ymaoi08p', 'NmUxNzMyYjc1MjU1Nzk3OWZjZjdiNjAzMTk3ZTA2ZDhlMTJlOTJiYjp7Il9hdXRoX3VzZXJfaWQiOiI0NiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMWM0MDI0NDI3MzhlNGI2MDEzNzJlM2NhMGZiNDJhNDFhZTNjN2E2MiJ9', '2019-07-21 11:52:33.210530'),
('jpppctiorx9ir2n0z37lgvcixugbtak4', 'YzNiZWE3OTAyYjYxM2U4ODNkODUxMmMwZGEyYzRkNWYwZDM1MzI4NTp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIxNWUxMzI4NGZlZDBmZjg4ODEwYzJhMzQ0YTNkM2VlMTg1NDA1YTY2IiwicXVlc3Rpb24iOls1MCwzNDksMjUsMTkwLDU1Niw0OTksMzQxLDc1MSwzNTUsMzk1LDQ5Niw4MzAsNzU5LDMzNyw2NjYsNDM1LDgyNyw4NTYsNzQsMjI0LDI0Miw3NjUsMzU3LDU1NywxNTQsNjMwLDM5Niw2NzEsMTM2LDI5LDE2LDEyLDM4LDI0LDE2Miw4MDMsOCw4MTUsMTIzLDI1OCw2OTUsNDg2LDEyNCwzNjEsNzIxLDUyNywxNzYsNjE4LDExNywyMDEsNDcyXX0=', '2019-07-14 21:08:55.926486'),
('jrxwrul4eahmtwh2nnph3bts5hdt528x', 'ZDYwNmVlNmU2YTEwNzk4MzE5MzY4N2MzMjFjNGRhOGQ5Y2RlMDNmOTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6Ikthd1NheE5OQm1qdDdGMGhPaTJsIiwibmFtZSI6IlVzZXIxIiwiX2F1dGhfdXNlcl9pZCI6IjE0NiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNDA4MTEyN2JiYjgxODFiYjZhOWRhNmMzMzYwYWI4NzZiYjcwMjdlOCIsInF1ZXN0aW9ucyI6WzEwLDU0MCw4NzUsODE3LDMyN10sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMTEyMzU1M30=', '2019-09-04 06:40:53.831917'),
('k5cd1ala90lalaeb24mlhw56gfzl328m', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 21:42:28.303886'),
('k685yutjvxko3rxy88r1shuf41rckimf', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 22:20:27.068832'),
('kggwwfucq3mmq08cenubnwdxav81tga3', 'NjA1Mjc0MDkwMzg4MDBiOWRjZjY5NzlhNDJjYjY0Yzk4MDY0MzAyYTp7Il9hdXRoX3VzZXJfaWQiOiI0NCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiYWQwMTBmOTIwYjc0ZTlmOThhOTljNTQwYTcxZjRmOGM5OTlhNTM2OCJ9', '2019-07-20 03:40:20.661862'),
('kz9x007tgn9wpvkaverp64pbk63wgf72', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 21:40:46.093425'),
('l2mm2n4l36dc70omda5zj2hxntcl0vdx', 'NzRiMDRlZGNkMDFiZWI3YmY2MjFjYWZkNWFmZWE1NzExY2Y4ODFhOTp7InVzZXJpZCI6Ikthd1NheE5OQm1qdDdGMGhPaTJsIiwiX2F1dGhfdXNlcl9pZCI6IjY3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJmMDAyOGQ1Y2Q2NWRiYzQ0YmE2ODY2ZTJiNzgwNDhjZmZjMzY1NGUyIiwicXVlc3Rpb25zIjpbNDksNDY0LDUwMywxNzgsNjI5LDg1LDE0Myw1MzgsNDU1LDc3MSw4NCw2MjIsNzkwLDI4MSwxNDIsNTYxLDQ4Niw0ODEsMjk1LDExNiw0MjAsNjYzLDEwOSwyODAsNjMwLDEzNSwxMDksNjMyLDIwNyw0NTEsODEsNTY1LDUwNiw3NDEsNjA2LDM4MSwzOTIsMjY2LDI2Miw4MjQsMzc1LDQxMiwyOTgsNDc1LDc5Myw1NjksMTY3LDc0MywxMDMsNzExXSwic2NvcmUiOjB9', '2019-07-31 19:12:30.896043'),
('lf4odwobm8sz1jpt3c8tn3k28v9vcgm5', 'OTU5YWYwODc4YWY3YzUxYWNkNDA3YjQwNTg0NDJhYmIzNjI5N2U4ZDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJHdXJ1amkifQ==', '2019-09-06 01:03:34.028049'),
('lj7q79u2n9uspr9s5ec0xkmnfx1xn47s', 'YmIxMDU4ZDE1YzY0NzBlZjA5YWZkNTc3ZmNhNTRjYjhmOTc3OTQxNDp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJSYW0gQm9ydWRlIiwiX2F1dGhfdXNlcl9pZCI6IjE4OCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiODJmMDRlMjY4OTgyMzFmYjMxYjRiOTFhNjQ4NjU5YTZjMjI0ZmY0ZCIsInF1ZXN0aW9ucyI6WzEwLDEsNjEsNDI0LDc3MiwzMDAsNzc0LDQ1MywzMCw3MTMsNzBdLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjIyMTM4MzF9', '2019-09-05 15:43:31.346554'),
('lx7hx68i04mn5jjw82w3a5cvfps5a4do', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 22:38:14.098554'),
('m0ntsyvhan5ylh5gwoa7975hdyfinw87', 'MWY4YmM4MzA2YzlkY2I2MDNhNWMyYjk5NTJmYmMxYTZmNGVlZTdiYjp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6InNyeWJRZU1hb1Z2bHB1dXY5V1F4IiwibmFtZSI6IkFudWoiLCJfYXV0aF91c2VyX2lkIjoiMTc1IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJiYTExOTIyMjU3MTY0YmU5Mzg5M2IxZjQ4NTkzMTk4MGY3Yzc0M2IxIiwicXVlc3Rpb25zIjpbMTAsMSw3Myw1NjgsMzY5LDYwMyw4NDYsMjIzLDY2LDIzMywzMDNdLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjIxMDM0Mzh9', '2019-09-05 04:39:38.892990'),
('m725euqhe9qfg5e337n0jkubun22k4vn', 'OGViNDBmZjljNmU5Y2FhZmFmNzEzYTc3Nzk5MjZjOGFiN2E4MjRkZTp7InVzZXJpZCI6Ikthd1NheE5OQm1qdDdGMGhPaTJsIiwiX2F1dGhfdXNlcl9pZCI6Ijg0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI4ZTVhOGExNmFjNjVhZjFkODFlZTYyYmYwNjEyMGY5YjNiNjY1OGZiIiwicXVlc3Rpb25zIjpbMTAsNDc0LDY4Nyw2NjYsMTg2LDY5NSw1NzIsMTkzLDczNSwxNzIsODA1XSwic2NvcmUiOjB9', '2019-08-01 17:19:25.812882'),
('mddx7j6sjyjwcsmgsgbkb45y24l1iccg', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 21:48:59.660957'),
('mulveqyn1e4s2hpt9l9f4mskul34txq9', 'OTBkOTJmMmRmZWJiNzg1NmRmYTMzYzMyN2ZlNDA0MjkyZGMzNGRkODp7Il9hdXRoX3VzZXJfaWQiOiI0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJiN2MwMzhlMWYzZjdlMGNhYzU1YmU1NWQ2OTQzZGExNjdlOWExNmJmIiwicXVlc3Rpb24iOls1MCw1MDEsNzk3LDE2NSw1MjQsNjQ2LDYxNSwyODUsMTYzLDYyOSw3MzUsNTA1LDQyNyw3NzQsNzU3LDMzNiwzNyw1NjcsMjQ4LDc2LDUyNCwyMTEsMjMwLDQ3MSw3MTYsNjA1LDYzNSwxNTIsMjI2LDYzNywyMzUsMjgzLDU2OCw0MzAsMjM0LDM2NSw3MSw0MDksNjg0LDY2Miw0NzAsOTUsNTg1LDMzNSwxMyw3MzcsMjI2LDQ5NSwyOTMsNzk2LDcyNV19', '2019-07-15 05:37:37.658341'),
('n8lcvqgk5imjs8ygfbjozjw2b7nolo0f', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 22:14:35.662524'),
('ni0f9glr0b84hht9ko7p1ozkpsi71tfv', 'ZGJkNzEyMWRmM2RhMzFiODNiYzM0NjM0MDI3MzI1YzBmYzA0NDM4Nzp7InVzZXJpZCI6IllFczlXSTRkeHJEek9TeXA2amdtIiwiX2F1dGhfdXNlcl9pZCI6IjE2IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5NzE4ZTM5NzFlZmJmYWRkMTQ1M2M0NTRiNjA4Yzg1MzU5MzEyOTU4IiwicXVlc3Rpb25zIjpbNSwzNTMsNjIzLDc1NCw0OTQsODcxXSwic2NvcmUiOjF9', '2019-07-18 11:45:00.291223'),
('niu2tk3j2g7b68s9052mexgr1t0pjwlz', 'ZDQ3ZDFkNzAyMDYwMmFlMTg3NGNlYjdiODA3OGFiNTI1ZGY5MTJhMzp7Il9hdXRoX3VzZXJfaWQiOiI1NyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiN2I5NzQ1OGFlNTM0OWZiOWE5ZDk1ZjJhZTdkNGVhNGM2MGM5Mzg5MiJ9', '2019-07-31 19:29:41.745543'),
('nuv4x08x2igpwwn1hc8azjrmeasc9ub0', 'MGY0OTM0NzMzZjA5ODExYWI3ODI4Yjg2YzZhOTU5OWYyYjdiYjcxODp7InVzZXJpZCI6IlRGVVREV0ZRV2NmV0hCU0VaamEwIiwiX2F1dGhfdXNlcl9pZCI6IjY2IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJmOTlkM2Y0Y2M5ZDJlZmE0Mzk3MjA0MjRjZTM2ZWFjMTI3N2Y1YWYzIiwicXVlc3Rpb25zIjpbNDksMTgwLDEwOSwzNDEsNzc4LDY2Miw4MjQsNiw1NDcsNzYxLDE5MywyMDgsNjExLDU5LDQ0NSwxNTUsNjAwLDI4MCw0MzQsNzgxLDgyMCwxMiw1NzcsMTYyLDIxOSwyODYsMzQxLDg0NSw3ODIsODMyLDgyNCw4MDUsNDc5LDMyNSw0OTUsMTg5LDg2MSw2MjgsMjg3LDg2Miw3MTksNTk2LDgxMiw2NDgsNzE0LDcyMiwxNyw2NzYsNjkzLDQxMl0sInNjb3JlIjowfQ==', '2019-07-31 19:11:58.783761'),
('o50mfx3jll58h1jcsbav7i3l4289xko6', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 15:35:26.494464'),
('oj6teup2v7lg43u5gdmzx1u62k6epzaq', 'MmM3NWUzZDQ0NmRhNDYwNDc4NjY4ZGZhODZmYzI5MTQ1MDhiOTJmMjp7InVzZXJpZCI6ImFtSWp4ZkdJdzd5OU9KbzE2WG1ZIiwiX2F1dGhfdXNlcl9pZCI6IjI0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3ZmRkN2VhMGYzZGExMjkyMTM5M2ZiYjYzZWIwNTQ1YThhNmEyYzg0IiwicXVlc3Rpb25zIjpbNSwyOTgsNjg2LDYzNSw0NjQsMjk4LDUsNzIyLDYzNSw1NDAsNDQ4LDM4Niw1LDM3MCw4NzcsMzMwLDUxNiw0NjZdLCJzY29yZSI6MX0=', '2019-07-18 12:14:00.764740'),
('oycw393jvpidf1lw763gpshxs5mke494', 'MGYyNmM0NmFhMjA4ODRiNmIxODAzOTUzZDBkMTgwMzAwZDdlMmRkNzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-03 11:30:21.738758'),
('piawcixd4o52sig7f8ni6r26rhab5jzi', 'NzYyOTBjODM3YTIwM2VjMjQzZGQwYWY1NDBhZWQzZGQ2YzQ4NTFmMzp7InVzZXJpZCI6ImJwUGhCZWM3Y2I1T0tzZEpGeEtoIiwiX2F1dGhfdXNlcl9pZCI6IjIwIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIwYTJjMjI2ZGMxOGU2MjYyNjA0YjJkZmRjNTQ1NDRiYTY1NjgxM2M5IiwicXVlc3Rpb25zIjpbMTUsNjIyLDMyOCw3ODIsNjkyLDQ1NCw3NTQsODc3LDU4Miw1MzgsNjc0LDY4OCw3MjAsMzU2LDYzNiw2NjFdLCJzY29yZSI6MjB9', '2019-07-18 12:01:51.088879'),
('pid8ohov375szcmypttekajkruoho8mg', 'MGYyNmM0NmFhMjA4ODRiNmIxODAzOTUzZDBkMTgwMzAwZDdlMmRkNzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-04 05:48:25.929024'),
('pleiykgmm0jsjier5crnf8ydilysgk0d', 'MzU2ZGNlMTQ4OWRkMzA5NzY2YjcyMTdiNzgzOTc0MGQwZTA0YmFkNjp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6IkRqSGxoMG52V25UcTBFc2dxS1ZpIiwibmFtZSI6IkppbmVzaCIsIl9hdXRoX3VzZXJfaWQiOiIxNzAiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6ImM5NTAyNGU0NDRhNDJjYThiZDI4NGMxODQwMjQ3MmI0MWJiMTc2ZTUiLCJxdWVzdGlvbnMiOlsxMCwxLDU1MiwzMTMsMzIyLDc4NSwxNjMsNzA2LDMzOCw1NDYsMzY2XSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIyMDk0ODAxfQ==', '2019-09-05 03:53:01.658253'),
('pybi7bvm2zqahicbkieom1yutgobdsbb', 'ODBlODc4MzljNDNhYmVjOTM3MjdmZWM4MjJjZjk2OTg4MTdhNDI0ZDp7InVzZXJpZCI6IkpHaUdpa2Nhd3dIbk5Vdm5vM2RqIiwiX2F1dGhfdXNlcl9pZCI6IjY4IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhYTU2MTdiZWM5YTkwMWNlMGI5MzRkMDRmNDM0ZjQ4NTMzN2FiNWEyIiwicXVlc3Rpb25zIjpbNDksNjUsMzE2LDMxOSw4NDMsMzM1LDM1OCwyNjEsNjcyLDcsMjI1LDE5MSwzMjQsMzcwLDYyNywxNjgsMzczLDQzNCw3MDgsNzY0LDM0Myw2NjAsNjE2LDg3OCwyMTksNjYsMTA2LDcwOCwyMDIsMzkyLDgyNSwzOTIsMTcwLDcyNyw3MzEsNTUxLDk2LDE1LDgzLDMzMSw1NSw4NjYsODgwLDEzMiwzOTMsNTMyLDQzMSw0NzksMjc3LDIwOF0sInNjb3JlIjowfQ==', '2019-07-31 19:12:59.993059'),
('q39mr7zhwkjtbmhfaj7x4nt5cgm58pig', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 14:52:43.798894'),
('qh0siah385fygk31cqe6punp6lei9xu2', 'NzBhYjEzZTE4NmNiZDhmMDYzOTU3NjM4Y2U5MzQ3MDEwZGE2ZTQzMzp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTgyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhMDk4NTRiY2IzZmY4Y2IyMTU0YzU5ZTI0NDBlNzQyMWE2MTZmZTNmIiwicXVlc3Rpb25zIjpbMTAsMSw2OTMsNTIyLDc3MiwyNjIsMjk3LDUyNSwxMjksMTgwLDgzNV0sInNjb3JlIjowfQ==', '2019-09-05 12:22:17.753531'),
('qyx7so9h1ay6iuyhes6bzwhhxylyx1ip', 'MzRkYmFhY2VmYjg4ODRmZTYwZWMzOTQ5YjFjOGFkZDA0MTM3YzA2Njp7InVzZXJpZCI6IllFczlXSTRkeHJEek9TeXA2amdtIiwiX2F1dGhfdXNlcl9pZCI6IjE3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzZmNhZDI4NmFmNzUwMGRmZDk2NTg2Y2M4N2I2YzcxMTJiMDhhOGQxIiwicXVlc3Rpb25zIjpbNSwyNTcsNTE4LDY5NSwzNzcsNjE3XSwic2NvcmUiOjR9', '2019-07-18 11:49:44.169710'),
('r5shn9k7k4cez6utasq2yazw1sxn5777', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 23:17:36.585501'),
('rbx7pm5i5aqjd4vftsaap9vvi32otryf', 'N2NhZmY4ZWFjNTIzMmYwOGU4NjNiMGU5NWZhY2E1YzY0ZWNhZTZjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTY0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhY2NkNjBhYWY0MDMxODlmYjQ4ZWIzNDMzNDI1MzUxMzcyODlmY2I4IiwicXVlc3Rpb25zIjpbMTAsNDMsNzMwLDM0NCw0MzQsNDU4LDM1NSwzNzEsNDU5LDU5NiwxOTddLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjEyMzQ5MTd9', '2019-09-04 17:54:17.898216'),
('rgciyo2abo1t8ks4of97p1ykrijmnl55', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 14:42:44.346866'),
('rrk2ttd96144j77s5xzcqprjpzs90col', 'Yjc0YzY3YTBmYTI1N2U2YzllOGIxZDE1MWQ2NmM5NTdmNDQyMGU3Yjp7InVzZXJpZCI6ImFtSWp4ZkdJdzd5OU9KbzE2WG1ZIiwiX2F1dGhfdXNlcl9pZCI6IjMzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIwNzI4MzNmNjk1N2JhMzMyMTVkMWUwNTljYjVlYmE0MDNiZTE5N2M3IiwicXVlc3Rpb25zIjpbNSwyOTUsNDYsNjczLDM5Nyw4MjddLCJzY29yZSI6LTV9', '2019-07-18 12:33:52.691867'),
('s0dhlczu1pihlvotszbjux1rgtuu91gl', 'NDhlMGIzYTE0OWZmODc3NDRkZmEzZDdkMWRhNjA3ZTVmM2RjMzk3OTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJwYXNjMTkxOSIsIl9hdXRoX3VzZXJfaWQiOiIyMjMiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6IjhjMGQzMjdlOTY4OGE1NzYyNWQwNmVkNTQ0NGI2NmUyZjliMTM5MzAiLCJxdWVzdGlvbnMiOls0MCwxLDQyLDcwLDM2LDUzLDI3LDkwLDU1LDU2LDEzLDMsMzUsMzgsNjUsNDUsMyw5NSwxMDQsMTEyLDMyLDIzLDExLDExNywxMTcsNiwyMiwyOSw0LDk4LDc3LDUxLDk5LDc5LDc4LDEwOSw3Niw3OSwxMTEsMTA5LDc1XSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIzMDkwMjI5fQ==', '2019-09-06 03:31:29.865191'),
('t5k5kt5dvbpcx81ua3o22awlbk4wsy24', 'MmFmNDM0ZjFmMDI1ZTJiZmI5NDhmZWRkMTgzYzQ1MzNkNDgwN2FkMTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6InRBdng3dmtrdXpNd3hmbTQ1RXh0IiwibmFtZSI6IlVzZXIyIiwiX2F1dGhfdXNlcl9pZCI6IjE5NCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZDYzM2I1ZTEyM2IwZjZhMDU1YjlhNDczZWFiYTA1NzZmNDcxNTc5YiIsInF1ZXN0aW9ucyI6WzEwLDEsNzgzLDYxOCw4NzcsNjk2LDEyMSw1MjUsMjgsMTcwLDEwNF0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMzAxMDAxOX0=', '2019-09-05 19:05:19.715803'),
('t5u9fstbwh3aznr71qfwxjhoh61qayor', 'YTBmYTk0MzQyMDUyZGE4OGIyYjJjNmNkNmNiZGE4NWMyOGRlZjE5NTp7Il9hdXRoX3VzZXJfaWQiOiIzNCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMGFmYzBlNmZiMGVlNzVlNDRhYjM2NjQ3ZWFhNDI4NTc3MDYyZDE4MiIsInF1ZXN0aW9ucyI6WzUsMzksNjExLDQ5OSw0MjIsMzExXSwic2NvcmUiOjB9', '2019-07-18 12:33:39.933828'),
('u3wuab5cotlor245ykyfrpgvubfv5q5a', 'MzRhYjIwNzY2MmVlMTg1NmYzZjQ4OGRjMDE2ODAxMWI4ZGNjMGM1ODp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTM3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI2NDRjMWQxY2M5ZDcyZDg2NTgzYzM4NmUxN2EwYzgxOWVkNDA4NWM4IiwicXVlc3Rpb25zIjpbMTE0LDcyMSw3NTUsMTAsMzddLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjAxODU1NDR9', '2019-09-03 13:00:44.204373'),
('ujs996rzhtsuax3zfhxedi29u6283s3l', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 14:48:24.503714'),
('upbw54rlos5rkkyykq3ax79fgx7ayf5w', 'YTcyNTQxYWVjNjJhNWViMmZjMTEzZGFjNzRmNTU2ZTM4YzFjOGJiODp7Il9hdXRoX3VzZXJfaWQiOiIxMzMiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6ImM0YWRjYjhjY2Q1NzgzN2M3MGE4Zjk1YzQ2ZTgxNmEwNzEwNjg4YWEifQ==', '2019-09-04 06:28:00.100124'),
('vi93z1freyiqzpfekt2lwvz4p6xsjap9', 'OTQxN2ZlZjc4NDNiMjEwZTk5MTIwZjg3OTY5NTRlMDE2ZTM0YmUxNTp7InVzZXJpZCI6ImJwUGhCZWM3Y2I1T0tzZEpGeEtoIiwiX2F1dGhfdXNlcl9pZCI6IjIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI2NjU0ZWI0NDI3ZTE1ZjQ4NGM1YTY3YWEyNGUwNzU1ZTUyMjRmYmUxIiwicXVlc3Rpb25zIjpbNSwyOTgsNjg2LDYzNSw0NjQsMjk4XSwic2NvcmUiOjZ9', '2019-07-18 12:13:51.586639'),
('vpm3f2xyqh7792yj5z9mfc1udszi15dp', 'MTVmNjNmYjE2MDk2MmY0YjQyNWQyNzhkNTFhZjM5MDlmM2U5YzliMzp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTU3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI2NWY1MjU3ZWNiNmZhMTZjNjIyOTQzNGZkYjAzN2UyZjE3OTQwYzllIiwicXVlc3Rpb25zIjpbMTAsNiwxOTAsMzEzLDYzOCw5MSwzMjQsMzQ2LDM4OSw2NDAsMTU2XSwic2NvcmUiOjAsImVuZHRpbWUiOjIwMTkwODIxMTc1MzUwfQ==', '2019-09-04 11:58:50.949531'),
('w87e8jihbjuf2m0pw18gk9kp067k8fzj', 'ZmFhYWEyMjdmN2ZlYWQ2Y2EyYTg1MTcwYjdlYjc5ZmYzYWExNmZkMTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTc2IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI5MGNhMjJhZjgzNTc5MTZiOTA5YzJhYjNkODc5MWY0OGMzMDcyODg5IiwicXVlc3Rpb25zIjpbMTAsMSw1ODQsMTkwLDI3OSw2NDUsNTU5LDksMzk3LDIwOCw0NzZdLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjIxMDQyNTF9', '2019-09-05 04:47:51.379832'),
('x4cndm8qftx2up7fi45w9113p4frcsnm', 'MDY3YmVjNDI3ZDEzN2Q0ZDM4YTQzYjVjNDBiZGQyMzcyNGM1ZTU0MDp7Il9hdXRoX3VzZXJfaWQiOiIzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkZTQ4ZDhkNTdmYmYyY2I0Nzc0YTgwOTMzN2FjYTU0MmRjMzczYjFmIn0=', '2019-07-14 21:00:36.038990'),
('xhtx05sbqjr8kvp6m9pug43zmi9o1j64', 'NmZhODdjYWUxNmMxZWUyNjgzYzg3YWU4NWVmZmQ1MzI3ZmM0ODk1ZTp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6ImY3WXczNkgzVEtJWHV4ZmdlS1ZZIiwibmFtZSI6IkJvc3MiLCJfYXV0aF91c2VyX2lkIjoiMTQ5IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJiYWYxNjYyNTg4ZGQ0MjdlMDAyMGVjMmM1MWIzZTA1Mzg1ZjRkMWY0IiwicXVlc3Rpb25zIjpbNjI1LDgyLDEwLDI3MCwyOTVdLCJzY29yZSI6MCwiZW5kdGltZSI6MjAxOTA4MjExMzI1MDR9', '2019-09-04 07:30:04.781620'),
('y0wu3nu7mx1ba8du1zb0c2qc0rm0h2g4', 'M2M3ZjUxMDcxN2UxOGU0NTRkMjlhZjUyZjZhZTI3YjM4NWM5OTRjYzp7ImF1dGhlbnRpY2F0ZSI6InllcyJ9', '2019-09-05 22:12:12.833690'),
('yp4rrmxbkz0abfn2b0egk825qjbys5yt', 'OTljZGM4YmQ0OWYyMWYzMmNjNmU0YTljZDI5ZmI4ZGIzNDU3ZjNiMzp7InVzZXJpZCI6ImRUMFk3ejNFUGZLanh6SXFhUEEzIiwiX2F1dGhfdXNlcl9pZCI6Ijc5IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3Yzg4YTdhYWQwM2Q4YjBiNjNhYjkyMDIzYTZjNWIyMDM5YWY5ZWE5IiwicXVlc3Rpb25zIjpbOCw2NTQsMzY4LDEyMyw3MzAsNzcxLDg3Miw3MjksMjEwXSwic2NvcmUiOjB9', '2019-08-01 12:47:21.508309'),
('z2po2th8lyrkdyxog7y0uoz3imxd9fzw', 'YzgwZTc1NGJmNmE4OTA4NTJlNjA2YTMzNDBlNGI0MTcwNDBhMzRlNjp7ImF1dGhlbnRpY2F0ZSI6InllcyIsIm5hbWUiOiJHdXJ1amkiLCJfYXV0aF91c2VyX2lkIjoiMjAxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI2ZjE1NGE0NzlkOWM5MDEwZjMzOTAxMjc1YmZlYTMxOTQ2NTQ4YWNjIn0=', '2019-09-05 22:55:44.168496'),
('z80isarhssid8d62tj50nberuz3l30vo', 'MWQ1YmVlYjI0YmM3N2Y4YzM2NGNkZDVjNjI4NWIxZDZlNjljM2FmNzp7InVzZXJpZCI6IlRGVVREV0ZRV2NmV0hCU0VaamEwIiwiX2F1dGhfdXNlcl9pZCI6IjY0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIxYWYyNjlkMDc3Nzc2NTZjYzlkN2M0OWY1NmEyMGE0MzYzNGMyMTFjIiwicXVlc3Rpb25zIjpbNDksNTU2LDQ2NCw4MzgsNDAyLDUzOSw3NzgsNzUyLDQxOSwxMjIsNjQyLDE5Nyw0NjAsNjg1LDM2NSw4OSw4MjgsNzQ0LDUyNiw1MDQsNzA1LDQyOCwxNjIsODE2LDIxLDE2MSw4MDAsMTczLDMzNiwyMDcsNTA0LDE3MCw1NDIsMTY2LDQzMCwzMTYsNDEsODE1LDUwOCwxODMsMzQxLDUwLDQ5Myw3LDQ2LDg2MSw2NDcsNTgyLDUzOSw0MV0sInNjb3JlIjowfQ==', '2019-07-31 18:54:28.324854'),
('zcb1gw6s6wfzfz9iuk96cymki740uwy9', 'OTRhYjVkMzI0MGI1NzcwMjk2ZDk4MzA1YjcwMmJiY2NiMDZmZmY0Yzp7Il9hdXRoX3VzZXJfaWQiOiIxMSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZTIyNzE5MDY1ZTI5MjRhN2Q0YjEzMzY5YmFjNWVjMTlmNTIxMzRhYiIsInF1ZXN0aW9ucyI6WzEsMzMwXSwic2NvcmUiOjB9', '2019-07-17 15:35:27.246150'),
('znt6qughj2od8sruhdk62xn7udazcnfx', 'N2Q2ZWFlMjM5NzhmM2FmOGNiMzk0MWRjOWIzMjNjZTNmMjhiMGNhYzp7ImF1dGhlbnRpY2F0ZSI6InllcyIsInVzZXJpZCI6IkpHaUdpa2Nhd3dIbk5Vdm5vM2RqIiwibmFtZSI6IlVzZXIzIiwiX2F1dGhfdXNlcl9pZCI6IjE3MyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMGM5MTZiNWM4NTdlZDNhZDFlNmVjYzFmYmY4MzM0ODZmN2E1N2M5MSIsInF1ZXN0aW9ucyI6WzEwLDEsNDMxLDg4MCwzMDIsMTAsMzQ2LDI1Myw4MDgsMTQyLDMxMV0sInNjb3JlIjowLCJlbmR0aW1lIjoyMDE5MDgyMjEwMDUwNn0=', '2019-09-05 04:10:06.224881'),
('zsuy52a4wkryuqd5o1u8jbmxuoy6grs4', 'ZDM2NjYxY2EzZTNkOGM5Yzg0MTMyZjI5NzYwZWRlNWY4NTM1M2IzNTp7Il9hdXRoX3VzZXJfaWQiOiIxMzMiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6ImQ3ZWM4MDY1YTIwZjEzOTI1Y2VmNmNhNzNkMGE3NDc2ZGUzZGI1ZGQiLCJhdXRoZW50aWNhdGUiOiJ5ZXMifQ==', '2019-09-05 23:47:57.271995');

-- --------------------------------------------------------

--
-- Table structure for table `questions_auth`
--

CREATE TABLE `questions_auth` (
  `id` int(11) NOT NULL,
  `mail` longtext NOT NULL,
  `participant1` longtext NOT NULL,
  `tickedid` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `questions_question`
--

CREATE TABLE `questions_question` (
  `id` int(3) DEFAULT NULL,
  `problem` varchar(525) DEFAULT NULL,
  `option_a` varchar(47) DEFAULT NULL,
  `option_b` varchar(47) DEFAULT NULL,
  `option_c` varchar(45) DEFAULT NULL,
  `option_d` varchar(32) DEFAULT NULL,
  `correct_option` varchar(1) DEFAULT NULL,
  `level` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions_question`
--

INSERT INTO `questions_question` (`id`, `problem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `level`) VALUES
(1, 'What is the 29th palindrome number in the natural number range.', '343', '202', '212', '262', 'b', 1),
(2, 'Given x+y+z = 17, find the number of triplets (x,y,z) such that x,y,z are non-negative integers', '87', '153', '306', '217', 'b', 1),
(3, 'Find the product of the lcm and gcd of 1231 and 763', '1266', '270', '939,253', 'Not possible', 'c', 1),
(4, 'You are given a 5 by 5 grid ,you can either go to the right or downwards by one block ,what are the number of ways in which you can travel from the leftmost and uppermost to rightmost and lowermost point?', '70', '252', '120', '258', 'a', 1),
(5, 'Find number of diagonals in a polygon of 11 sides?', '44', '55', '121', '11', 'a', 1),
(6, 'What is the index of the first term in the Fibonacci sequence to contain 10 digits.( indexing starts from 1 and fibonacci number starts from 0.)', '59', '39', '46', '53', 'c', 1),
(7, 'Given a 29×53 board and it is divided into 1×1 squares ( like a regular chess board division ). Find the total number of rectangles and squares that are present in it.', '270', '1866', '1982', '1668', 'b', 1),
(8, 'Sum of Digits in 2^70 is', '66', '70', '69', 'None of These', 'b', 1),
(9, 'No of integers which exist such that the number is equal to the sum of factorial of individual digits.', '4', '2', '5', '3', 'a', 1),
(10, 'How many palindromic primes exist with even number of digits?', '0', '1', '2', '3', 'b', 1),
(11, 'The number of numbers x such that x= p^q + q^p ', '1', '2', '3', '0', 'a', 1),
(12, 'The next term in the series 1, 133, 315, 803 is', '1148', '1547', '2196', 'None of These', 'a', 1),
(13, 'What is the minimum number of people in a room (greater than 1) so that the probability that 2 people have same birthday is 50%?', '23', '88', '187', '313', 'a', 1),
(14, 'Which number\'s factorial equals exactly 6 weeks?', '10', '11', '12', '13', 'a', 1),
(15, 'It\'s dark. You have ten grey socks and ten blue socks you want to put into pairs. All socks are exactly the same except for their colour. How many socks would you need to take with you to ensure you had at least a pair?\n\n', '3', '16', '8', '7', 'a', 1),
(16, 'If 9999 = 4, 8888 = 8, 1816 = 6, 1212 = 0, then 1919 =?\n', '10', '4', '2', '12', 'b', 1),
(17, 'Sum of the elements in the first 10 rows of Pascsal\'s Triangle is:', '1023', '2047', '255', '511', 'a', 1),
(18, 'Maximum number of intersection points of 100 circles is', '9900', '10100', '9702', 'None of these', 'a', 1),
(19, 'Given a number n and an array containing 1 to 2n+1 consecutive numbers. Three elements are chosen at random. Find the probability that the elements chosen are in A.P.\nTake n=100', '0.00750019', '0.00757595', '0.00742592', '0.00765326', 'a', 1),
(20, 'From the options given find a number n such that n! has n digits?', '24', '23', '22', '21', 'a', 1),
(21, 'The number of factors of 16! are', '2 * 2 * 3 * 3 * 7', '4032', '2592', 'None of These', 'a', 1),
(22, 'Number of safe primes below 100?\nA safe prime is a prime number of the form (2 * p) + 1 where p is also a prime.', '7', '8', '9', '10', 'a', 1),
(23, 'What are the number of prime factors of 51242183?', '3', '2', '1', 'None of These', 'a', 1),
(24, 'Number of Mersenne primes below 200 (Any prime is Mersenne Prime if it is of the form 2k-1 where k is an integer greater than or equal to 2).', '3', '4', '6', 'None of These', 'b', 1),
(25, 'Find the nest term of the sequence : 9, 27, 140, 11,?', '36', '6', '72', '1', 'a', 1),
(26, 'How many terms are there in 3,9,27,81........531441?', '25', '12', '13', '14', 'b', 1),
(27, 'If the average of four consecutive odd numbers is 12, find the smallest of these numbers?', '5', '7', '9', '11', 'c', 1),
(28, 'Largest five digit number exactly divisible by 39 is:', '99979', '99956', '99989', '99996', 'd', 1),
(29, 'Which is not the prime number?', '43', '57', '73', '101', 'b', 1),
(30, '103 x 103 + 97 x 97 = ?', '20018', '21348', '22250', '24090', 'a', 1),
(31, 'How many of the following numbers are divisible by 9 96381, 46729, 54459, 85369, 46818', '1', '2', '3', '4', 'c', 1),
(32, 'What will be the next number? 3, 5, 7, 11, 13, 17…….', '21', '19', '25', '20', 'b', 1),
(33, 'P and Q can do a work in 30 and 60 days respectively. They agreed to work together and finish the work for 1000 Rupees. But they worked only for 10 days. How much money should they together get ?', '500', '100', '800', '200', 'a', 1),
(34, 'If (4446)x + (2222)x = (10001)x then value of (2342)x - (1656)x = (?)x', '453', '353', '893', '673', 'b', 1),
(35, '‘A’ sells a DVD to ‘B’ at a gain of 17% and ‘B’ then sells it to ‘C’ at a loss of 25%. If \'C\' pays Rupees 1053 to ‘B’. then what is the cost price of the DVD to ‘A’ ?', '1200', '1450', '1250', '1375', 'a', 1),
(36, 'Choose the missing number in the series: \n9, 7, 12, 12, 15, 17, 18, 22, ?', '27', '21', '22', '24', 'b', 1),
(37, 'The units digit of (35)87 + (93)46 is:', '4', '2', '6', 'None of these', 'a', 1),
(38, 'Five colleague of different age group headed to the bar for celebrating birthday party. Few of them decided to order alcohol. The government rule clearly sates that one must be atleast 25 years old inorder to drink alcohol. Peter is the head of team and eldest member with age 40 and Bruce is co-teamlead. John is drinking banana smoothie. Barry is drinking alchohol and Smith, who is 20 years old, haven\'t decided yet. Choose the correct option to make sure rules are being followed :', 'Check Bruce\'s age', 'Check Bruce\'s and Smith\'s drink', 'Check Bruce and Barry\'s age and Smith\'s drink', 'Check Peter and Smith\'s drin', 'c', 1),
(39, 'What is the missing number in the following sequence? 2, 12, 60, 240, 720, 1440, .... 0', '2880', '1440', '720', '0', 'b', 1),
(40, 'What would be the smallest natural number which when divided either by 20 or by 42 or by 76 leaves a remainder ‘7’ in each case is_', '3067', '6067', '7987', '63487', 'c', 1),
(41, 'A six sided unbiased die with four green faces and two red faces is rolled seven times. Which of the following combinations is the most likely outcome of the experiment?', 'Three green faces and four red faces', 'Four green faces and three red faces', 'Five green faces and two red faces.', 'Six green faces and one red face', 'c', 1),
(42, 'If pqr ≠ 0 and p^{-x} = \\frac{1}{q}, q^{-y} = \\frac{1}{r}, r^{-z} = \\frac{1}{p}, what is the value of the product xyz ?', '-1', '1/pqr', 'pqr', '1', 'd', 1),
(43, 'In appreciative of social improvement completed in a town, a wealthy philanthropist decided to give gift of Rs. 750 to each male senior citizen and Rs. 1000 for female senior citizens. There are total 300 senior citizens and th 8/9th of total men and 2/3rd of total women claimed the gift. What is amount of money philanthropist paid?', '15000', '200000', '115000', '151000', 'b', 1),
(44, 'How many strings of 5 digits have the property that the sum of their digits is 7?', '66', '330', '495', '99', 'b', 1),
(45, 'Consider a set A = {1, 2, 3, ........, 1000}. How many members of A shall be divisible by 3 or by 5 or by both 3 and 5?', '533', '599', '467', '66', 'c', 1),
(46, 'The sum of all 3 digit numbers divisible by 3 is:', '165150', '165190', '156790', '175790', 'a', 1),
(47, 'Which of Following is not divisible from 4 ?', '546702', '556824', '367312', '467536', 'a', 1),
(48, 'What should be the value of * in 985*865, if number is divisible by 9?', '0', '4', '5', '6', 'b', 1),
(49, 'The least perfect square, which is divisible by each of 15, 20 and 36 is:', '1200', '800', '1000', '900', 'd', 1),
(50, 'What should be the value of x in equation (x / √216) = (√96 / x)', '11', '12', '13', '9', 'a', 1),
(51, 'Sum of 4 childeren born at interval of 4 years is 36. What is the age of youngest child?', '2 year', '3 year', '4 year', '5 year', 'b', 1),
(52, 'A is 5 years older than B who is thrice as old as C. If the total of ages of A, B and C is 40, then how old is C ?', '5', '6', '7', '8', 'a', 1),
(53, 'Three friends started running together on a circular track at 8:00:00 am. Time taken by them to complete one round of the track is 15 min, 20 min, 30 min respectively. If they run continuously without any halts, then at what time will they meet again at the starting point for the fourth time ?', '8:30:00 am', '9:00:00 pm', '12:00:00 pm', '12:00:00 am', 'c', 1),
(54, 'The LCM of two co-prime numbers is 117. What is the sum of squares of the numbers ?', '22', '220', '250', '1530', 'c', 1),
(55, 'HCF of two numbers is 11 and their LCM is 385. If the numbers do not differ by more than 50, what is the sum of the two numbers ?', '132', '35', '12', '36', 'a', 1),
(56, 'Two numbers are in the ratio of 5:7. If their LCM is 105, what is the difference between their squares ?', '210', '212', '216', '218', 'c', 1),
(57, 'Which of the following is the largest of all ? (i) 7/8 (ii) 15/16 (iii) 23/24 (iv) 31/32', '1', '2', '3', '4', 'd', 1),
(58, 'Two numbers are in the ratio 3 : 5. If their L.C.M. is 75. what is sum of the numbers?', '25', '45', '40', '50', 'c', 1),
(59, 'Ratio of two numbers is 3:2. If LCM of numbers is 60, then smaller number is?', '20', '30', '40', '50', 'a', 1),
(60, 'Three numbers are in the ratio of 2 : 3 : 4 and their L.C.M. is 240. Their H.C.F. is:', '10', '20', '30', '40', 'b', 1),
(61, 'What is the lowest common multiple of 12, 36 and 20?', '120', '180', '360', '240', 'b', 1),
(62, 'What is the least number which when divided by 4, 5, 6 and 7 leaves a remainder 3, but when divided by 9 leaves no remainder?', '1683', '1263', '423', '843', 'c', 1),
(63, 'Present age of Vinod and Ashok are in ratio of 3:4 respectively. After 5 years, the ratio of their ages becomes 7:9 respectively. What is Ashok’s present age is ?', '40', '38', '36', '34', 'a', 1),
(64, 'At present, the ratio between ages of Ram and Shyam is 6:5 respectively. After 7 years, Shyam’s age will be 32 years. What is the present age of Ram?', '26', '28', '30', '24', 'c', 1),
(65, 'The present ages of A, B and C are in proportions 4:5:9. Nine years ago, sum of their ages was 45 years. Find their present ages in years', '20,25,35', '15,20,35', '16,20,36', '15,20,19', 'c', 1),
(66, 'A person’s present age is one third of the age of his mother. After 12 years, his age will be one half of the age of his mother. What is present age of his mother?', '34', '36', '39', '40', 'b', 1),
(67, 'A is as older than B as he is younger than C.If the sum of ages of B and C is 68 years. What is the present age of A?', '34', '35', '36', '40', 'a', 1),
(68, 'Opportunistic reasoning is addressed by which of the following knowledge representation', 'script', 'black board', 'rules', 'fuzzy logic', 'b', 1),
(69, 'How many numbers between 20 and 451 are divisible by 9?', '44', '48', '50', '52', 'b', 1),
(70, 'How many terms are there in 3,9,27,81........531441?', '11', '13', '14', '12', 'd', 1),
(71, '7 + 72 + 73...........76 =?', '145672', '137256', '135672', '155672', 'b', 1),
(72, 'Two numbers are in the ratio of 2:9. If their H. C. F. is 19, numbers are:', '16,20', '8,36', '38,171', '20,90', 'c', 1),
(73, 'Subhash has 90 currency notes, some of which are Rs. 1000 denomination and rest of Rs. 500 denomination. The total amount is Rs 71,000. How many notes he has in denomination of Rs. 500?', '32', '34', '38', '40', 'c', 1),
(74, 'If the average of four consecutive odd numbers is 12, find the smallest of these numbers?', '5', '7', '9', '11', 'c', 1),
(75, 'If the sum of two numbers is 13 and the sum of their square is 85. Find the numbers?', '6,7', '5,8', '4,9', '3,10', 'a', 1),
(76, 'The difference between a two-digit number and the number obtained by interchanging the positions of its digits is 45. What is the difference between the two digits of that number?', '6', '5', '7', 'not', 'b', 1),
(77, 'A two-digit number is such that the product of the digits is 12. When 9 is subtracted from the number, the digits are reversed. The number is:', '62', '43', '34', '26', 'b', 1),
(78, 'Find a positive number which when increased by 16 is equal to 80 times the reciprocal of the number', '20', '-4', '4', '10', 'c', 1),
(79, 'What is the sum of two consecutive odd numbers, the difference of whose squares is 56?', '30', '28', '26', '24', 'b', 1),
(80, 'The product of two numbers is 108 and the sum of their squares is 225. The difference of the number is:', '3', '4', '5', '6', 'a', 1),
(81, 'Consider following two rules R1 and R2 in logical reasoning in Artificial Intelligence (AI) : R1 : From α ⊃ β and α/Inter β is known as Modus Tollens (MT) R2 : From α ⊃ β and ¬β/Inter ¬α is known as Modus Ponens (MP)', 'Only R1 is correct', 'Both R1 and R2 are correct', 'Only R2 is correct.', 'Neither R1 nor R2 is correct', 'd', 1),
(82, 'Which digits should come in place of * and $ if the number 4675*2$ is divisible by both 5 & 8?', '4,1', '1,0', '4,0', '8,0', 'b', 1),
(83, 'What least number must be added to 4000 to obtain a number exactly divisible by 17?', '12', '14', '15', '13', 'a', 1),
(84, 'What least number must be subtracted from 5000 to get a number exactly divisible by 23?', '10', '9', '6', '7', 'b', 1),
(85, 'The largest 4 digit number exactly divisible by 5, 6 and 7 is:', '9980', '9870', '9976', '9950', 'b', 1),
(86, 'What should be the next number in below series? 3, 8, 15, 24, 35……..', '45', '46', '48', '50', 'c', 1),
(87, 'The average of 21 results is 20. Average of 1st 10 of them is 24 that of last 10 is 14. the result of 11\'th is :', '40', '42', '45', '48', 'a', 1),
(88, 'Two friends A and B were employed to do a work. Initial deadline was fixed at 24 days. Both started working together but after 20 days, A left the work and the whole work took 30 days to complete. In how much time can B alone can do the work?', '40', '50', '60', '70', 'c', 1),
(89, 'A and B took a job to be completed in 20 days. They started working together and after 12 days, C joined them and the whole job finished in 15 days. How much time would C require to complete the job if only C was hired?', '15', '12', '8', '9', 'b', 1),
(90, 'Three people A, B and C working individually can finish a job in 10, 12 and 20 days respectively. They decided to work together but after 2 days, A left the work and after another one day, B also left work. If they got two lacs collectively for the entire work, find the difference of the highest and lowest share.\n', '70k', '60k', '50k', '40k', 'a', 1),
(91, 'A alone and B alone can do a work in respectively 18 and 8 days more than both working together. Find the number of days required if both work together.', '12', '8', '7', '6', 'a', 1),
(92, 'Three friends A, B and C are employed to make pastries in a bakery. Working individually, they can make 60, 30 and 40 pastries respectively in an hour. They decided to work together but due to lack of resources, they had to work on shifts of 30 minutes. Find the time taken to make 185 pastries.', '4 hr', '4 hr 15 min', '3hr', '2hr', 'b', 1),
(93, 'A person employed a group of 20 men for a construction job. These 20 men working 8 hours a day can complete the job in 28 days. The work started on time but after 18 days, it was observed that two thirds of the work was still pending. To avoid penalty and complete the work on time, the employer had to employ more men and also increase the working hours to 9 hours a day. Find the additional number of men employed if the efficiency of all men is same.', '40', '42', '44', '46', 'c', 1),
(94, '6 men and 10 women were employed to make a road 360 km long. They were able to make 150 kilometres of road in 15 days by working 6 hours a day. After 15 days, two more men were employed and four women were removed. Also, the working hours were increased to 7 hours a day. If the daily working power of 2 men and 3 women are equal, find the total number of days required to complete the work.', '34', '35', '36', '38', 'a', 1),
(95, 'A stadium was to be built in 1500 days. The contractor employed 200 men, 300 women and 750 robotic machines. After 600 days, 75% of the work was still to be done. Fearing delay, the contractor removed all women and 500 robotic machines. Also, he employed some more men having the same efficiency as earlier employed men. This led to a speedup in work and the stadium got built 50 days in advance. Find the additional number of men employed if in one day, six men, ten women and fifteen robotic machines have same work output.', '1400', '1230', '1200', '1140', 'd', 1),
(96, '3 men and 4 women can complete a work in 10 days by working 12 hours a day. 13 men and 24 women can do the same work by working same hours a day in 2 days. How much time would 12 men and 1 women working same hours a day will take to complete the whole work?', '4', '9', '8', '10', 'a', 1),
(97, '600 men can make a road in 500 days. They start working together but after every hundred days, 50 men leave the work. Find the total time (in days) it takes to make the road.', '550', '650', '750', '850', 'b', 1),
(98, '10 men working 9 hours a day can complete a work in 24 days. How much time will it take to complete the work if 15 men are employed for 6 hours a day?', '20', '24', '25', '30', 'b', 1),
(99, '32 Bakers working 6 hours a day can make 400 cakes in 25 days. If 30 such bakers are given a contract to make 300 cakes in 24 days, how many hours a day should they work?', '5', '4', '3', '8', 'a', 1),
(100, 'Two friends A and B were hired to paint a room. A alone can paint the room in 10 days and is twice as efficient as B. Due to lack of resources, they decided to work alternatively with A starting first. Find the days it will take to paint the room.', '12', '13', '14', '17', 'b', 1),
(101, 'Two friends A and B take a job for Rs. 10000. Had they worked alone, A would have taken 20 days while B would have taken 30 days. They started working together but after 10 days, A left and B completed the remaining work alone. Find the difference between their share.', '0', '10k', '20k', '30k', 'a', 1),
(102, 'If 6 men and 8 boys can do a piece of work in 10 days while 26 men and 48 boys can do the same in 2 days, the time taken by 15 men and 20 boys in doing the same type of work will be:', '4 days', '5 days', '6 days', 'NOT', 'a', 1),
(103, 'Two numbers are in the ratio of 2:9. If their H. C. F. is 19, numbers are:', '38,171', '20,90', '16,80', '15,60', 'a', 1),
(104, 'HCF of two numbers is 11 and their LCM is 385. If the numbers do not differ by more than 50, what is the sum of the two numbers ?', '34', '132', '12', '36', 'b', 1),
(105, 'Two numbers are in the ratio of 5:7. If their LCM is 105, what is the difference between their squares ?', '212', '214', '216', '220', 'c', 1),
(106, 'Which is the largest number that divides 17, 23, 35, 59 to leave the same remainder in each case ?', '2', '3', '4', '6', 'd', 1),
(107, 'The LCM. of two numbers is 30 and their HCF. is 15. If one of the numbers is 30, then what is the other number?', '15', '30', '20', '25', 'a', 1),
(108, 'Express 252 as a product of primes.', '2 * 2 * 3 * 3 * 7', '2 * 2 * 9 * 3 * 7', '2 * 2 * 3 * 7 * 7', '2 * 2 * 3 * 3 * 9', 'a', 1),
(109, 'Which of the following has the most number of divisors?', '186', '176', '99', '101', 'b', 1),
(110, 'A perfect number n is a number which is equal to the sum of its divisors. Which of the following is a perfect number?', '6', '9', '12', '24', 'a', 1),
(111, 'Express 1095/1168 in its simplest form.', '15/16', '17/18', '15/18', 'NOT', 'a', 1),
(112, 'Find the highest common factor of the following numbers: 4 * 27 * 3125 8 * 9 * 25 * 7 16 * 81 * 5 * 11 * 49', '180', '360', '240', '540', 'a', 1),
(113, 'There are 25 horses among which you need to find out the fastest 3 horses. You can conduct race among at most 5 to find out their relative speed. At no point you can find out the actual speed of the horse in a race. Find out how many races are required to get the top 3 horses.', '5', '6', '7', '8', 'c', 1),
(114, 'What will be the maximum sum of 44, 42, 40, ...... ?', '502', '504', '506', '510', 'c', 1),
(115, 'A tourist covers half of his journey by train at 60 km/h, half of the remainder by bus at 30 km/h and the rest by cycle at 10 km/h. The average speed of the tourist in km/h during his entire journey is', '30', '24', '25', '36', 'b', 1),
(116, 'Consider the following logical inferences.\nI1: If it rains then the cricket match will not be played.\nThe cricket match was played.\nInference: There was no rain.\nI2: If it rains then the cricket match will not be played.\nIt did not rain.\nInference: The cricket match was played.\nWhich of the following is TRUE?', 'I1 is correct but I2 is not a correct inference', 'I1 is not correct but I2 is a correct inference', 'Both I1 and I2 are not correct inferences', 'NOT', 'a', 1),
(117, 'The cost function for a product in a firm is given by 5q2, where q is the amount of production. The firm can sell the product at a market price of Rs 50 per unit. The number of units to be produced by the firm such that the profit is maximized is', '5', '10', '15', '20', 'a', 1),
(118, 'A political party orders an arch for the entrance to the ground in which the annual convention is being held. The profile of the arch follows the equation y = 2x – 0.1x2 where y is the height of the arch in meters. The maximum possible height of the arch is', '8', '10', '12', '14', 'b', 1),
(119, 'An automobile plant contracted to buy shock absorbers from two suppliers X and Y. X supplies 60% and Y supplies 40% of the shock absorbers. All shock absorbers are subjected to a quality test. The ones that pass the quality test are considered reliable. Of X’s shock absorbers, 96% are reliable. Of Y’s shock absorbers, 72% are reliable. The probability that a randomly chosen shock absorber, which is found to be reliable, is made by Y is', '0.916', '0.729', '0.667', '0.334', 'd', 1),
(120, 'Which of the following assertions are CORRECT? P: Adding 7 to each entry in a list adds 7 to the mean of the list Q: Adding 7 to each entry in a list adds 7 to the standard deviation of the list R: Doubling each entry in a list doubles the mean of the list S: Doubling each entry in a list leaves the standard deviation of the list unchanged', 'P Q', 'Q R', 'P R', 'NOT', 'c', 1),
(121, 'Given the sequence of terms, AD CG FK JP, the next term is', 'OV', 'PV', 'QV', 'NOT', 'a', 1),
(122, 'If Log(P) = (1/2)Log(Q) = (1/3)Log(R), then which of the following options is TRUE?', 'P^2 = Q^3R^2', 'Q^2 = PR', 'Q^2 = R^3*P^2', 'NOT', 'b', 1),
(123, 'A container originally contains 10 litres of pure spirit. From this container 1 litre of spirit is replaced with 1 litre of water. Subsequently, 1 litre of the mixture is again replaced with 1 litre of\'water and this process is repeated one more time. How much spirit is now left in the container?', '7.26 lit', '7.29 lit', '7.39 lit', 'NOT', 'b', 1),
(124, '25 persons are in a room. 15 of them play hockey, 17 of them play football and 10 of them play both hockey and football. Then the number of persons playing neither hockey nor football is:', '2', '3', '15', '20', 'b', 1),
(125, 'If 137 + 276 = 435 how much is 731 + 672?', '1623', '1567', '1789', 'NOT', 'a', 1),
(126, '5 skilled workers can build a wall in 20 days: 8 semi-skilled workers can build a wall in 25 days; 10 unskilled workers can build a wall in 30 days. If a team has 2 skilled, 6 semi-skilled and 5 unskilled workers, how long will it take to build the wall?', '10', '15', '20', '25', 'b', 1),
(127, 'What is the next number in series :\n4, 6, 12, 18, 30, 42, 60, ?', '78', '72', '98', '102', 'b', 1),
(128, 'How many three digit numbers are of form xyz with x<y, z<y and x>0.', '244', '250', '240', '237', 'c', 1),
(129, 'How many triangles can be formed by joining the vertices of a decagon?', '110', '120', '123', '140', 'b', 1),
(130, 'There are 15 intermediate stations on a railway line from one terminus to another. In how many ways a train can stop at 3 of these intermediate stations if no two of these stopping stations are to be consecutive?', '286', '455', '220', '257', 'a', 1),
(131, 'There are 37 points in a plane out of which no three are in the same straight line except 13 points which are collinear . How many straight lines can be formed by joining them?', '589', '590', '592', 'None of these', 'a', 1),
(132, '0, 0, 1, 1, 2, 4, 7, 13, 24, 44, 81, 149, 274, the next term is?', '504', '927', '505', '928', 'a', 1),
(133, 'The number of digits in 20th Fibonacci Number', '3', '4', 'None of These', '5', 'b', 1),
(134, 'The longest sum of the consecutive primes below one-thousand that adds to a prime is ', '953', '947', '967', '971', 'a', 1),
(135, 'Addition of first 6 prime numbers ending with digit 9 eg. 139', '682', '672', '652', '692', 'b', 1),
(136, 'V  I  B  G  Y  O  R\n6  _  4  _   5  _   3\nFill in the blanks', '5 5 6', '4 6 6', '4 5 4', '6 5 6', 'd', 1),
(137, 'The unit place number of 2^30 is??', '2', '4', '6', '8', 'b', 1),
(138, 'The smallest number that can be divided by each of the numbers from 1 to 10 without any remainder.', '7560', '5040', '840', '2520', 'd', 1),
(139, 'The number, 197, is called a circular prime because all rotations of the digits: 197, 971, and 719, are themselves prime.Which is the smallest 3-digit circular prime no. ?', '1,0', '133', '157', '113', 'd', 1),
(140, 'You are given a 5 by 5 grid ,you can either go rightwards or downwards by one block ,what are the number of ways in which you can travel from the leftmost and uppermost to rightmost and lowermost point?', '252', '168', '196', '200', 'a', 1),
(141, 'Number of diagonals of decagon ?', '20', '45', '35', '40', 'c', 1),
(142, 'Given postive numbers a, b, c which satisfies the equations a+b+c=12.\nFind the maximum value of a*b*c.', '64', '38', '27', '8', 'a', 1),
(143, 'Let d(n) be defined as the sum of proper divisors of n (numbers less than n which divide evenly into n).\nIf d(a) = b and d(b) = a, where a ≠ b, then a and b are an amicable pair and each of a and b are called amicable numbers. What is the amicable number of 220', '246', '282', '284', '223', 'c', 1),
(144, 'Given a sequence 1 ,2 ,6 ,15 ,.........\nFind the 11th term ', '286', '507', '386', '240', 'c', 1),
(145, 'What is the possibility of having 53 Thursdays in a non-leap year?', '6/7', '1/7', '1/365', '53/365', 'b', 1),
(146, 'The no of trailing zeroes in factorial of 28 is ?', '4', '5', '6', '7', 'c', 1),
(147, 'If there are 6 Stairs, in how many ways can we reach the 6th stair?', '6', '11', '13', '16', 'c', 1),
(148, 'Find the product of all factors of 221', '48841', '48456', '48909', '48671', 'a', 1),
(149, 'If 17^5 is divided by 6 remainder is', '3', '5', '2', '1', 'b', 1),
(150, 'Find the 10th number of the series 1, 6, 13 ,24', '150', '200', '160', '180', 'a', 1),
(151, 'Which digits should come in place of * and $ if the number 4675*2$ is divisible by both 5 & 8?', '1,0', '4,0', '4,5', '2,4', 'a', 1),
(152, 'Mala has a colouring book in which each English letter is drawn two times. She wants to paint each of these 52 prints with one of k colours, such that the colour-pairs used to colour any two letters are different. Both prints of a letter can also be coloured with the same colour. What is the minimum value of k that satisfies this requirement ?', '9', '8', '7', '6', 'c', 1),
(153, 'Find the number t and digit a in:\n[3(230+t)]^2=492,a04', '1,2', '4,8', '3,5', '3,6', 'b', 1),
(154, 'the sum of all digits of the answer in this series 1^1 + 2^2 + 3^3 + ... + 10^10 =', '29', '30', '33', '35', 'a', 1),
(155, 'The number of ways in which eight digit number can be formed using the digits from 1 to 9 without repitition if first four places of the number are in increasing order and last four places are in decreasing order\n', '540', '630', '270', '450', 'b', 1),
(156, 'Nine people are sitting around a round table. The number of ways of selecting four of them such that they are not from adjacent seats are', '5', '8', '9', '10', 'c', 1),
(157, 'Let N be the number of integral solution of the equation x+y+z+w=15 where x>=0 ,y>5 ,z>=2 and w>=1.Find the unit digit of N.', '2', '3', '5', '4', 'd', 1),
(158, 'The last digit of 9!+3^9966 is:', '1', '3', '7', '9', 'd', 1),
(159, 'The last digit of 9!+3^9966 is:', '1', '3', '7', '9', 'd', 1),
(160, 'There are 3A ,3B ,3C that are places randomly in a 3 by 3 matrix.The probability that no row or column contains two identical letters can be expressed as p/q, where p and q are co-prime numbers.Then p+q is? ', '131', '161', '141', '131', 'c', 1),
(161, 'What is half divided into half?', '1', '1/4', '1/2', '2', 'a', 1),
(162, 'How many automorphic numbers are there between 1 and 1000?\n', '3', '4', '6', '6', 'b', 1),
(163, 'Total no. Of armstrong numbers in existance\n', '<5', '<35', '<90', '<220', 'c', 1),
(164, 'How much of the English alphabet does a given string use? The sentence :\"The quick brown fox jumps over the lazy dog\"  uses 100%. It has 26 unique letters (howmucftenglisapbdvr), and 26/26 =100.Now how much percentage the following sentence will give: \"Did you put your name in the Goblet of Fire, Harry?\" he asked calmly. \n', '76.92', '75.48', '72.08', '70', 'a', 1),
(165, 'Which of the following is correct post-fix representation for (a*b*c*[a+c]*d)', 'ab*c*a+c*d*', 'ab*c*ac+d*', 'ab*c*c+a*d*', 'a*b*c*ac+*d*', 'b', 1),
(166, 'A multiple choice test contains 10 questions. There are 4 possible answers for each question. In how many ways can a student answer the questions on the test if the student answers every question?', '10', '4^10', '40', '10^4', 'd', 1),
(167, 'What is value of Exception for the given array a[6] = { 1.0 , 2.0 , 3.0 , 4.0 , 5.0 , 6.0}', '3', '3.5', '4', '4.5', 'b', 1),
(168, '2,3,7,43,1807,?', '3263442', '3263443', '3264332', '3264333', 'b', 1),
(169, '14,10,?,7,1,0', '9', '9.5', '8', '8.5', 'c', 1),
(170, 'The number of ways of placing 8 similar balls in 5 numbered boxes', '498', '495', '500', '493', 'b', 1),
(171, 'Let n=6 and given permutation is 125364 find next permutation?', '125436', '124536', '125346', '123564', 'a', 1),
(172, 'Find the probability of drawing a card of spades on each of two consecutive draws from a well shuffled pack of cards without replacement of a card. ', '0.0588235', '0.0587235', '0.588234', '0.588243', 'a', 1),
(173, 'How many numbers of 7 digits can be formed with the numbers 0,2,25,6,6,6 which are even?', '4320', '4330', '4340', '4350', 'a', 1),
(174, 'Probability of a man hitting a target is 0.25. If he fires seven times, what is the probability that he will hit the target at least twice?', '0.555', '0.6', '0.405', '0.5', 'a', 1),
(175, 'An average box containing 10 articles is likely to have 2 defectives. If we consider a consignment of 100 boxes, how many of of them are expected to have three or less defective. ', '88', '85', '91', '90', 'a', 1),
(176, 'Find the number of rectangles on a chess board', '1296', '1294', '1298', '208', 'a', 1),
(177, 'Find the number of ways such that numbers which are divisible by 105 and have 105 factors?', '6', '5', '4', '3', 'a', 1),
(178, 'Find the number of ways to post 4 letters in 6 mail boxes?', '6^4', '4^6', 'None of These', '6^4+4^6', 'a', 1),
(179, 'A man travels 1000km north of New Delhi, then 1000km west, then 1000km South and 1000km east. Give his position with respect to New Delhi.', 'Left of New Delhi', 'Right of New Delhi', 'At New Delhi', 'Can\'t say', 'a', 1),
(180, 'X speaks truth 60% and Y in 50% of the cases. Find the probability that they contradict each other on narrating each other.', '0.5', '0.6', '0.625', '0.525', 'a', 1),
(181, '1, 1, 2, 1, 1, 2, 2, 2, ?, 1', '1', '2', '3', '4', 'c', 1),
(182, '1, 11, 21, 1211, 111221, 312211, 13112221, ', '112131211', '1131223211', '1113111211', '1113213211', 'd', 1),
(183, 'If the difference between expectation of the square of a random variable (E[X²]) and the square of the expectation of the random variable (E[X])² is denoted by R, then?', 'R = 0', 'R < 0', 'R >= 0', 'R>0', 'c', 1),
(184, 'What is the probability that divisor of 1099 is a multiple of 1096?', '1/625', '4/625', '12/625', '16/625', 'a', 1),
(185, 'Two n bit binary strings, S1 and S2, are chosen randomly with uniform probability. The probability that the Hamming distance between these strings (the number of bit positions where the two strings differ) is equal to d is', 'nCd /2n', 'nCd / d', 'd/2n\n', '1/2d', 'a', 1),
(186, 'The probability that the top and bottom cards of a randomly shuffled deck are both aces is\nA\n\n\n', '4/52 x 4/52', '4/52 x 3/52', '\n4/52 x 3/51\n', '4/52 x 4/51', 'c', 1),
(187, 'Does any positive integer X exists such that (X * X) % 13 == 4', 'Yes', 'No', 'Can\'t Say', 'None of the Above', 'a', 1),
(188, 'What is the 53rd prime number?\n', '239', '251', '233', '277', 'a', 1);

-- --------------------------------------------------------

--
-- Table structure for table `questions_scores`
--

CREATE TABLE `questions_scores` (
  `id` int(11) NOT NULL,
  `username` longtext NOT NULL,
  `event` longtext NOT NULL,
  `score` int(11) NOT NULL,
  `created` datetime(6) NOT NULL,
  `firebase` tinyint(1) NOT NULL,
  `name` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Scores_scores`
--

CREATE TABLE `Scores_scores` (
  `id` int(11) NOT NULL,
  `username` longtext NOT NULL,
  `event` longtext NOT NULL,
  `score` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Scores_scores`
--

INSERT INTO `Scores_scores` (`id`, `username`, `event`, `score`) VALUES
(1, 'pratham', 'Cerebro', -5),
(2, 'pratham@pasc.in', 'Cerebro', -5),
(3, 'user1@pasc.in', 'Cerebro', 10),
(4, 'user2@pasc.in', 'Cerebro', 0),
(5, 'user5@pasc.in', 'Cerebro', 10),
(6, 'user3@pasc.in', 'Cerebro', 5),
(7, 'user1@pasc.in', 'Cerebro', -3),
(8, 'user1@pasc.in', 'Cerebro', -2),
(9, 'pratham@pasc.in', 'Cerebro', -9),
(10, 'user3@pasc.in', 'Cerebro', -1),
(11, 'user4@pasc.in', 'Cerebro', 0),
(12, 'pratham@pasc.in', 'Cerebro', -4),
(13, 'joshisiddhesh28@gmail.com', 'Cerebro', -5),
(14, 'user1@pasc.in', 'Cerebro', -5),
(15, 'user5@pasc.in', 'Cerebro', 7),
(16, 'jinesh@pasc.in', 'Cerebro', 0),
(17, 'pratham@pasc.in', 'Cerebro', 12),
(18, 'boss@pasc.in', 'Cerebro', 4),
(19, 'user1@pasc.in', 'Cerebro', 7),
(20, 'anuj@pasc.in', 'Cerebro', 0),
(21, 'jinesh@pasc.in', 'Cerebro', 0),
(22, 'boss@pasc.in', 'Cerebro', -2),
(23, 'apoorv@pasc.in', 'Cerebro', 2),
(24, 'user1@pasc.in', 'Cerebro', 0),
(25, 'user2@pasc.in', 'Cerebro', -1),
(26, 'user3@pasc.in', 'Cerebro', 0),
(27, 'user4@pasc.in', 'Cerebro', 0),
(28, 'user5@pasc.in', 'Cerebro', 8),
(29, 'anuj@pasc.in', 'Cerebro', 0),
(30, 'jinesh@pasc.in', 'Cerebro', -3),
(31, 'jinesh@pasc.in', 'Cerebro', -3),
(32, 'boss@pasc.in', 'Cerebro', 0),
(33, 'pratham@pasc.in', 'Cerebro', 0),
(34, 'raghav@pasc.in', 'Cerebro', 0),
(35, 'manav@pasc.in', 'Cerebro', 0),
(36, 'yash@pasc.in', 'Cerebro', 3),
(37, 'anuj@pasc.in', 'Cerebro', 11),
(38, 'user1@pasc.in', 'Cerebro', 2),
(39, 'user1@pasc.in', 'Cerebro', 2),
(40, 'user3@pasc.in', 'Cerebro', 0),
(41, 'user2@pasc.in', 'Cerebro', -5),
(42, 'yash@pasc.in', 'Cerebro', -1),
(43, 'user5@pasc.in', 'Cerebro', 0),
(44, 'user4@pasc.in', 'Cerebro', 0),
(45, 'user4@pasc.in', 'Cerebro', 0),
(46, 'user4@pasc.in', 'Cerebro', 5),
(47, 'boss@pasc.in', 'Cerebro', 8),
(48, 'apoorv@pasc.in', 'Cerebro', 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `questions_auth`
--
ALTER TABLE `questions_auth`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions_scores`
--
ALTER TABLE `questions_scores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Scores_scores`
--
ALTER TABLE `Scores_scores`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=225;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=273;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `questions_auth`
--
ALTER TABLE `questions_auth`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `questions_scores`
--
ALTER TABLE `questions_scores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `Scores_scores`
--
ALTER TABLE `Scores_scores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
