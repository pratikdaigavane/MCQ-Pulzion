from django.apps import AppConfig


class TestSubmitConfig(AppConfig):
    name = 'test_submit'
